"""
ab_inst.py — 악기 소리 자체를 옛것/새것으로 비교하는 짧은 예제 만들기

믹스에 묻히지 않게 단독 타점과 짧은 악구만 만든다.
"""
import numpy as np
import gugak as G
import oldinst as O

SR = G.SR
RV = G.Reverb(dur=1.8, decay=0.9, pre=0.010, damp=5000, seed=5)


def bake(events, dur, wet=0.28):
    """events: [(신호, 시각, 게인, 팬)]"""
    mix = G.Mix(dur, tail=2.0)
    for y, at, g, pan in events:
        mix.add(y, at, g, pan, 0.30)
    out = mix.render(RV, wet=wet, loop=False, target_db=-16.5,
                     eq=dict(low_db=-2.0, mud_db=-1.0, pres_db=1.5, air_db=2.0, hpf=35))
    return G.fade_edges(out, 8)


# ---------------------------------------------------------------- 단타
def hits_old():
    e = []
    for i, t in enumerate([0.3, 1.4, 2.5]):
        e.append((O.old_janggu_gung(1.0, 1.0, seed=10 + i), t, 1.0, -0.15))
    for i, t in enumerate([3.7, 4.5, 5.3]):
        e.append((O.old_janggu_chae(0.5, 1.0, seed=20 + i), t, 1.0, 0.2))
    for i, t in enumerate([6.4, 7.6]):
        e.append((O.old_buk(1.4, 1.0, seed=30 + i), t, 1.0, 0.05))
    return bake(e, 9.2)


def hits_new():
    e = []
    for i, t in enumerate([0.3, 1.4, 2.5]):
        e.append((G.janggu_gung(1.1, 1.0, seed=10 + i, strike=0.30 + 0.06 * i), t, 1.0, -0.15))
    for i, t in enumerate([3.7, 4.5, 5.3]):
        e.append((G.janggu_chae(0.55, 1.0, seed=20 + i, strike=0.68 + 0.05 * i), t, 1.0, 0.2))
    for i, t in enumerate([6.4, 7.6]):
        e.append((G.buk(1.5, 1.0, seed=30 + i), t, 1.0, 0.05))
    return bake(e, 9.2)


# ---------------------------------------------------------------- 굿거리 한 장단 ×2
GUT = [(0, "G", 1.0), (2, "c", .42), (2.5, "c", .34), (3, "g", .72),
       (4, "c", .40), (5, "c", .30), (5.5, "c", .26), (6, "g", .85),
       (8, "c", .42), (8.5, "c", .34), (9, "g", .62), (10, "c", .38),
       (11, "c", .30), (11.5, "c", .26)]
SOB = 0.40


def jangdan(new):
    e = []
    rng = np.random.default_rng(7)
    for cyc in range(2):
        t0 = 0.25 + cyc * 12 * SOB
        for pos, kind, v in GUT:
            t = t0 + pos * SOB + rng.normal(0, 0.008)
            vv = v * (0.93 + 0.14 * rng.random())
            sd = int(rng.integers(1 << 20))
            if kind in ("G", "g"):
                y = (G.janggu_gung(1.0, 1.0, seed=sd, strike=0.28 + 0.12 * rng.random())
                     if new else O.old_janggu_gung(0.85, 1.0, seed=sd))
                e.append((y, t, vv, -0.18))
            if kind in ("G", "c"):
                y = (G.janggu_chae(0.5, 1.0, seed=sd + 1, strike=0.62 + 0.18 * rng.random())
                     if new else O.old_janggu_chae(0.4, 1.0, seed=sd + 1))
                e.append((y, t, vv * (0.75 if kind == "G" else 1.0), 0.22))
    return bake(e, 0.25 + 24 * SOB + 1.2)


# ---------------------------------------------------------------- 가야금 / 거문고
PENTA = [0, 2, 4, 7, 9]


def pitch(root, n):
    o, i = divmod(n, 5)
    return G.mtof(root + 12 * o + PENTA[i])


def gaya(new):
    e = []
    rng = np.random.default_rng(11)
    # 단음 3개 (농현 있는 것/없는 것) → 짧은 악구
    for i, (n, non) in enumerate([(0, 0), (2, 0), (1, 26)]):
        y = (G.gayageum(pitch(58, n), 3.0, 1.0, nonghyeon=non, seed=40 + i) if new
             else O.old_gayageum(pitch(58, n), 3.0, 1.0, nonghyeon=non, seed=40 + i))
        e.append((y, 0.3 + i * 1.5, 1.0, 0.0))
    t = 5.2
    for k, n in enumerate([0, 1, 2, 1, 3, 2, 1, 0]):
        y = (G.gayageum(pitch(58, n), 2.2, 1.0, nonghyeon=(22 if k in (3, 7) else 0),
                        seed=60 + k) if new
             else O.old_gayageum(pitch(58, n), 2.2, 1.0, nonghyeon=(22 if k in (3, 7) else 0),
                                 seed=60 + k))
        e.append((y, t + k * 0.42, 0.9, 0.15))
    return bake(e, 5.2 + 8 * 0.42 + 2.4, wet=0.34)


def geo(new):
    e = []
    for i, n in enumerate([0, 2, 1]):
        y = (G.geomungo(pitch(46, n), 3.2, 1.0, seed=80 + i) if new
             else O.old_geomungo(pitch(46, n), 3.2, 1.0, seed=80 + i))
        e.append((y, 0.3 + i * 1.6, 1.0, -0.1))
    t = 5.4
    for k, n in enumerate([0, 0, 2, 1, 0, 3, 2, 0]):
        y = (G.geomungo(pitch(46, n), 2.0, 1.0, seed=100 + k) if new
             else O.old_geomungo(pitch(46, n), 2.0, 1.0, seed=100 + k))
        e.append((y, t + k * 0.5, 0.85, -0.2))
    return bake(e, 5.4 + 8 * 0.5 + 2.4, wet=0.34)


ITEMS = [
    ("hits", "단타 — 궁편 ×3, 채편 ×3, 북 ×2", hits_old, hits_new),
    ("jangdan", "굿거리 한 장단 ×2 (장구만)", lambda: jangdan(False), lambda: jangdan(True)),
    ("gayageum", "가야금 — 단음 3 + 짧은 악구", lambda: gaya(False), lambda: gaya(True)),
    ("geomungo", "거문고 — 단음 3 + 짧은 악구", lambda: geo(False), lambda: geo(True)),
]

if __name__ == "__main__":
    import os
    os.makedirs("ab", exist_ok=True)
    for key, label, fo, fn in ITEMS:
        G.write_wav(f"ab/{key}_old.wav", fo())
        G.write_wav(f"ab/{key}_new.wav", fn())
        print(f"{key:10s} {label}")

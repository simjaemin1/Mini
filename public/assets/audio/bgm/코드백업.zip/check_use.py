"""
check_use.py — 곡의 음 하나하나가 실제 녹음에서 왔는지 센다.

렌더 결과만 들으면 몇 개가 합성음으로 새어나갔는지 알 수 없다.
score.json(악보)의 모든 음에 대해 Bank 가 실제로 어떤 조각을 고르는지 물어본다.
고를 게 없으면 install() 이 합성음으로 대체하므로, 그게 '샘플로 못 채운 음' 이다.
"""
import sys
import json
import collections
import numpy as np
import sampler as S

NOTE = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
nm = lambda m: f"{NOTE[int(round(m)) % 12]}{int(round(m)) // 12 - 1}"
f2m = lambda f: 69 + 12 * np.log2(max(1e-6, f) / 440.0)


def choose_art(inst, dur, nong, bend, have):
    def ok(a):
        return a in have
    if bend <= -20 and ok("toegim"):
        return "toegim"
    if bend >= 20 and ok("chuseong"):
        return "chuseong"
    if nong >= 22 and ok("nong_deep"):
        return "nong_deep"
    if nong >= 8 and dur is not None and dur >= 2.6 and ok("nong_deep"):
        return "nong_deep"
    if nong >= 8 and ok("nong_shallow"):
        return "nong_shallow"
    if dur is not None and dur < 0.5 and ok("staccato"):
        return "staccato"
    return "sus" if ok("sus") else None


def main():
    roots = sys.argv[1:] or ["samples_gaya"]
    bank = S.Bank(roots)
    score = json.load(open("score.json"))
    arts_of = {k: {m[2].get("art") for m in v} for k, v in bank.by_inst.items()}
    octs = {t: S.plan_octaves({t: n}, bank) for t, n in score.items()}

    print(f"{'곡':20s} {'음':>6s} {'샘플':>6s} {'합성':>5s} {'악기':>4s}  이동 평균/최대(반음)")
    print("-" * 78)
    tot_n = tot_s = 0
    per_inst = collections.defaultdict(lambda: [0, 0])
    for track, notes in score.items():
        n = s = 0
        shifts = []
        insts = set()
        for e in notes:
            inst = e["inst"]
            insts.add(inst)
            n += 1
            if not bank.has(inst):
                per_inst[inst][1] += 1
                continue
            midi = None
            if e.get("freq"):
                midi = f2m(e["freq"]) + 12 * octs[track].get(inst, 0)
                rng = bank.range(inst)
                if rng:
                    lo, hi = rng
                    while midi > hi + 2:
                        midi -= 12
                    while midi < lo - 2:
                        midi += 12
                    d0 = bank._dist(inst, midi)
                    if d0 > 1.2:
                        for alt in (midi + 12, midi - 12):
                            if lo - 2 <= alt <= hi + 2 and bank._dist(inst, alt) < min(0.6, d0):
                                midi = alt
            art = choose_art(inst, e.get("dur"), e.get("nong", 0), e.get("bend", 0),
                             arts_of.get(inst, set())) if midi is not None else None
            got = bank._pick(inst, midi, rr=n, dur=e.get("dur"),
                             amp=e.get("amp", 1.0), art=art)
            if got is None:
                per_inst[inst][1] += 1
                continue
            s += 1
            per_inst[inst][0] += 1
            if midi is not None and got[0] is not None:
                shifts.append(abs(got[0] - midi))
        tot_n += n
        tot_s += s
        sh = (np.mean(shifts), np.max(shifts)) if shifts else (0, 0)
        print(f"{track:20s} {n:6d} {s:6d} {n-s:5d} {len(insts):4d}  {sh[0]:6.2f} / {sh[1]:5.2f}")
    print("-" * 78)
    print(f"{'합계':20s} {tot_n:6d} {tot_s:6d} {tot_n-tot_s:5d}")
    print(f"\n실제 녹음으로 채운 비율: {tot_s/tot_n*100:.1f}%   합성음으로 남은 음: {tot_n-tot_s}개\n")
    print(f"{'악기':14s} {'샘플':>7s} {'합성':>7s}")
    for i, (a, b) in sorted(per_inst.items(), key=lambda t: -sum(t[1])):
        print(f"{i:14s} {a:7d} {b:7d}")


if __name__ == "__main__":
    main()

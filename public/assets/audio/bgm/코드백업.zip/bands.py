import numpy as np, json
from scipy.io import wavfile
names=list(json.load(open("out/meta.json")))
edges=[20,60,120,250,500,1000,2000,4000,8000,16000]
print(f"{'track':20s}"+"".join(f"{a}-{b}".rjust(9) for a,b in zip(edges,edges[1:])))
for nm in names:
    sr,d=wavfile.read(f"out/{nm}.wav"); m=(d.astype(np.float32)/32768).mean(1)
    F=np.fft.rfft(m*np.hanning(len(m))); f=np.fft.rfftfreq(len(m),1/sr); P=np.abs(F)**2
    tot=P.sum()
    row=[]
    for a,b in zip(edges,edges[1:]):
        s=P[(f>=a)&(f<b)].sum()
        row.append(10*np.log10(s/tot+1e-12))
    print(f"{nm:20s}"+"".join(f"{v:9.1f}" for v in row))

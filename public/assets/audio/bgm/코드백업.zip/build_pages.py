"""
build_pages.py — 자기완결 진단 페이지 4종을 다시 굽는다.

★오디오는 반드시 MP3 로 넣는다. Safari 는 Ogg Vorbis 를 재생하지 못한다.
  (Chromium 으로만 검증하면 이 문제를 못 잡는다 — WebKit 으로도 확인할 것)
"""
import base64
import json
import os

CSS = """
:root{--bg:#14110e;--panel:#1e1a15;--line:#3a322a;--ink:#e9e0d2;--dim:#a39683;
 --acc:#c99a4e;--red:#c98b6e;--grn:#8fb08a}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);padding:26px 20px 70px;
 font-family:-apple-system,BlinkMacSystemFont,"Apple SD Gothic Neo","Noto Sans KR",sans-serif;line-height:1.6}
.wrap{max-width:940px;margin:0 auto}
h1{font-size:21px;margin:0 0 6px}
.sub{color:var(--dim);font-size:13px;margin-bottom:20px}
h2{font-size:15px;color:var(--acc);border-bottom:1px solid var(--line);padding-bottom:7px;margin:32px 0 12px}
h3{font-size:14.5px;color:var(--acc);margin:0 0 10px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(258px,1fr));gap:10px}
.two{display:grid;grid-template-columns:1fr 1fr;gap:12px}
@media(max-width:640px){.two{grid-template-columns:1fr}}
.lay,.pair{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:12px 14px}
.pair{margin-bottom:14px}
.lay.full{border-color:var(--acc);margin-bottom:12px}
.nm{font-size:13px;margin-bottom:7px;display:flex;justify-content:space-between;align-items:baseline;gap:8px}
.db{color:var(--dim);font-size:11px;white-space:nowrap}
.tag{font-size:11.5px;margin-bottom:5px}
.tag.old,.tag.syn{color:var(--red)} .tag.new,.tag.smp{color:var(--grn)}
audio{width:100%;height:34px}
.why,.note{color:var(--dim);font-size:12.5px;margin-top:11px;padding-top:10px;border-top:1px solid var(--line)}
.warn{background:#1c1712;border:1px solid #55452c;border-radius:10px;padding:14px 16px;
 font-size:13px;color:#d8c8a8;margin-bottom:20px}
b{color:var(--ink)} code{background:#241f18;padding:2px 5px;border-radius:4px;font-size:12px;color:#d9c79f}
table{width:100%;border-collapse:collapse;font-size:12.5px;margin-top:8px}
td,th{border-bottom:1px solid var(--line);padding:6px 8px;text-align:left}
th{color:var(--acc);font-weight:600}
"""


def b64(p):
    with open(p, "rb") as f:
        return "data:audio/mpeg;base64," + base64.b64encode(f.read()).decode()


def au(p):
    return f'<audio controls loop preload="metadata" src="{b64(p)}"></audio>'


def page(title, sub, body):
    return (f'<!DOCTYPE html><html lang="ko"><head><meta charset="utf-8">'
            f'<meta name="viewport" content="width=device-width,initial-scale=1">'
            f'<title>{title}</title><style>{CSS}</style></head><body><div class="wrap">'
            f'<h1>{title}</h1><div class="sub">{sub}</div>{body}</div></body></html>')


def write(name, html):
    with open(name, "w") as f:
        f.write(html)
    print(f"{name}  {os.path.getsize(name)/1e6:.2f} MB")


# ---------------------------------------------------------------- ① 층 분리
def build_layers():
    TR = [("village_day_trad", "마을 낮 · 전통"), ("village_night_trad", "마을 밤 · 전통"),
          ("village_day_amb", "마을 낮 · 앰비언트"), ("journey_trad", "원정 · 전통")]
    secs = [f'''<h2>먼저 — 제가 찾은 결함 두 개 (고치기 전 / 고친 뒤)</h2>
<div class="two">
 <div class="pair"><div class="tag old">마을 낮·전통 <b>고치기 전</b></div>{au("diag/ab__village_day_trad__before.mp3")}</div>
 <div class="pair"><div class="tag new">마을 낮·전통 <b>고친 뒤</b></div>{au("diag/ab__village_day_trad__after.mp3")}</div>
 <div class="pair"><div class="tag old">가야금만 <b>고치기 전</b> — A#2~G4, 21반음</div>{au("diag/ab__gayageum__before.mp3")}</div>
 <div class="pair"><div class="tag new">가야금만 <b>고친 뒤</b> — F3~G4, 12반음</div>{au("diag/ab__gayageum__after.mp3")}</div>
</div>
<div class="warn"><b>① 가야금 반주가 악기 음역 밖에서 뛰어다녔습니다.</b>
 반주 음을 고르는 식에 <code>steps[i%5] % 10 - 5</code> 라는 실수가 있어 A#2(116Hz)~G4 를 21반음씩 도약했습니다.
 실제 가야금 최저현은 D3(146Hz)라 그 아래는 없는 음입니다. 울림 1.9초 / 음 간격 0.395초라 항상 4~5음이 겹쳐 울렸습니다.
 → 한 옥타브 안에서 순차로 움직이게 고치고 울림도 1.15초로 줄였습니다. 가야금 층의 90~150Hz 성분이 <b>14.7dB</b> 줄었습니다.
 <br><br><b>② 대금·단소 숨소리가 모두 같은 위상으로 떨렸습니다.</b>
 <code>1 + 0.5·sin(2π·3.1t)</code> 라는 고정 3.1Hz 트레몰로가 음마다 t=0 에서 시작해 <b>모든 음이 같은 박자로 같이</b> 떨렸습니다.
 → 음마다 속도(2.2~4.4Hz)와 위상을 다르게 하고 깊이도 절반으로 줄였습니다.</div>''']
    for tr, title in TR:
        rows = json.load(open(f"diag/{tr}.json"))
        cards = "".join(
            f'<div class="lay"><div class="nm">{lab}<span class="db">{db:+.1f} dB</span></div>'
            f'{au(f"diag/{tr}__{k}.mp3")}</div>' for k, lab, db in rows)
        secs.append(f'<h2>{title} — 층 분리</h2>'
                    f'<div class="lay full"><div class="nm">전체 (완성본)</div>'
                    f'{au(f"diag/{tr}__full.mp3")}</div><div class="grid">{cards}</div>')
    write("BGM_층분리.html", page(
        "BGM 층 분리 — 어느 소리인지 찾기",
        "각 곡의 12~34초 구간. 층별 음량은 <b>완성본 안에서의 실제 크기 그대로</b>이고 "
        "옆의 dB는 완성본 대비 기여도입니다.", "".join(secs)))


# ---------------------------------------------------------------- ② 악기 옛것/새것
def build_instruments():
    ITEMS = [
        ("hits", "단타 — 궁편 ×3 · 채편 ×3 · 북 ×2",
         "옛것: 사인파 1개 + 잡음. 새것: 원형막 고유모드 16개 + 오동나무 통 공진 + 타격 접촉음."),
        ("jangdan", "굿거리 한 장단 ×2 (장구만)",
         "옛 채편은 520·1200Hz 고정 배음이 <b>매 타점마다 같은 선</b>으로 남습니다. 새것은 칠 때마다 타점 위치가 달라 모드 구성이 바뀝니다."),
        ("gayageum", "가야금 — 단음 3 + 짧은 악구",
         "현만 있고 <b>공명통이 없었습니다</b>. 오동나무 판 공진 5개와 손톱이 명주현을 뜯는 순간음을 넣었습니다."),
        ("geomungo", "거문고 — 단음 3 + 짧은 악구",
         "옛것은 <b>가야금에 저역 필터를 씌운 것</b>이었습니다. 거문고는 뜯는 악기가 아니라 <b>술대(대나무 채)로 때리는</b> 악기입니다. 술대가 대모를 치는 '탁' 소리부터 새로 썼습니다."),
    ]
    cards = "".join(
        f'<div class="pair"><h3>{lab}</h3><div class="two">'
        f'<div><div class="tag old">고치기 전</div>{au(f"ab/{k}_old.mp3")}</div>'
        f'<div><div class="tag new">새로 만든 것</div>{au(f"ab/{k}_new.mp3")}</div>'
        f'</div><div class="why">{why}</div></div>' for k, lab, why in ITEMS)
    write("악기_옛것새것.html", page(
        "악기 소리 다시 만들기 — 옛것 / 새것",
        "믹스에 묻히지 않게 <b>단독 타점과 짧은 악구</b>만 담았습니다.",
        '<div class="warn">이건 <b>녹음이 아니라 합성음</b>입니다. 실제 악기를 녹음한 소리가 아니라 '
        '물리 모형을 코드로 세워 만든 것이라, 아무리 다듬어도 진짜 장구·가야금·거문고와는 다릅니다.</div>' + cards))


# ---------------------------------------------------------------- ③ 합성음 vs 실샘플
def build_vs_sample():
    ROWS = [("가야금", "gaya_mine", "gaya_koto", "고토 (Koto, 일본 13현)",
             "가야금과 같은 치터 계열이라 가장 가깝습니다. 다만 <b>농현(왼손 흔들기)이 샘플에는 없습니다</b>."),
            ("대금", "wind_mine", "wind_shaku", "샤쿠하치 (Shakuhachi, 일본 세로피리)",
             "둘 다 대나무 피리지만 <b>대금의 청(갈대막) 울림이 없습니다</b>."),
            ("거문고", "geo_mine", "geo_shami", "샤미센 (Shamisen, 일본 3현)",
             "샤미센도 발목으로 때리는 악기라 타현 성격은 맞지만, 가죽 울림통이라 훨씬 건조합니다."),
            ("장구", "jang_mine", "jang_sample", "다이코 + 팀발레",
             "GM 규격에 장구가 없어 대체한 것입니다. <b>한 통을 두 가죽이 나눠 쓰는 장구의 울림</b>은 서로 다른 두 악기를 겹쳐서는 나오지 않습니다.")]
    cards = "".join(
        f'<div class="pair"><h3>{nm}</h3><div class="two">'
        f'<div><div class="tag syn">내 합성음</div>{au(f"sf/{a}.mp3")}</div>'
        f'<div><div class="tag smp">실제 녹음 — {alt}</div>{au(f"sf/{b}.mp3")}</div>'
        f'</div><div class="why">{why}</div></div>' for nm, a, b, alt, why in ROWS)
    write("합성음_vs_실샘플.html", page(
        "합성음 vs 실제 녹음 샘플",
        "같은 가락(아리랑 1~4마디)·같은 박자·같은 음량. 장구만 굿거리 두 장단입니다.",
        '<div class="warn">오른쪽은 <b>실제 악기를 녹음한 샘플</b>입니다(<code>fluid-soundfont-gm</code>). '
        '<b>그런데 전부 일본 악기입니다</b> — GM 규격에 국악기가 없어 고토·샤쿠하치·샤미센·다이코가 들어 있습니다.</div>'
        + cards))


# ---------------------------------------------------------------- ④ 샘플러 작동 확인
def build_sampler_proof():
    ROWS = [("마을 낮 · 아리랑", "village_day_ari"), ("원정 · 전통", "journey_trad")]
    cards = "".join(
        f'<div class="pair"><h3>{nm}</h3><div class="two">'
        f'<div><div class="tag syn">합성음</div>{au(f"sf/{k}_synth.mp3")}</div>'
        f'<div><div class="tag smp">샘플러를 거친 것 (대역 음원)</div>{au(f"sf/{k}_sampler.mp3")}</div>'
        f'</div></div>' for nm, k in ROWS)
    tbl = ('<div class="warn"><b>검증한 것</b><table>'
           '<tr><th>항목</th><th>결과</th></tr>'
           '<tr><td>음정 자동 검출 (파일명에 음이름 없이)</td><td>21음 <b>전부 정확</b></td></tr>'
           '<tr><td>임의 음높이 리샘플링 정확도</td><td>59음, <b>최대 오차 11.7센트</b></td></tr>'
           '<tr><td>장구 궁편/채편 자동 분리</td><td>밝기 기준으로 분리됨</td></tr>'
           '<tr><td>음원 없는 악기 → 합성음 자동 대체</td><td>단소·피리·북·징·꽹과리 유지됨</td></tr>'
           '<tr><td>곡 전체 렌더링</td><td>클리핑 0 · 길이·음량 기존과 동일</td></tr></table></div>')
    write("샘플러_작동확인.html", page(
        "샘플러 작동 확인",
        "음원이 들어오면 실제로 갈아끼워지는지 <b>대역 음원</b>으로 전 과정을 돌린 것입니다.",
        '<div class="warn">오른쪽은 <b>진짜 국악기가 아닙니다.</b> 국악 음원이 없어 사운드폰트를 폴더에 넣고 돌린 것입니다. '
        '여기서 볼 것은 <b>"폴더에 wav 를 넣으면 곡의 악기가 실제로 바뀌는가"</b> 입니다.</div>'
        + cards + tbl))


if __name__ == "__main__":
    build_layers()
    build_instruments()
    build_vs_sample()
    build_sampler_proof()

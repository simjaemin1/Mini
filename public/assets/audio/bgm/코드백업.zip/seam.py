import numpy as np, json
from scipy.io import wavfile
for nm in json.load(open("out/meta.json")):
    sr,d=wavfile.read(f"out/{nm}.wav"); x=d.astype(np.float32)/32768; m=x.mean(1)
    jump=float(np.abs(x[0]-x[-1]).max()); p=float(np.percentile(np.abs(np.diff(m)),99.99))
    w=int(sr*0.5); e=np.array([np.sqrt((m[i:i+w]**2).mean()) for i in range(0,len(m)-w,w)])
    print(f"{nm:20s} seam {jump:.4f} / step_p99 {p:.4f}   rms range {20*np.log10(e.min()+1e-9):6.1f}..{20*np.log10(e.max()+1e-9):6.1f} dB  clip {(np.abs(x)>0.999).sum()}")

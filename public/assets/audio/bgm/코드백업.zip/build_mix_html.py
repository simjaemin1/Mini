"""build_mix_html.py — 12곡 + 악기별 켜고 끄는 믹서를 하나의 HTML 로."""
import os
import json
import base64
import subprocess

OUT = "_mixmp3"
TITLES = [("village_day_trad", "마을 낮 · 전통"), ("village_day_amb", "마을 낮 · 앰비언트"),
          ("village_day_ari", "마을 낮 · 아리랑"),
          ("village_night_trad", "마을 밤 · 전통"), ("village_night_amb", "마을 밤 · 앰비언트"),
          ("village_night_ari", "마을 밤 · 아리랑"),
          ("battle_trad", "전투 · 전통"), ("battle_amb", "전투 · 앰비언트"),
          ("battle_ari", "전투 · 아리랑"),
          ("journey_trad", "원정 · 전통"), ("journey_amb", "원정 · 앰비언트"),
          ("journey_ari", "원정 · 아리랑")]
NOTE = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
nm = lambda m: f"{NOTE[int(round(m)) % 12]}{int(round(m)) // 12 - 1}"


def mp3(src, dst, kbps, mono=True, secs=None):
    cmd = ["ffmpeg", "-v", "error", "-y", "-i", src]
    if secs:
        cmd += ["-t", str(secs)]
    cmd += ["-c:a", "libmp3lame", "-b:a", f"{kbps}k"]
    if mono:
        cmd += ["-ac", "1"]
    cmd += [dst]
    subprocess.run(cmd, check=True)
    return dst


def b64(p):
    return "data:audio/mpeg;base64," + base64.b64encode(open(p, "rb").read()).decode()


def main():
    os.makedirs(OUT, exist_ok=True)
    man = json.load(open("stems/_manifest.json"))
    meta = json.load(open("out_samples/meta.json"))
    score = json.load(open("score.json"))

    use = {}
    for notes in score.values():
        for e in notes:
            use[e["inst"]] = use.get(e["inst"], 0) + 1
    real = {k for k, v in meta["source"].items() if v == "샘플"}
    inst_ko = {"gayageum": "가야금", "danso": "단소", "daegeum": "대금", "piri": "피리",
               "geomungo": "거문고", "janggu_gung": "장구 궁편", "janggu_chae": "장구 채편",
               "buk": "북", "jing": "징", "kkwaenggwari": "꽹과리", "bak": "박"}
    rows = "".join(
        f'<tr><td>{inst_ko.get(i,i)}</td><td class="n">{n}</td>'
        f'<td class="{"ok" if i in real else "no"}">'
        f'{"국립국악원 실제 녹음" if i in real else "합성음"}</td></tr>'
        for i, n in sorted(use.items(), key=lambda t: -t[1]))

    blocks = []
    for k, title in TITLES:
        full = f"out_samples/{k}.wav"
        if not os.path.exists(full):
            continue
        fp = mp3(full, f"{OUT}/{k}_full.mp3", 96, mono=False, secs=36)
        layers = man.get(k, [])
        chs, auds = [], []
        for key, label, db in layers:
            sp = f"stems/{k}__{key}.wav"
            if not os.path.exists(sp):
                continue
            m = mp3(sp, f"{OUT}/{k}_{key}.mp3", 56, mono=True)
            chs.append(f'<button class="ch on" data-k="{key}">{label}'
                       f'<span class="db">{db:+.0f}dB</span></button>')
            auds.append(f'<audio data-st="{key}" src="{b64(m)}"></audio>')
        mixer = ""
        if chs:
            mixer = (f'<div class="mix"><div class="mixhead">악기별 켜고 끄기 '
                     f'— 재생 중에 눌러도 됩니다 (10~32초 구간)</div>'
                     f'<div class="chs">{"".join(chs)}</div>{"".join(auds)}'
                     f'<div class="ctl"><button class="play">재생</button>'
                     f'<button class="all">전부 켜기</button>'
                     f'<span class="st">멈춤</span></div></div>')
        t = meta["tracks"].get(k, {})
        octs = " · ".join(f"{a} {b:+d}옥타브" for a, b in (t.get("octaves") or {}).items())
        blocks.append(
            f'<div class="tr"><div class="th"><b>{title}</b>'
            f'<span class="sub">{t.get("seconds","?")}초</span></div>'
            f'<audio controls preload="none" src="{b64(fp)}"></audio>'
            + (f'<div class="meta">성부 이동: {octs}</div>' if octs else '')
            + mixer + '</div>')

    tun = ""
    for root, label in [("samples_gaya", "산조가야금"), ("samples_geomungo", "정악거문고"),
                        ("samples_daegeum", "산조대금"), ("samples_piri", "향피리"),
                        ("samples_danso", "단소"), ("samples_janggu", "장구"),
                        ("samples_jing", "징"), ("samples_kkwaenggwari", "꽹과리"),
                        ("samples_buk", "좌고"), ("samples_bak", "박")]:
        p = f"{root}/_index.json"
        if not os.path.exists(p):
            continue
        idx = json.load(open(p))
        import sampler as SP
        arts = {}
        for e in idx["entries"]:
            arts[e.get("art")] = arts.get(e.get("art"), 0) + 1
        al = ", ".join(f"{SP.ART_NAME_KO.get(a,a)} {c}"
                       for a, c in sorted(arts.items(), key=lambda x: -x[1])[:6])
        t = list(idx.get("tuning", {}).values())
        line = ""
        if t and t[0].get("strings"):
            s = t[0]
            line = (f' · 조율 <code>{" ".join(nm(x) for x in s["strings"])}</code>'
                    f' (전역 {s["offset_semi"]*100:+.0f}센트)')
        tun += f'<tr><td>{label}</td><td class="n">{len(idx["entries"])}</td><td>{al}{line}</td></tr>'

    html = f"""<!doctype html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>두랑고 BGM — 국악기 실음원판</title><style>
:root{{--bg:#12100e;--fg:#efe7db;--dim:#a99a86;--line:#332c25;--acc:#d8a25a;--acc2:#6fa8b8}}
*{{box-sizing:border-box}}
body{{margin:0;background:var(--bg);color:var(--fg);font:15px/1.65 -apple-system,BlinkMacSystemFont,"Apple SD Gothic Neo","Noto Sans KR",sans-serif}}
.wrap{{max-width:860px;margin:0 auto;padding:26px 18px 80px}}
h1{{font-size:24px;margin:0 0 6px}}
h2{{font-size:17px;margin:34px 0 8px;padding-bottom:6px;border-bottom:1px solid var(--line)}}
.lead{{color:var(--dim);margin:0 0 18px}}
.tr{{border:1px solid var(--line);border-radius:10px;padding:12px 14px;margin:12px 0;background:#181410}}
.th{{display:flex;gap:9px;align-items:baseline;margin-bottom:9px}}
.sub{{color:var(--dim);font-size:12px}}
audio[controls]{{width:100%;height:34px}}
audio[data-st]{{display:none}}
.meta{{color:var(--dim);font-size:12px;margin-top:7px}}
.mix{{margin-top:11px;padding:11px;border:1px solid var(--acc2);border-radius:9px;background:#141b1d}}
.mixhead{{font-size:12px;color:var(--dim);margin-bottom:9px}}
.chs{{display:flex;gap:6px;flex-wrap:wrap}}
.ch{{padding:8px 12px;border-radius:8px;border:1px solid var(--line);background:#1b1512;
 color:var(--dim);font-size:13px;cursor:pointer;font-family:inherit;display:flex;gap:7px;align-items:center}}
.ch.on{{background:var(--acc2);color:#0d1416;border-color:var(--acc2);font-weight:700}}
.ch .db{{font-size:11px;opacity:.75}}
.ctl{{margin-top:9px;display:flex;gap:9px;align-items:center}}
.play,.all{{padding:6px 15px;border-radius:7px;border:1px solid var(--acc);background:transparent;
 color:var(--acc);cursor:pointer;font-family:inherit;font-size:13px}}
.st{{color:var(--dim);font-size:12px}}
table{{border-collapse:collapse;font-size:13px;width:100%;margin:8px 0}}
th,td{{border:1px solid var(--line);padding:4px 9px;text-align:left;vertical-align:top}}
th{{color:var(--dim);font-weight:400}}
td.n{{text-align:right}} td.ok{{color:#7fd08a}} td.no{{color:#a99a86}}
.note{{color:var(--dim);font-size:12.5px;margin:4px 0}}
code{{font-size:11.5px}}
footer{{margin-top:40px;padding-top:14px;border-top:1px solid var(--line);color:var(--dim);font-size:12.5px}}
</style></head><body><div class="wrap">
<h1>두랑고 BGM — 국악기 실음원판</h1>
<p class="lead">12곡 전부, 악기 11종 전부 국립국악원 실제 녹음입니다.
곡에 쓰인 음 <b>7086개 중 합성음은 0개</b>입니다.
곡마다 <b>악기별로 켜고 끌 수</b> 있습니다.</p>

<h2>악기 현황</h2>
<table><tr><th>악기</th><th>쓰인 음</th><th>소리 출처</th></tr>{rows}</table>

<h2>음원</h2>
<table><tr><th>악기</th><th>조각</th><th>주법 · 조율</th></tr>{tun}</table>
<p class="note">조율은 검출값을 '전역 오프셋 + 정수 반음' 으로 풀어 확정한 것입니다.
산조가야금은 A≈446Hz 로 조율된 C 평조 12현이라, 곡의 조를 여기 맞춰 옮겼습니다
(평조는 으뜸음 G, 계면조는 A 일 때 12현에 그대로 얹힙니다).
그 결과 음정을 억지로 늘리는 양이 최대 2.32 → 0.52반음으로 줄었습니다.</p>

<h2>12곡</h2>
{''.join(blocks)}

<footer>국악기 음원 제공 — 국립국악원 (공공누리 제1유형)<br>
믹서의 dB 는 완성본 대비 그 층의 기여도입니다. 층은 정규화 없이 뽑아서 실제 음량 비가 보존됩니다.</footer>
</div>
<script>
document.querySelectorAll('.tr').forEach(function(box){{
  var mix=box.querySelector('.mix'); if(!mix) return;
  var A={{}}, playing=false;
  mix.querySelectorAll('audio[data-st]').forEach(function(a){{ A[a.dataset.st]=a; a.loop=true; }});
  var st=mix.querySelector('.st'), pb=mix.querySelector('.play');
  function setv(){{ mix.querySelectorAll('.ch').forEach(function(c){{
    var a=A[c.dataset.k]; if(a) a.volume=c.classList.contains('on')?1:0; }}); }}
  mix.querySelectorAll('.ch').forEach(function(c){{
    c.onclick=function(){{ c.classList.toggle('on'); setv(); }}; }});
  mix.querySelector('.all').onclick=function(){{
    mix.querySelectorAll('.ch').forEach(function(c){{ c.classList.add('on'); }}); setv(); }};
  pb.onclick=function(){{
    var xs=Object.values(A);
    if(playing){{ xs.forEach(function(a){{a.pause();}}); playing=false;
      pb.textContent='재생'; st.textContent='멈춤'; }}
    else {{ xs.forEach(function(a){{ a.currentTime=0; }}); setv();
      Promise.all(xs.map(function(a){{return a.play();}})).then(function(){{
        playing=true; pb.textContent='정지'; st.textContent='재생 중'; }})
        .catch(function(e){{ st.textContent='재생 실패'; }}); }}
  }};
}});
</script></body></html>"""
    p = "두랑고BGM_통합.html"
    open(p, "w").write(html)
    print(f"{p}  {os.path.getsize(p)/1e6:.1f}MB  트랙 {len(blocks)}개")


if __name__ == "__main__":
    main()

"""build2.py — 새 12곡 + 악기별 켜고 끄기 + 무엇이 달라졌는지, 한 화면에."""
import os, json, base64, subprocess
import compose as C, tracks2 as T, sampler as S

OUT = "_m2"
KIND = {"G": "덩", "g": "쿵", "c": "덕", "d": "더", "i": "기덕", "r": "더러러러"}
SCENE_NOTE = {
    "village_day": ("굿거리 · G 평조", "치 우 궁′ / 우 치 각 궁 — 올라가 붙들고, 내려와 맺는다"),
    "village_night": ("진양조 · A 계면조", "낮의 주제를 <b>뒤집고 배로 늘인 것</b>. 같은 얼굴의 다른 표정"),
    "battle": ("자진모리→휘모리 · A 계면조", "주제의 머리 두 음만 남기고 조여서 몰아친다"),
    "journey": ("세마치 · G 평조", "걷는 걸음. 궁에서 나가 궁으로 돌아온다"),
}


def mp3(src, dst, k, mono=False, secs=None):
    cmd = ["ffmpeg", "-v", "error", "-y", "-i", src]
    if secs:
        cmd += ["-t", str(secs)]
    cmd += ["-c:a", "libmp3lame", "-b:a", f"{k}k"] + (["-ac", "1"] if mono else []) + [dst]
    subprocess.run(cmd, check=True)
    return dst


def b64(p):
    return "data:audio/mpeg;base64," + base64.b64encode(open(p, "rb").read()).decode()


def main():
    os.makedirs(OUT, exist_ok=True)
    man = json.load(open("stems/_manifest.json"))
    meta = json.load(open("out_samples/meta.json"))

    gu = {}
    for jd, (ncy, pat) in C.JANGDAN.items():
        g = ["·"] * ncy
        for p, k, _ in pat:
            g[int(p)] = KIND[k]
        gu[jd] = " ".join("".join(g[i:i + 3]) for i in range(0, ncy, 3))

    blocks = []
    for scene in T.SCENES:
        jd_ko, theme = SCENE_NOTE[scene]
        jd = T._scene(scene)["jangdan"]
        sob, _ = C.TEMPO[jd]
        cards = []
        for mood in T.MOODS:
            k = f"{scene}_{mood}"
            p = f"out_samples/{k}.wav"
            if not os.path.exists(p):
                continue
            fp = mp3(p, f"{OUT}/{k}.mp3", 80, secs=34)
            chs, auds = [], []
            for gk, label, db in man.get(k, []):
                sp = f"stems/{k}__{gk}.wav"
                if not os.path.exists(sp):
                    continue
                m = mp3(sp, f"{OUT}/{k}_{gk}.mp3", 44, mono=True)
                chs.append(f'<button class="ch on" data-k="{gk}">{label}'
                           f'<span class="db">{db:+.0f}dB</span></button>')
                auds.append(f'<audio data-st="{gk}" src="{b64(m)}"></audio>')
            mixer = ""
            if chs:
                mixer = (f'<div class="mix"><div class="mixhead">악기별 켜고 끄기 — '
                         f'재생 중에 눌러도 됩니다 (8~34초 구간)</div>'
                         f'<div class="chs">{"".join(chs)}</div>{"".join(auds)}'
                         f'<div class="ctl"><button class="play">재생</button>'
                         f'<button class="all">전부 켜기</button>'
                         f'<span class="st">멈춤</span></div></div>')
            t = meta["tracks"].get(k, {})
            cards.append(f'<div class="tr"><div class="th"><b>{T.KO_M[mood]}</b>'
                         f'<span class="sub">{t.get("seconds","?")}초</span></div>'
                         f'<audio controls preload="none" src="{b64(fp)}"></audio>'
                         f'{mixer}</div>')
        blocks.append(
            f'<h2>{T.KO_S[scene]}</h2>'
            f'<p class="note">{jd_ko} · 소박 {sob*1000:.0f}ms · 한 주기 '
            f'{C.JANGDAN[jd][0]*sob:.2f}초<br>장단 <b class="gu">{gu[jd]}</b><br>주제 — {theme}</p>'
            + "".join(cards))

    html = f"""<!doctype html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>두랑고 BGM — 다시 쓴 12곡</title><style>
:root{{--bg:#12100e;--fg:#efe7db;--dim:#a99a86;--line:#332c25;--acc:#d8a25a;--acc2:#6fa8b8}}
*{{box-sizing:border-box}}
body{{margin:0;background:var(--bg);color:var(--fg);font:15px/1.65 -apple-system,BlinkMacSystemFont,"Apple SD Gothic Neo","Noto Sans KR",sans-serif}}
.wrap{{max-width:860px;margin:0 auto;padding:26px 18px 80px}}
h1{{font-size:24px;margin:0 0 6px}}
h2{{font-size:18px;margin:34px 0 6px;padding-bottom:6px;border-bottom:1px solid var(--line);color:var(--acc)}}
.lead{{color:var(--dim);margin:0 0 18px}}
.tr{{border:1px solid var(--line);border-radius:10px;padding:12px 14px;margin:10px 0;background:#181410}}
.th{{display:flex;gap:9px;align-items:baseline;margin-bottom:9px}} .th b{{color:var(--acc)}}
.sub{{color:var(--dim);font-size:12px}}
audio[controls]{{width:100%;height:34px}} audio[data-st]{{display:none}}
.mix{{margin-top:11px;padding:11px;border:1px solid var(--acc2);border-radius:9px;background:#141b1d}}
.mixhead{{font-size:12px;color:var(--dim);margin-bottom:9px}}
.chs{{display:flex;gap:6px;flex-wrap:wrap}}
.ch{{padding:8px 12px;border-radius:8px;border:1px solid var(--line);background:#1b1512;
 color:var(--dim);font-size:13px;cursor:pointer;font-family:inherit;display:flex;gap:7px;align-items:center}}
.ch.on{{background:var(--acc2);color:#0d1416;border-color:var(--acc2);font-weight:700}}
.ch .db{{font-size:11px;opacity:.75}}
.ctl{{margin-top:9px;display:flex;gap:9px;align-items:center}}
.play,.all{{padding:6px 15px;border-radius:7px;border:1px solid var(--acc);background:transparent;
 color:var(--acc);cursor:pointer;font-family:inherit;font-size:13px}}
.st{{color:var(--dim);font-size:12px}}
.note{{color:var(--dim);font-size:12.5px;margin:4px 0 10px}}
.gu{{color:var(--acc);letter-spacing:.08em;font-size:14px}}
.how{{border:1px solid #2f4a52;border-left:3px solid var(--acc2);border-radius:8px;
 background:#101a1d;padding:12px 15px;margin:16px 0;font-size:13px;color:#cfdde1}}
.how b{{color:var(--acc2)}} .how ol{{margin:8px 0 0;padding-left:20px}} .how li{{margin:6px 0}}
table{{border-collapse:collapse;font-size:13px;width:100%;margin:8px 0}}
th,td{{border:1px solid var(--line);padding:4px 9px;text-align:left}}
th{{color:var(--dim);font-weight:400}} td.n{{text-align:right}}
footer{{margin-top:40px;padding-top:14px;border-top:1px solid var(--line);color:var(--dim);font-size:12.5px}}
</style></head><body><div class="wrap">
<h1>두랑고 BGM — 다시 쓴 12곡</h1>
<p class="lead">장면 4 × 결 3. 음 <b>{meta.get('notes','?')}개 중 합성음 0개</b>,
전부 국립국악원 실제 녹음입니다. 곡마다 악기별로 켜고 끌 수 있습니다.</p>

<div class="how"><b>예전 판과 무엇이 다른가</b>
<ol>
<li><b>선율을 골격과 잔가락으로 짭니다.</b> 처음엔 서양식으로 주제를 정해 A–A′–B–A″ 로
되풀이했는데, 들머리 두 주기가 음 두 개뿐이라 비었고 같은 머리가 29% 의 주기에서 똑같이 나왔습니다.
산조에는 '한 주제를 네 번 되풀이하는 A 단락' 이 없습니다. 있는 것은
<b>골격</b>(한 장단에 두세 음, 어디로 가는지를 정하는 큰 음)과
<b>잔가락</b>(그 사이를 메우는 잘고 빠른 가락)이고, 정체는 골격이 지키고 잔가락은 매번 다릅니다.
지금은 <b>똑같은 주기가 0개</b>, 머리 세 음이 겹치는 비율도 8~13% 입니다.</li>
<li><b>긴 음이 실제로 이어집니다.</b> 예전에는 음원보다 긴 음을 요청받으면 뒤에 무음을 덧대고
페이드해서, 관악기가 숨을 놓듯 도중에 사그라들었습니다(대금 17%·단소 28% 의 음이 그랬고
모자란 양 중앙값 0.6초). 이제 지속 구간을 크로스페이드로 이어 붙여 늘립니다 —
합성이 아니라 <b>그 녹음의 지속부를 되풀이</b>하는 것이라 음색은 그대로입니다.</li>
<li><b>악기를 자료에 맞춰 배치했습니다.</b> 대금은 합주의 조율 기준(서양 관현악의 오보에 자리)이라
주선율, 향피리는 겹서라 음량이 커서 야외·행진 음악(삼현육각)의 주선율이라 전투,
단소는 줄풍류의 악기라 조용한 자리와 응답, 거문고는 술대로 때리는 악기라 골격과 저음입니다.
시김새 문법도 <b>그 악기 이름으로</b> 묻습니다 — 전투의 피리에게 대금 어휘를 물었더니
피리에 없는 주법이라 어림잡기로 떨어져 끊어치기 12개짜리 녹음이 451번 되풀이됐습니다.</li>
<li><b>시김새를 문법으로 겁니다.</b> 국악에서 변주는 음을 바꾸는 게 아니라 같은 음을
어떻게 흔들고 밀고 꺾느냐입니다. 긴 음은 깊은 농현, 정점은 청성, 맺음은 퇴성, 도약은 추성,
반복은 굴림, 거문고 대박은 슬기둥 — 값이 아니라 <b>어느 녹음을 꺼낼지</b>를 지정합니다.</li>
<li><b>장단을 자료에 맞춰 다시 짰습니다.</b> 겹채(기덕)의 본타가 박에 오도록 당기고
(+93~145ms → +3ms), 3소박 장단에 얹혀 있던 스윙을 뺐습니다.
세마치·휘모리의 둘째 박은 궁편이 아니라 양손 합장단입니다.</li>
<li><b>조와 옥타브를 음원에서 계산합니다.</b> 악기가 실제로 가진 음을 재서
억지로 늘리는 양이 가장 적은 자리를 고릅니다. 거문고만 베이스로 쓰려고 1반음을 양보했습니다.</li>
<li><b>잔향을 껐습니다.</b> 임펄스 응답을 봉우리로 정규화하는 바람에 잔향이 마른 소리보다
+15.8dB 컸던 것을 고치고(에너지 정규화), 세기는 0으로 두었습니다.</li>
</ol></div>

{''.join(blocks)}

<footer>국악기 음원 제공 — 국립국악원 (공공누리 제1유형)<br>
장단 배열 출처 — 위키백과 「장단」 · 이보형 「韓國民俗音樂 長短의 리듬型에 관한 硏究」(서울대)<br>
믹서의 dB 는 완성본 대비 그 층의 기여도입니다. 층은 정규화 없이 뽑아 실제 음량 비가 보존됩니다.</footer>
</div>
<script>
document.querySelectorAll('.tr').forEach(function(box){{
  var mix=box.querySelector('.mix'); if(!mix) return;
  var A={{}}, playing=false;
  mix.querySelectorAll('audio[data-st]').forEach(function(a){{ A[a.dataset.st]=a; a.loop=true; }});
  var st=mix.querySelector('.st'), pb=mix.querySelector('.play');
  function setv(){{ mix.querySelectorAll('.ch').forEach(function(c){{
    var a=A[c.dataset.k]; if(a) a.volume=c.classList.contains('on')?1:0; }}); }}
  mix.querySelectorAll('.ch').forEach(function(c){{
    c.onclick=function(){{ c.classList.toggle('on'); setv(); }}; }});
  mix.querySelector('.all').onclick=function(){{
    mix.querySelectorAll('.ch').forEach(function(c){{ c.classList.add('on'); }}); setv(); }};
  pb.onclick=function(){{
    var xs=Object.values(A);
    if(playing){{ xs.forEach(function(a){{a.pause();}}); playing=false;
      pb.textContent='재생'; st.textContent='멈춤'; }}
    else {{ xs.forEach(function(a){{ a.currentTime=0; }}); setv();
      Promise.all(xs.map(function(a){{return a.play();}})).then(function(){{
        playing=true; pb.textContent='정지'; st.textContent='재생 중'; }})
        .catch(function(e){{ st.textContent='재생 실패'; }}); }}
  }};
}});
</script></body></html>"""
    p = "두랑고BGM_통합.html"
    open(p, "w").write(html)
    print(f"{p}  {os.path.getsize(p)/1e6:.1f}MB")


if __name__ == "__main__":
    main()

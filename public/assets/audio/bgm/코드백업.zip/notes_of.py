"""
notes_of.py — 소리를 만들지 않고 **악보만** 뽑는다.

조를 하나 바꿀 때마다 12곡을 4분씩 렌더하면 시행착오가 불가능하다.
악기 함수를 '길이 1의 무음' 으로 바꿔치고 호출만 기록하면 같은 정보를 몇 초에 얻는다.

    python3 notes_of.py            # score.json 생성
"""
import sys
import json
import numpy as np

import gugak as G

PITCHED = ["gayageum", "geomungo", "daegeum", "danso", "piri", "haegeum", "ajaeng"]
PERC = ["janggu_gung", "janggu_chae", "buk", "jing", "kkwaenggwari", "bak"]
OTHER = ["pad", "wind", "water", "crickets", "flute"]


def collect(names=None):
    log, orig = [], {}

    def wrap_pitched(name):
        def f(freq, dur, amp=1.0, **kw):
            log.append(dict(inst=name, freq=float(freq), dur=float(dur), amp=float(amp),
                            nong=float(kw.get("vib_cents", kw.get("nonghyeon", 0)) or 0),
                            bend=float(kw.get("bend_end", kw.get("bend", 0)) or 0)))
            return np.zeros(1, np.float32)
        return f

    def wrap_perc(name):
        def f(dur=0.5, amp=1.0, **kw):
            log.append(dict(inst=name, freq=None, dur=float(dur), amp=float(amp)))
            return np.zeros(1, np.float32)
        return f

    for n in PITCHED:
        orig[n] = getattr(G, n, None)
        if orig[n]:
            setattr(G, n, wrap_pitched(n))
    for n in PERC:
        orig[n] = getattr(G, n, None)
        if orig[n]:
            setattr(G, n, wrap_perc(n))
    for n in OTHER:
        orig[n] = getattr(G, n, None)
        if orig[n]:
            setattr(G, n, lambda *a, **k: np.zeros(1, np.float32))

    orig_render = G.Mix.render
    G.Mix.render = lambda self, *a, **k: np.zeros((2, 2), np.float32)
    try:
        import importlib
        import compose as C
        import arirang as A
        importlib.reload(C)
        importlib.reload(A)
        allt = {**C.TRACKS, **A.ARI_TRACKS}
        names = names or list(allt)
        score = {}
        for nm in names:
            log.clear()
            allt[nm]["fn"](allt[nm])
            score[nm] = [dict(e) for e in log]
        return score
    finally:
        for n, f in orig.items():
            if f:
                setattr(G, n, f)
        G.Mix.render = orig_render


if __name__ == "__main__":
    from collections import defaultdict
    score = collect(sys.argv[1:] or None)
    json.dump(score, open("score.json", "w"))
    per = defaultdict(lambda: defaultdict(int))
    for nm, notes in score.items():
        for e in notes:
            per[nm][e["inst"]] += 1
    insts = sorted({i for v in per.values() for i in v})
    print(f"{'곡':20s}" + "".join(f"{i[:8]:>9s}" for i in insts))
    print("-" * (20 + 9 * len(insts)))
    tot = {i: 0 for i in insts}
    for nm in score:
        print(f"{nm:20s}" + "".join(f"{per[nm].get(i,0):9d}" for i in insts))
        for i in insts:
            tot[i] += per[nm].get(i, 0)
    print("-" * (20 + 9 * len(insts)))
    print(f"{'합계':20s}" + "".join(f"{tot[i]:9d}" for i in insts))
    print(f"\n음 {sum(tot.values())}개 · score.json 저장")

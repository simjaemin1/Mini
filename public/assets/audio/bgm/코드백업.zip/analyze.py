import numpy as np, json, os
from scipy.io import wavfile
from scipy import signal as sps
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

names=list(json.load(open("out/meta.json")))
fig,axes=plt.subplots(4,2,figsize=(17,13))
rep=[]
for ax,nm in zip(axes.ravel(),names):
    sr,d=wavfile.read(f"out/{nm}.wav"); x=d.astype(np.float32)/32768
    m=x.mean(1)
    f,t,S=sps.spectrogram(m,sr,nperseg=2048,noverlap=1024)
    S=10*np.log10(S+1e-12)
    ax.pcolormesh(t,f,S,shading='auto',vmin=-110,vmax=-30,cmap='magma')
    ax.set_yscale('symlog',linthresh=200); ax.set_ylim(40,12000)
    ax.set_title(nm,fontsize=9); ax.set_xlabel(''); ax.set_ylabel('')
    # 이음매 불연속: 마지막 샘플 -> 첫 샘플 점프를 인접 샘플 점프 분포와 비교
    jump=np.abs(x[0]-x[-1]).max()
    dmax=np.percentile(np.abs(np.diff(m)),99.99)
    # 무음 구간 검사
    win=int(sr*0.5); e=np.array([np.sqrt((m[i:i+win]**2).mean()) for i in range(0,len(m)-win,win)])
    rep.append(dict(name=nm,secs=round(len(m)/sr,2),
        seam_jump=round(float(jump),5), typical_step_p99=round(float(dmax),5),
        min_halfsec_rms_db=round(float(20*np.log10(e.min()+1e-9)),1),
        max_halfsec_rms_db=round(float(20*np.log10(e.max()+1e-9)),1),
        clipped=int((np.abs(x)>0.999).sum()),
        lowfreq_pct=round(float(np.mean(np.abs(np.fft.rfftfreq(len(m),1/sr)[:0])) if False else 0),1)))
plt.tight_layout(); plt.savefig("out/spectrograms.png",dpi=85)
print(json.dumps(rep,indent=1,ensure_ascii=False))

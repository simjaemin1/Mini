"""
ab_sample.py — 내 합성음 vs 실제 녹음 샘플(사운드폰트) 3종 비교

사운드폰트: FluidR3_GM.sf2 (apt `fluid-soundfont-gm`, 실제 악기를 녹음한 샘플)
단, 국악기는 GM 규격에 없다. 가장 가까운 것이:
  가야금 → 고토(Koto, 일본 13현)      prog 107
  대금   → 샤쿠하치(Shakuhachi, 일본) prog 77
  거문고 → 샤미센(Shamisen, 일본)     prog 106
  장구   → 다이코 + 팀발레            prog 116 / 타악 65
같은 가락·같은 박자로 나란히 놓아 판단할 수 있게 한다.
"""
import os
import numpy as np
import mido
import gugak as G
from arirang import ARIRANG, ari_f, ari_midi

SF = "/usr/share/sounds/sf2/FluidR3_GM.sf2"
DO = 70              # Bb4
BEAT = 0.72
BARS = 4
TPB = 480
BPM = 60.0 / BEAT    # 한 박 = BEAT 초


def _phrase():
    """아리랑 1~4마디를 (시각초, 길이초, midi) 로."""
    out = []
    for b in range(BARS):
        for (t, d, n) in ARIRANG[b]:
            out.append((b * 3 * BEAT + t * BEAT, d * BEAT, ari_midi(DO, n)))
    return out


GUT = [(0, "G", 1.0), (2, "c", .42), (2.5, "c", .34), (3, "g", .72),
       (4, "c", .40), (5, "c", .30), (5.5, "c", .26), (6, "g", .85),
       (8, "c", .42), (8.5, "c", .34), (9, "g", .62), (10, "c", .38),
       (11, "c", .30), (11.5, "c", .26)]
SOB = 0.40


def _jangdan():
    out = []
    rng = np.random.default_rng(7)
    for cyc in range(2):
        t0 = 0.25 + cyc * 12 * SOB
        for pos, kind, v in GUT:
            t = t0 + pos * SOB + rng.normal(0, 0.008)
            vv = v * (0.93 + 0.14 * rng.random())
            out.append((t, kind, vv))
    return out


# ---------------------------------------------------------------- 샘플 쪽
def midi_render(name, events, prog, channel=0, vel=100, drum=False):
    """events: [(시각초, 길이초, midi)] → MIDI 저장 후 fluidsynth 로 렌더."""
    mf = mido.MidiFile(ticks_per_beat=TPB)
    tr = mido.MidiTrack()
    mf.tracks.append(tr)
    tr.append(mido.MetaMessage('set_tempo', tempo=mido.bpm2tempo(BPM), time=0))
    if not drum:
        tr.append(mido.Message('program_change', channel=channel, program=prog, time=0))
    sec2tick = lambda s: int(round(s / BEAT * TPB))
    ev = []
    for (t, d, n) in events:
        v = vel if len(str(n)) else vel
        ev.append((sec2tick(t), 'note_on', n, v))
        ev.append((sec2tick(t + d), 'note_off', n, 0))
    ev.sort(key=lambda e: (e[0], e[1] == 'note_on'))
    prev = 0
    for tick, kind, n, v in ev:
        tr.append(mido.Message(kind, channel=channel, note=int(n),
                               velocity=int(v), time=max(0, tick - prev)))
        prev = tick
    mf.save(f"sf/{name}.mid")
    os.system(f'fluidsynth -ni -F sf/{name}.wav -r 44100 -g 1.1 "{SF}" sf/{name}.mid '
              f'>/dev/null 2>&1')
    from scipy.io import wavfile
    sr, d = wavfile.read(f"sf/{name}.wav")
    x = (d.astype(np.float32) / 32768).T
    if x.shape[0] == 1:
        x = np.vstack([x, x])
    return x


def midi_render_multi(name, tracks):
    """tracks: [(채널, 프로그램, drum?, [(t,d,n,vel)])]"""
    mf = mido.MidiFile(ticks_per_beat=TPB)
    tr = mido.MidiTrack()
    mf.tracks.append(tr)
    tr.append(mido.MetaMessage('set_tempo', tempo=mido.bpm2tempo(BPM), time=0))
    sec2tick = lambda s: int(round(s / BEAT * TPB))
    ev = []
    for ch, prog, drum, notes in tracks:
        if not drum:
            tr.append(mido.Message('program_change', channel=ch, program=prog, time=0))
        for (t, d, n, v) in notes:
            ev.append((sec2tick(t), 'note_on', ch, n, v))
            ev.append((sec2tick(t + d), 'note_off', ch, n, 0))
    ev.sort(key=lambda e: (e[0], e[2] == 'note_on'))
    prev = 0
    for tick, kind, ch, n, v in ev:
        tr.append(mido.Message(kind, channel=ch, note=int(n), velocity=int(v),
                               time=max(0, tick - prev)))
        prev = tick
    mf.save(f"sf/{name}.mid")
    os.system(f'fluidsynth -ni -F sf/{name}.wav -r 44100 -g 1.1 "{SF}" sf/{name}.mid '
              f'>/dev/null 2>&1')
    from scipy.io import wavfile
    sr, d = wavfile.read(f"sf/{name}.wav")
    x = (d.astype(np.float32) / 32768).T
    if x.shape[0] == 1:
        x = np.vstack([x, x])
    return x


# ---------------------------------------------------------------- 내 합성 쪽
RV = G.Reverb(dur=2.0, decay=1.0, pre=0.012, damp=4800, seed=5)


def bake(events, dur, wet=0.30):
    mix = G.Mix(dur, tail=2.0)
    for y, at, g, pan in events:
        mix.add(y, at, g, pan, 0.30)
    return mix.render(RV, wet=wet, loop=False, target_db=-17.0,
                      eq=dict(low_db=-2.0, mud_db=-1.0, pres_db=1.5, air_db=2.0, hpf=35))


def mine_gaya():
    e = [(G.gayageum(G.mtof(n), max(1.6, d * 1.6), 1.0,
                     nonghyeon=(20 if d >= 1.0 else 0), seed=200 + i), t, 0.9, 0.0)
         for i, (t, d, n) in enumerate(_phrase())]
    return bake(e, BARS * 3 * BEAT + 2.0)


def mine_daegeum():
    e = [(G.daegeum(G.mtof(n), d * 0.95, 1.0, vib_cents=(32 if d >= 0.7 else 18),
                    seed=300 + i), t, 0.85, 0.0)
         for i, (t, d, n) in enumerate(_phrase())]
    return bake(e, BARS * 3 * BEAT + 2.0)


def mine_geomungo():
    e = [(G.geomungo(G.mtof(n - 24), max(1.6, d * 1.6), 1.0, seed=400 + i), t, 0.9, 0.0)
         for i, (t, d, n) in enumerate(_phrase())]
    return bake(e, BARS * 3 * BEAT + 2.0)


def mine_jangdan():
    e = []
    rng = np.random.default_rng(11)
    for t, kind, v in _jangdan():
        sd = int(rng.integers(1 << 20))
        if kind in ("G", "g"):
            e.append((G.janggu_gung(1.0, 1.0, seed=sd,
                                    strike=0.28 + 0.12 * rng.random()), t, v, -0.18))
        if kind in ("G", "c"):
            e.append((G.janggu_chae(0.5, 1.0, seed=sd + 1,
                                    strike=0.62 + 0.18 * rng.random()), t,
                      v * (0.75 if kind == "G" else 1.0), 0.22))
    return bake(e, 0.25 + 24 * SOB + 1.4)


def norm(x, target_db=-17.0):
    r = np.sqrt(np.mean(x ** 2) + 1e-12)
    x = x * (10 ** (target_db / 20)) / r
    pk = np.max(np.abs(x)) + 1e-9
    return (x * min(1.0, 10 ** (-1.0 / 20) / pk)).astype(np.float32)


if __name__ == "__main__":
    os.makedirs("sf", exist_ok=True)
    ph = _phrase()

    G.write_wav("sf/gaya_mine.wav", mine_gaya())
    G.write_wav("sf/gaya_koto.wav", norm(midi_render("koto_ph", ph, 107)))

    G.write_wav("sf/wind_mine.wav", mine_daegeum())
    G.write_wav("sf/wind_shaku.wav", norm(midi_render("shaku_ph", ph, 77)))

    G.write_wav("sf/geo_mine.wav", mine_geomungo())
    G.write_wav("sf/geo_shami.wav",
                norm(midi_render("shami_ph", [(t, d, n - 24) for t, d, n in ph], 106)))

    G.write_wav("sf/jang_mine.wav", mine_jangdan())
    gung = [(t, 0.4, 43, int(90 * v)) for t, k, v in _jangdan() if k in ("G", "g")]
    chae = [(t, 0.2, 65, int(95 * v)) for t, k, v in _jangdan() if k in ("G", "c")]
    G.write_wav("sf/jang_sample.wav",
                norm(midi_render_multi("jang_s", [(0, 116, False, gung),
                                                  (9, 0, True, chae)])))
    print("완료")

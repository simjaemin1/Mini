"""
janggu_page.py — 장구 전용 화면.

  ① 국악원 낱개 타법 18개(6타법 × 강·중·약)를 하나씩
  ② 그 타법으로 짠 장단 6종을 장구만으로
  ③ 완성된 12곡에서 장구 층만 뽑은 것
"""
import os
import json
import base64
import subprocess
import numpy as np

import gugak as G
import sampler as S

OUT = "_jg"
STROKE = [("deong", "덩", "양손 동시. 장단의 가장 센 박"),
          ("kung", "쿵", "궁편(왼손). 낮고 둥근 소리"),
          ("gideok", "기덕", "채편 겹채. 두 번 빠르게"),
          ("deok", "덕", "채편(오른손). 기본 단타"),
          ("deo", "더", "채편 여리게"),
          ("deoreoreoreo", "더러러러", "채편 굴림. 후두둑 굴린다")]
DYN = [("loud", "강"), ("mid", "중"), ("qui", "약")]
JANGDAN_KO = {"gutgeori": ("굿거리", "12소박 · 느긋한 3분박. 마을 낮"),
              "jungjungmori": ("중중모리", "12소박 · 굿거리보다 조금 빠르다"),
              "semachi": ("세마치", "9소박 · 아리랑의 장단"),
              "jajinmori": ("자진모리", "12소박 · 몰아치는 빠른 장단"),
              "hwimori": ("휘모리", "8소박 · 가장 빠르다. 전투"),
              "jinyang": ("진양조", "24소박 · 가장 느리다. 마을 밤")}
TRACK_KO = {"village_day_trad": "마을 낮 · 전통", "village_day_amb": "마을 낮 · 앰비언트",
            "village_day_ari": "마을 낮 · 아리랑", "village_night_trad": "마을 밤 · 전통",
            "village_night_amb": "마을 밤 · 앰비언트", "village_night_ari": "마을 밤 · 아리랑",
            "battle_trad": "전투 · 전통", "battle_amb": "전투 · 앰비언트",
            "battle_ari": "전투 · 아리랑", "journey_trad": "원정 · 전통",
            "journey_amb": "원정 · 앰비언트", "journey_ari": "원정 · 아리랑"}


def mp3(src, dst, kbps=112, mono=True, secs=None):
    cmd = ["ffmpeg", "-v", "error", "-y", "-i", src]
    if secs:
        cmd += ["-t", str(secs)]
    cmd += ["-c:a", "libmp3lame", "-b:a", f"{kbps}k"] + (["-ac", "1"] if mono else []) + [dst]
    subprocess.run(cmd, check=True)
    return dst


def b64(p):
    return "data:audio/mpeg;base64," + base64.b64encode(open(p, "rb").read()).decode()


def render_jangdan(bank, name, cycles=3):
    """그 장단을 장구만으로. 곡에 쓰이는 것과 **같은 속도·같은 스윙**으로 친다.
    예전에는 여기서만 소박 0.20초를 썼는데, 그러면 굿거리(곡에서는 0.395초)가
    두 배 빨라지고 진양조(0.30초)는 세 배 빨라져 굿거리보다 급해진다 —
    장단은 이름이 아니라 속도가 정체라서, 그 순간 다른 장단이 된다."""
    import compose as C
    S.install(bank, [C])
    ncy, pat = C.JANGDAN[name]
    sobak, swing = C.TEMPO[name]
    dur = ncy * sobak * cycles + 2.5
    mix = G.Mix(dur, tail=1.5)
    for cy in range(cycles):
        C.play_jangdan(mix, name, 0.25 + cy * ncy * sobak, sobak,
                       gain=1.0, seed=100 + cy, drum="janggu",
                       humanize=0.010, swing=swing)
    rv = G.Reverb(dur=1.8, decay=1.0, pre=0.010, damp=5200, seed=3, width=0.8)
    return mix.render(rv, wet=0.30, loop=False, target_db=-17.0)


def main():
    os.makedirs(OUT, exist_ok=True)
    bank = S.Bank(["samples_janggu"])

    # ── ① 낱개 타법
    # ★ 이름을 '들어 있나' 로 찾으면 안 된다. deok 은 gideok 안에 들어 있고
    #   deo 는 deok·deong·deoreoreoreo 안에 다 들어 있다. 그래서 예전 판은
    #   기덕 파일 하나가 덕·더 자리까지 덮어써서 셋이 같은 소리로 났다.
    #   파일명을 '_' 로 쪼개 **토막 전체가 같을 때만** 그 타법으로 친다.
    files = {}
    for p in sorted(os.listdir("samples_janggu")):
        if not p.endswith(".wav"):
            continue
        parts = set(os.path.splitext(p)[0].split("_"))
        for key, _, _ in STROKE:
            if key not in parts:
                continue
            for dk, _ in DYN:
                if dk in parts:
                    files[(key, dk)] = os.path.join("samples_janggu", p)
    want = {(k, d) for k, _, _ in STROKE for d, _ in DYN}
    assert set(files) == want and len(set(files.values())) == 18, \
        f"타법 짝짓기 실패: {len(files)}칸 / 파일 {len(set(files.values()))}개"
    cells = []
    for key, ko, desc in STROKE:
        row = f'<tr><td class="sk"><b>{ko}</b><span class="d">{desc}</span></td>'
        for dk, dko in DYN:
            p = files.get((key, dk))
            if not p:
                row += '<td class="no">—</td>'
                continue
            m = mp3(p, f"{OUT}/s_{key}_{dk}.mp3", 128)
            row += (f'<td><button class="hit" data-t="{key}_{dk}">{dko}</button>'
                    f'<audio id="a_{key}_{dk}" preload="auto" src="{b64(m)}"></audio></td>')
        cells.append(row + "</tr>")

    # ── ② 장단 6종 (장구만)
    import compose as C
    KIND_KO = {"G": "덩", "g": "쿵", "c": "덕", "d": "더", "i": "기덕", "r": "더러러러"}
    jd = []
    for name, (ko, desc) in JANGDAN_KO.items():
        y = render_jangdan(bank, name)
        w = f"{OUT}/j_{name}.wav"
        G.write_wav(w, y)
        m = mp3(w, f"{OUT}/j_{name}.mp3", 112, mono=False)
        ncy, pat = C.JANGDAN[name]
        sob, sw = C.TEMPO[name]
        gu = []
        for s in range(ncy):
            hit = [k for p, k, _ in pat if int(p) == s]
            gu.append(KIND_KO[hit[0]] if hit else "·")
        gu = " ".join("".join(gu[i:i + 3]) for i in range(0, ncy, 3))
        jd.append(f'<div class="tr"><div class="th"><b>{ko}</b>'
                  f'<span class="sub">{desc}</span></div>'
                  f'<div class="gu">{gu}</div>'
                  f'<div class="tempo">소박 {sob*1000:.0f}ms · 한 주기 {ncy*sob:.2f}초'
                  + (f' · 스윙 {sw:.2f}' if sw else '') + ' · 세 주기</div>'
                  f'<audio controls preload="none" src="{b64(m)}"></audio></div>')

    # ── ③ 곡에서 뽑은 장구 층
    st = []
    for t, ko in TRACK_KO.items():
        p = f"stems/{t}__janggu.wav"
        if not os.path.exists(p):
            continue
        m = mp3(p, f"{OUT}/st_{t}.mp3", 96, mono=False)
        st.append(f'<div class="tr"><div class="th"><b>{ko}</b>'
                  f'<span class="sub">10~32초 구간 · 장구만</span></div>'
                  f'<audio controls preload="none" src="{b64(m)}"></audio></div>')

    html = f"""<!doctype html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>장구 — 낱개 타법부터 곡까지</title><style>
:root{{--bg:#12100e;--fg:#efe7db;--dim:#a99a86;--line:#332c25;--acc:#d8a25a;--acc2:#6fa8b8}}
*{{box-sizing:border-box}}
body{{margin:0;background:var(--bg);color:var(--fg);font:15px/1.65 -apple-system,BlinkMacSystemFont,"Apple SD Gothic Neo","Noto Sans KR",sans-serif}}
.wrap{{max-width:800px;margin:0 auto;padding:26px 18px 80px}}
h1{{font-size:24px;margin:0 0 6px}}
h2{{font-size:17px;margin:32px 0 8px;padding-bottom:6px;border-bottom:1px solid var(--line)}}
.lead{{color:var(--dim);margin:0 0 16px}}
table.hits{{border-collapse:collapse;width:100%;margin:10px 0}}
table.hits td,table.hits th{{border:1px solid var(--line);padding:8px 10px;text-align:center}}
table.hits th{{color:var(--dim);font-weight:400;font-size:13px}}
td.sk{{text-align:left;width:44%}}
td.sk b{{font-size:16px;color:var(--acc)}}
td.sk .d{{display:block;color:var(--dim);font-size:12px}}
td.no{{color:var(--dim)}}
.hit{{width:100%;padding:10px 4px;border-radius:8px;border:1px solid var(--acc2);
 background:#141b1d;color:var(--fg);font-size:14px;cursor:pointer;font-family:inherit}}
.hit:active,.hit.on{{background:var(--acc2);color:#0d1416;font-weight:700}}
.tr{{border:1px solid var(--line);border-radius:10px;padding:11px 13px;margin:9px 0;background:#181410}}
.th{{display:flex;gap:9px;align-items:baseline;margin-bottom:8px}}
.sub{{color:var(--dim);font-size:12px}}
audio[controls]{{width:100%;height:34px}}
table.hits audio{{display:none}}
.note{{color:var(--dim);font-size:12.5px;margin:6px 0}}
.fix{{border:1px solid #5c3b2e;border-left:3px solid var(--acc);border-radius:8px;
 background:#1a120c;padding:11px 14px;margin:14px 0;font-size:13px;color:#d9cbb8}}
.fix b{{color:var(--acc)}}
.fix ol{{margin:8px 0 0;padding-left:20px}}
.fix li{{margin:7px 0}}
.how{{border:1px solid #2f4a52;border-left:3px solid var(--acc2);border-radius:8px;
 background:#101a1d;padding:11px 14px;margin:14px 0;font-size:13px;color:#cfdde1}}
.how b{{color:var(--acc2)}}
.how p{{margin:7px 0}} .how ol{{margin:8px 0;padding-left:20px}} .how li{{margin:5px 0}}
.gu{{font-size:15px;letter-spacing:.08em;color:var(--acc);margin:2px 0 3px}}
.tempo{{font-size:11.5px;color:var(--dim);margin-bottom:7px}}
code{{font-size:12px;background:#241c15;padding:1px 4px;border-radius:3px}}
footer{{margin-top:38px;padding-top:14px;border-top:1px solid var(--line);color:var(--dim);font-size:12.5px}}
</style></head><body><div class="wrap">
<h1>장구</h1>
<p class="lead">국립국악원 낱개 타법부터, 그것으로 짠 장단, 완성된 곡에서 장구만 뽑은 것까지
한 화면에 놓았습니다. 이상한 곳이 어디인지 짚으실 수 있게요.</p>

<h2>① 낱개 타법 — 국악원 원본 그대로</h2>
<p class="note">앞뒤 묵음을 걷어낸 것 외에 아무 가공도 없습니다. 음량도 <b>손대지 않았습니다</b> —
강·중·약의 크기 차가 녹음된 그대로입니다. 눌러서 하나씩 들어보세요.</p>
<table class="hits"><tr><th>타법</th><th>강</th><th>중</th><th>약</th></tr>
{''.join(cells)}</table>
<p class="note">덩·쿵은 <b>궁편</b>(왼손 낮은 쪽), 기덕·덕·더·더러러러는 <b>채편</b>(오른손 높은 쪽)입니다.</p>
<div class="fix"><b>여기가 틀려 있었습니다 — 기덕·덕·더가 다 같은 소리로 났던 이유</b>
<ol>
<li><b>덕과 더 자리에 기덕 파일이 들어가 있었습니다.</b> 파일 이름을 '들어 있나' 로 찾았는데
<code>deok</code> 은 <code>gideok</code> 안에 들어 있고 <code>deo</code> 는 셋 다에 들어 있습니다.
이름순으로 <code>gideok</code> 이 마지막이라 덕·더 칸을 덮어썼습니다. 세 칸이 같은 파일이었으니
같게 들리는 게 당연했습니다. 이제 이름을 <code>_</code> 로 쪼개 토막이 정확히 맞을 때만 짝짓습니다.</li>
<li><b>강·중·약을 제가 뭉갰습니다.</b> 파일마다 최대치를 맞춰 정규화했는데,
가야금은 한 파일에 음계가 다 들어 있어 그게 맞지만 타악기는 한 파일이 한 타점이라
그게 곧 세기를 지우는 짓입니다. 쿵 강/중/약이 원본은 −0.3/−5.4/−11.6dB 인데
전부 −0.3dB 가 돼 있었습니다. 지금은 악기당 배율 하나만 씁니다.</li>
<li><b>더러러러가 굴림이 아니라 덕 네 개였습니다.</b> 타점마다 자르는 코드가
한 번의 굴림(0.17~2.2초, 여덟 번)을 네 조각으로 썰었습니다. 징은 더 심해서,
한 번 친 35초짜리 여운을 58조각으로 썰어 놨습니다. 타악기는 이제 자르지 않습니다.</li>
<li><b>약하게 친 녹음의 꼬리가 방 안 잡음이었습니다.</b> 꼬리 자르는 기준이 봉우리 대비라서
여린 녹음에서는 그 선이 잡음보다 아래로 내려갔습니다. 쿵/약이 3.54초, 더/약이 3.88초짜리
잡음 덩어리였습니다. 이제 1.23초·0.56초입니다.</li>
</ol></div>

<h2>② 장단 — 장구만으로</h2>
<p class="note">곡에 쓰이는 것과 같은 코드·같은 속도로 세 주기씩 찍었습니다. 다른 악기는 없습니다.</p>

<div class="how"><b>어떻게 만드는가 — 음원에 무슨 일이 일어나는지 전부</b>
<p>주파수를 분석해 음색을 흉내낸 합성음이 <b>아닙니다.</b> 위 ①의 녹음을
시각에 놓는 것이 전부이고, 녹음 자체에 가하는 처리는 다음 다섯 가지뿐입니다.</p>
<ol>
<li><b>고르기</b> — 악보의 (타법, 세기)로 18개 중 하나를 고릅니다. 리샘플링(음높이 변경)은
없습니다. 타악기는 음정이 없으므로 <b>표본 하나도 건드리지 않습니다.</b></li>
<li><b>자리에 놓기</b> — 소박 단위 시각에 얹습니다. 굿거리는 스윙 0.28,
사람 손의 흔들림 ±10ms를 더합니다.</li>
<li><b>볼륨과 좌우</b> — 스칼라 곱. 파형 모양은 안 변합니다.</li>
<li><b>끝 페이드</b> — 정해진 길이 뒤부터 서서히 0으로. 다음 박을 안 넘어가게.</li>
<li><b>잔향</b> — 다 합친 뒤 한 번, 30%만 섞습니다.</li>
</ol>
<p>검산: 찍힌 소리에서 국악원 원본을 그 자리에 맞춰 빼면 <b>−39dB</b>만 남습니다
(남는 건 끝 페이드와 1.5ms 어택 램프). 조각 18개는 원본과 <b>상관계수 1.0000</b>,
18개 전부입니다.</p></div>

{''.join(jd)}
<div class="fix"><b>장단을 자료에 맞춰 다시 짰습니다</b><br>
<b>기덕이 3분의 1박씩 밀리고 있었습니다.</b> 기덕은 ‘기’(앞꾸밈)+‘덕’(본타) 두 타인데,
저는 파일 앞머리를 박에 맞춰 놓았습니다. 그러면 정작 본타는 93~145ms 뒤에 떨어집니다 —
소박이 395ms 인 굿거리에서 3분의 1박입니다. 이제 본타가 박에 오도록 그만큼 당깁니다
(측정: +93~145ms → <b>+3ms</b>).<br>
<b>스윙을 뺐습니다.</b> 굿거리·중중모리는 이미 <b>3소박</b> 장단이라 셋잇단 자체가 흔들림인데,
거기에 스윙 0.28 을 또 얹어 각 박의 셋째 소박을 55ms 씩 밀고 있었습니다.
기덕이 하필 그 자리(2·8소박)라 두 오차가 겹쳐 최대 200ms 가 밀렸습니다.<br>
<b>세마치·휘모리의 둘째 박이 틀렸습니다.</b> 구음이 각각 “덩<b>덩</b>덕쿵덕”,
“덩 <b>덩</b> 쿵덕 쿵” 인데 저는 둘 다 궁편(쿵)으로 쳐서 뼈대가 약했습니다.
중중모리도 이보형 논문의 “덩-딱/궁-딱/궁궁척/궁--” 으로 바로잡았습니다.<br>
<b>진양조는 6박 한 각 × 4각(24박)</b> 인데 각 하나에 한 타씩만 찍고 있었습니다.<br>
<b>속도가 전부 틀려 있었습니다.</b> 이 화면만 소박 0.20초로 찍고 있었는데,
곡에서 굿거리는 0.395초입니다 — <b>두 배 빨랐습니다.</b> 진양조는 0.30초라
<b>세 배 빨라</b> 가장 느린 장단이 굿거리보다 급하게 나왔습니다.
장단은 이름이 아니라 속도가 정체라, 그 순간 다른 장단이 됩니다.
이제 곡과 같은 표(<code>TEMPO</code>)를 씁니다.<br>
<b>더러러러가 굴림이 아니었습니다.</b> 국악원 녹음은 시범이라
0.37초 간격으로 느리게 시작해 0.19초까지 <b>점점 빨라집니다.</b>
저는 맨 앞부터 틀고 자리가 모자라 끊었으니, 들리는 건 0.37초 간격의 느린 세 타 —
그냥 덕 셋이었습니다. 이제 자리를 채울 수 있는 <b>가장 늦은 타점</b>에서 들어가
빨라진 대목이 울립니다(굿거리 0.19·0.23·0.15초 간격 4타).<br>
굿거리 주석에는 “덩 기덕 쿵 더러러러” 라고 적어 놓고, 실제 악보는
<code>기덕</code>을 <b>덕 두 개</b>로, <code>더러러러</code>를 <b>덕 세 개</b>로 찍고 있었습니다.
기덕과 더러러러는 덕을 여러 번 치는 게 아니라 손목 한 번에 나오는 <b>하나의 주법</b>이고,
국악원 녹음에 둘 다 따로 들어 있습니다. 이제 그 녹음을 그대로 씁니다.<br>
세기도 두 번 먹이지 않습니다 — 악보의 세기로 강/중/약 <b>녹음을 고르고</b>,
고른 녹음이 이미 그만큼 작으므로 남는 차이만 볼륨으로 줍니다.
예전엔 −16dB 로 녹음된 ‘더/약’ 에 볼륨 0.25 를 또 곱해 −28dB 로 안 들렸습니다.</div>

<h2>③ 완성된 12곡에서 장구만</h2>
<p class="note">정규화 없이 뽑아서 곡에서의 실제 음량 그대로입니다.</p>
{''.join(st)}

<footer>장단 배열 출처 — 위키백과 「장단」 · 이보형, 「韓國民俗音樂 長短의 리듬型에 관한 硏究」(서울대) ·
국립국악원 낱개 타법 표<br>
찍은 타점 41개를 울린 소리에서 되짚어 악보 자리와 대조: 중앙값 <b>4ms</b>, 85%가 20ms 안입니다
(사람이 밀렸다고 느끼기 시작하는 선이 대략 20~30ms).<br>
국악기 음원 제공 — 국립국악원 (공공누리 제1유형)<br>
18개 조각 전부 원본과 파형 상관계수 1.0000 으로 일치합니다.
장단에 찍힌 타점 37개도 파형을 되짚어 '넣은 그 녹음' 과 가장 닮은 것으로 확인했습니다
(4개는 쿵/강 과 쿵/중 이 0.896 대 0.893 으로 비겨서 갈렸을 뿐, 타법은 37개 모두 맞습니다).</footer>
</div>
<script>
// 사파리는 new Audio() 로 만든 소리의 재생을 자동재생 정책으로 막는다.
// 문서 안에 미리 놓인 <audio> 를 클릭 순간에 재생하면 통과한다.
var cur=null;
document.querySelectorAll('.hit').forEach(function(b){{
  var a=document.getElementById('a_'+b.dataset.t);
  b.onclick=function(){{
    if(cur && cur!==a){{ cur.pause(); cur.currentTime=0; }}
    document.querySelectorAll('.hit').forEach(function(x){{x.classList.remove('on');}});
    b.classList.add('on'); cur=a; a.currentTime=0;
    var pr=a.play(); if(pr && pr.catch) pr.catch(function(){{ b.classList.remove('on'); }});
    a.onended=function(){{ b.classList.remove('on'); }};
  }};
}});
</script></body></html>"""
    p = "장구.html"
    open(p, "w").write(html)
    print(f"{p}  {os.path.getsize(p)/1e6:.1f}MB  낱개 {len(files)}개 · 장단 {len(jd)}종 · 곡 {len(st)}개")


if __name__ == "__main__":
    main()

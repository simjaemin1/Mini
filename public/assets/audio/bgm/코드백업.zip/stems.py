"""
stems.py — 곡을 악기별 층으로 분리한다 (믹서용).

악기 함수를 무음으로 갈아끼워 특정 층만 남긴다.
인자(seed 등)는 그대로 평가되므로 난수 스트림이 바뀌지 않아
"완성본에서 그 층만 뽑아낸 것"과 정확히 같다.
정규화를 꺼서 층끼리의 실제 음량 비가 보존된다 — 그래야 켜고 끄는 게 의미가 있다.

    python3 stems.py samples_gaya samples_danso ...
"""
import sys
import os
import json
import numpy as np
import gugak as G
import sampler as S

INSTS = ["daegeum", "danso", "piri", "gayageum", "geomungo",
         "janggu_gung", "janggu_chae", "buk", "jing", "kkwaenggwari",
         "bak", "pad", "wind", "water", "crickets"]

GROUPS = {
    "gayageum": (["gayageum"], "가야금"),
    "geomungo": (["geomungo"], "거문고"),
    "winds":    (["daegeum", "danso", "piri"], "대금·단소·피리"),
    "janggu":   (["janggu_gung", "janggu_chae"], "장구"),
    "metal":    (["jing", "kkwaenggwari", "buk", "bak"], "징·꽹과리·북·박"),
    "pad":      (["pad"], "패드"),
    "amb":      (["wind", "water", "crickets"], "자연음(바람·개울·풀벌레)"),
}
EXCERPT = (10.0, 32.0)          # 발췌 구간(초)


def _silent(*a, **k):
    return np.zeros(0, np.float32)


def render_with(mods, track_fn, spec, keep):
    saved = {}
    for mod in mods:
        for name in INSTS:
            if hasattr(mod, name):
                saved[(mod, name)] = getattr(mod, name)
                if keep is not None and name not in keep:
                    setattr(mod, name, _silent)
    try:
        return track_fn(spec)
    finally:
        for (mod, name), fn in saved.items():
            setattr(mod, name, fn)


def main():
    roots = sys.argv[1:] or ["samples_gaya"]
    os.makedirs("stems", exist_ok=True)
    bank = S.Bank(roots)
    import compose as C
    import arirang as A
    allt = {**C.TRACKS, **A.ARI_TRACKS}
    score = json.load(open("score.json"))

    orig_render = G.Mix.render
    G.Mix.render = lambda self, *a, **k: orig_render(self, *a, **{**k, "norm": False})
    man = {}
    try:
        for track, spec in allt.items():
            used = {e["inst"] for e in score.get(track, [])}
            plan = S.plan_octaves({track: score[track]}, bank) if track in score else {}
            S.install(bank, [C, A], octaves=plan)
            full = render_with([C, A], spec["fn"], spec, None)
            rms = float(np.sqrt(np.mean(full ** 2))) + 1e-12
            gain = (10 ** (-15.0 / 20)) / rms
            a, b = int(EXCERPT[0] * G.SR), int(EXCERPT[1] * G.SR)
            G.write_wav(f"stems/{track}__FULL.wav", np.clip(full[:, a:b] * gain, -1, 1))
            rows = []
            for key, (insts, label) in GROUPS.items():
                if not (set(insts) & used) and key not in ("pad", "amb"):
                    continue
                S.install(bank, [C, A], octaves=plan)
                y = render_with([C, A], spec["fn"], spec, set(insts))
                r = float(np.sqrt(np.mean(y ** 2)))
                if r < 1e-6:
                    continue
                G.write_wav(f"stems/{track}__{key}.wav", np.clip(y[:, a:b] * gain, -1, 1))
                rows.append([key, label, round(20 * np.log10(r / rms + 1e-12), 1)])
            rows.sort(key=lambda x: -x[2])
            man[track] = rows
            print(f"  {track:20s} 층 {len(rows)}개  " +
                  " ".join(f"{l}({d:+.0f}dB)" for _, l, d in rows))
    finally:
        G.Mix.render = orig_render
    json.dump(man, open("stems/_manifest.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()

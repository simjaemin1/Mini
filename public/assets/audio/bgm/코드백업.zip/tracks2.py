"""
tracks2.py — 12곡 전부, 동기 전개 + 시김새 문법으로 다시 쓴 판.

장면 4 × 결 3 = 12곡.
    마을 낮 / 마을 밤 / 전투 / 원정   ×   전통 · 앰비언트 · 아리랑

무엇이 달라졌나
  ① 선율이 **골격 + 잔가락**이다(garak.py). 서양식 '주제를 네 번 되풀이하는 A 단락'
     을 버렸다 — 산조에는 그런 게 없다. 한 장단에 골격 두세 음이 어디로 갈지를 정하고,
     그 사이를 잔가락이 메우는데 잔가락은 **매번 다르다.**
     장면마다 골격이 지나가는 '여정'(GK.ARC)이 다르고, 그게 곡의 이야기다.
  ② 시김새를 문법으로 건다. 긴 음은 깊은 농현, 정점은 청성, 맺음은 퇴성,
     도약은 추성, 반복은 굴림, 거문고 대박은 슬기둥. 값이 아니라 **녹음을 지정**한다.
  ③ 장단은 자료(위키백과·이보형 논문)에 맞춰 다시 짰고, 겹채(기덕)는 본타를 박에 맞춘다.
  ④ 조와 옥타브를 **음원이 실제로 가진 음**에서 계산해 정한다(억지로 늘리는 양 최소).
"""
import numpy as np
from gugak import *   # noqa — sampler.install 이 이 이름들을 갈아끼운다
import gugak as G
import compose as C
import arirang as A
from motif import Motif, voice, deg_midi, PYEONGJO, GYEMYEONJO
import garak as GK

ARI_PENTA = [0, 2, 4, 7, 9]      # 본조아리랑은 do re mi sol la (평조가 아니다)

# ─────────────────────────────────────── 조·옥타브를 음원에서 계산한다
_PITCHES = {}


def pitches_of(inst):
    """그 악기가 실제로 가진 음(MIDI 정수). 색인에서 한 번만 읽는다."""
    if not _PITCHES:
        import json, glob, os
        for d in glob.glob("samples_*/_index.json"):
            if os.path.dirname(d) == "samples_test":
                continue
            for e in json.load(open(d))["entries"]:
                if e["midi"] is not None:
                    _PITCHES.setdefault(e["inst"], set()).add(round(e["midi"]))
    return np.array(sorted(_PITCHES.get(inst, [])), float)


def best_root(inst, mode, pc, ndeg=6, prefer=None, tol=0.3):
    """으뜸음 음정계급이 pc 인 조에서, 그 악기가 가장 안 늘리고 낼 수 있는 옥타브.
    tol 반음 안쪽 차이는 '같은 것' 으로 보고, 그 안에서는 prefer 에 가까운 옥타브를 고른다
    — 거문고는 1반음 늘리더라도 한 옥타브 낮게 잡는 편이 베이스로 맞다."""
    s = pitches_of(inst)
    if not len(s):
        return prefer if prefer is not None else 60
    best = None
    for root in range(24, 100):
        if root % 12 != pc % 12:
            continue
        degs = [deg_midi(root, mode, d) for d in range(ndeg)]
        if min(degs) < s.min() - 0.5 or max(degs) > s.max() + 0.5:
            continue
        cost = [float(np.min(np.abs(s - g))) for g in degs]
        key = (round(max(0.0, max(cost) - tol), 2),
               abs(root - (prefer if prefer is not None else root)),
               round(float(np.mean(cost)), 3))
        if best is None or key < best[0]:
            best = (key, root)
    return best[1] if best else (prefer if prefer is not None else 60)


def f_of(root, mode, deg):
    return G.mtof(deg_midi(root, mode, deg))


def sing(mix, fn, root, mode, notes, gain, pan, send, amp=1.0, seed=0,
         legato=0.94, gaya=False):
    """voice() 가 준 지시대로 분다/뜯는다. 시김새 이름이 그대로 넘어가
    sampler 가 **그 국악원 녹음**을 꺼낸다."""
    rng = np.random.default_rng(seed)
    kn, kb = ("nonghyeon", "bend") if gaya else ("vib_cents", "bend_end")
    for at, dur, deg, nong, bend, art in notes:
        kw = {kn: nong, kb: bend, "seed": int(rng.integers(1 << 20))}
        if art:
            kw["art"] = art
        mix.add(fn(f_of(root, mode, deg), dur * legato, amp, **kw),
                at + rng.normal(0, 0.008), gain, pan, send)


def gaya_bed(mix, t0, root, mode, sobak, spots, gain=0.46, seed=0):
    """가야금 반주. 반주라고 시김새를 빼지 않는다 — 산조가야금은 반주에서도 굴리고 꺾는다.
    spots: (소박, 음도, 길이[소박], 농현, 꺾기, 주법)"""
    rng = np.random.default_rng(seed)
    for s, deg, ln, nong, bend, art in spots:
        mix.add(gayageum(f_of(root, mode, deg), ln * sobak, 1.0, art=art,
                         nonghyeon=float(nong), bend=float(bend),
                         seed=int(rng.integers(1 << 20))),
                t0 + s * sobak + rng.normal(0, 0.010), gain, -0.20, 0.30)


GEO_HANDS = [("sulgidung", "jeonseong"), ("jeonseong", "sulgidung"),
             ("ssarang", "jeonseong"), ("sulgidung", "jachul")]


def geo_bass(mix, t0, root, mode, sobak, spots, gain=0.42, seed=0, fig=0):
    """거문고. 술대로 때리는 악기라 고유한 손이 따로 있다 — 슬기둥·싸랭·자출·전성."""
    rng = np.random.default_rng(seed)
    hands = GEO_HANDS[fig % 4]
    for i, (s, deg, ln) in enumerate(spots):
        mix.add(geomungo(f_of(root, mode, deg), ln * sobak, 1.0,
                         art=hands[i % 2], vib_cents=14.0,
                         seed=int(rng.integers(1 << 20))),
                t0 + s * sobak, gain, 0.24, 0.26)


# ─────────────────────────────────────── 장면마다의 주제
# 마을 낮 α : 치 우 궁'  — 올라가 꼭대기를 붙든다
# 마을 낮 β : 우 치 각 궁 — 내려와 궁으로 맺는다
ALPHA = Motif([(0, 1, 3), (1, 2, 4), (3, 3, 5)], span=6)
BETA = Motif([(0, 2, 4), (2, 1, 3), (3, 2, 2), (5, 1, 0)], span=6)

# 마을 밤 : 낮의 주제를 **뒤집고 늘인 것**. 같은 얼굴의 다른 표정이다.
NIGHT_A = ALPHA.invert(3).augment(2.0)          # 올라가던 것이 내려간다
NIGHT_B = BETA.augment(2.0).ending(0)

# 전투 : 주제를 조여서 되풀이한다. 머리 두 음만 남기고 몰아친다.
WAR_A = ALPHA.head(2).diminish(0.5)
WAR_B = Motif([(0, 1, 4), (1, 1, 3), (2, 1, 4), (3, 1, 5)], span=4)

# 원정 : 걷는 걸음. 세마치 9소박에 맞춘다.
ROAD_A = Motif([(0, 1.5, 0), (1.5, 1.5, 1), (3, 2, 3), (5, 1, 2), (6, 3, 3)], span=9)
ROAD_B = Motif([(0, 2, 4), (2, 1, 3), (3, 2, 1), (5, 1, 0), (6, 3, 0)], span=9)


def _scene(name):
    """장면마다 조·장단·악기 자리를 한 번에 정한다."""
    if name.startswith("village_day"):
        mode, pc, jd = PYEONGJO, 7, "gutgeori"          # G 평조 · 굿거리
    elif name.startswith("village_night"):
        mode, pc, jd = GYEMYEONJO, 9, "jinyang"         # A 계면조 · 진양조
    elif name.startswith("battle"):
        mode, pc, jd = GYEMYEONJO, 9, "jajinmori"       # A 계면조 · 자진모리
    else:
        mode, pc, jd = PYEONGJO, 7, "semachi"           # G 평조 · 세마치
    r = dict(mode=mode, jangdan=jd,
             dae=best_root("daegeum", mode, pc, prefer=69),
             piri=best_root("piri", mode, pc, ndeg=5, prefer=67),
             dan=best_root("danso", mode, pc, ndeg=5, prefer=81),
             gaya=best_root("gayageum", mode, pc, prefer=57),
             geo=best_root("geomungo", mode, pc, prefer=45, tol=1.05))
    return r


# ─────────────────────────────────────── 곡 만들기
def build(scene, mood):
    sc = _scene(scene)
    mode, jd = sc["mode"], sc["jangdan"]
    sobak, swing = C.TEMPO[jd]
    ncy_s = C.JANGDAN[jd][0]
    cycle = ncy_s * sobak
    day = scene == "village_day"
    night = scene == "village_night"
    war = scene == "battle"
    road = scene == "journey"

    mname = "gyemyeonjo" if mode is GYEMYEONJO else "pyeongjo"

    target = 108.0
    ncy = max(8, int(round(target / cycle)))
    dur = ncy * cycle + 5.0
    mix = G.Mix(dur, tail=4.0)
    rv = G.Reverb(dur=2.6, decay=1.5, pre=0.015, damp=2400, seed=11, width=0.85)
    rng = np.random.default_rng(abs(hash((scene, mood))) % (1 << 30))

    amb = mood == "amb"
    # 골격 여정 — 장면마다 '어디로 가는 이야기' 가 다르다
    gk = GK.Garak(mname, GK.ARC[scene], ncy_s,
                  seed=abs(hash((scene, mood))) % (1 << 20),
                  lo=-2 if night else 0, hi=6)
    # 악기를 자료에 맞춰 배치한다.
    #   대금 — 합주의 조율 기준(서양 관현악의 오보에 자리). 청 울림과 긴 호흡. 주선율.
    #   향피리 — 겹서라 음량이 커서 야외·행진 음악(삼현육각)의 주선율. 전투를 맡는다.
    #   단소 — 맑고 청아. 줄풍류(세악)의 악기라 조용한 자리와 응답구.
    #   가야금 — 12현·시김새가 풍부. 반주와 간주 독주.
    #   거문고 — 술대로 때리는 악기(대점·중점·소점). 굵고 낮다. 골격과 저음.
    # ★시김새 문법은 **그 악기 이름으로** 물어야 한다. 전투의 주선율은 피리인데
    #   대금의 어휘를 물어보면, 피리에 없는 주법이라 어림잡기로 떨어져
    #   끊어치기 12개짜리 녹음이 451번 되풀이됐다.
    if night and amb:
        lead, lead_name, lead_root = danso, "danso", sc["dan"]
        resp, resp_name, resp_root = daegeum, "daegeum", sc["dae"]
    elif war:
        lead, lead_name, lead_root = piri, "piri", sc["piri"]
        resp, resp_name, resp_root = danso, "danso", sc["dan"]
    else:
        lead, lead_name, lead_root = daegeum, "daegeum", sc["dae"]
        resp, resp_name, resp_root = danso, "danso", sc["dan"]

    # 단락 나누기 — 들머리 / A / A' / B / 사이 / A'' / 맺음
    m = [max(1, int(ncy * f)) for f in (0.09, 0.18, 0.18, 0.17, 0.09, 0.20)]
    e = np.cumsum(m).tolist()
    e.append(ncy)

    for c in range(ncy):
        t0 = c * cycle
        sd = 900 + c * 17
        sect = next(i for i, b in enumerate(e) if c < b)

        # ── 장구
        if sect > 0 and not (amb and sect == 4):
            heat = [0, .34, .62, .70, .48, .78, .44][sect] * (0.45 if amb else 1.0)
            nm = jd
            if war and sect >= 5:
                nm = "hwimori"                       # 전투는 끝에서 휘모리로 몰아친다
            C.play_jangdan(mix, nm, t0, C.TEMPO[nm][0], gain=heat, seed=sd,
                           drum="janggu" if heat > 0.45 else "soft",
                           humanize=0.011, swing=C.TEMPO[nm][1], send=0.28)
            if war and sect >= 4 and c % 2 == 0:
                mix.add(jing(2.4, 0.5, seed=int(rng.integers(1 << 20))), t0, 0.30, 0.1, 0.3)
            if war and sect >= 5:
                for s in range(0, ncy_s, 3):
                    mix.add(kkwaenggwari(0.5, 0.55, seed=int(rng.integers(1 << 20))),
                            t0 + s * sobak, 0.24, -0.3, 0.25)

        # ── 거문고 (베이스)
        if sect in (1, 2, 3, 5) and not (amb and sect == 1):
            geo_bass(mix, t0, sc["geo"], mode, sobak,
                     [(0, 0, 3.2), (ncy_s // 2, 3 if c % 2 else 2, 3.0)],
                     gain=0.38 if amb else 0.44, seed=sd + 1, fig=c)

        # ── 가야금 (반주 · 사이 독주)
        if sect == 4:
            # 사이 — 가야금 홀로. 같은 골격을 잘게 쪼개 12현의 시김새를 다 꺼낸다.
            bn = gk.bones(c, ncy)
            sing(mix, gayageum, sc["gaya"], mode,
                 gk.voice(gk.fill(bn, 0.85, breath=False), t0, sobak, "gayageum"),
                 gain=0.62, pan=-0.14, send=0.34, seed=sd + 8, gaya=True)
        elif sect > 0:
            h = ncy_s // 2
            spots = [(0, 0, min(2.0, h * 0.6), 10, 0, "nong_shallow"),
                     (h // 2, 3, 1.2, 0, 0, "gullim"),
                     (h, 2, min(1.8, h * 0.5), 12, 0, "nong_shallow"),
                     (h + h // 2, 3, 1.2, 0, -22, "toegim")]
            if amb:
                spots = [(0, 0, h * 0.9, 20, 0, "nong_break"),
                         (h, 3, h * 0.8, 0, -22, "toegim")]
            gaya_bed(mix, t0, sc["gaya"], mode, sobak, spots,
                     gain=0.40 if amb else 0.46, seed=sd + 5)

        # ── 선율 — 골격에 잔가락. 매 장단이 다르다.
        if mood == "ari":
            continue
        pos = c / max(1, ncy - 1)
        dens = GK.density_at(pos, peak=0.80 if war else 0.70,
                             lo=0.22 if amb else 0.32)
        breath = (c % 3 == 2) or amb                 # 두세 장단마다 숨을 쉰다
        bones = gk.bones(c, ncy)
        notes = gk.fill(bones, dens, breath=breath)
        if not notes:
            continue
        v = gk.voice(notes, t0, sobak, lead_name, cadence=(c % 4 == 3 or c == ncy - 1))
        # 끝으로 갈수록 잦아든다
        fade = 1.0 if c < ncy - 2 else (0.72 if c == ncy - 2 else 0.45)
        sing(mix, lead, lead_root, mode, v,
             gain=(0.56 if amb else 0.66) * fade, pan=0.10, send=0.34, seed=sd + 3)

        # 응답 — 골격의 마지막 두 음만 한 옥타브 위에서 되받는다.
        #   단소는 줄풍류의 악기라 맑게 얹히고, 대금이 쉬는 자리에 들어간다.
        if (c % 4 == 3) and not (amb and night):
            tail = [(s2, d2, g2) for s2, d2, g2 in notes if s2 >= ncy_s * 0.6][:3]
            if tail:
                sing(mix, resp, resp_root, mode,
                     gk.voice(tail, t0, sobak, resp_name, cadence=True),
                     gain=0.34 * fade, pan=0.34, send=0.42, seed=sd + 6)

        # 피리 — 향피리는 음량이 커서 야외·행진 음악의 주선율이다.
        #   전투에서는 이미 주선율이므로, 다른 곡에서는 골격만 두껍게 받친다.
        if not amb and not war and dens > 0.55 and c % 2 == 1:
            bb = [(s2, min(3.0, ncy_s / 3.0), g2) for s2, g2 in bones[:2]]
            sing(mix, piri, sc["piri"], mode,
                 gk.voice(bb, t0, sobak, "piri", cadence=False),
                 gain=0.26 * fade, pan=-0.34, send=0.40, seed=sd + 7)

    # ── 아리랑: 실제 전승 가락을 같은 시김새 문법으로 얹는다
    if mood == "ari":
        do = best_root("daegeum", ARI_PENTA, 0, ndeg=5, prefer=72)
        do_g = best_root("gayageum", ARI_PENTA, 0, ndeg=5, prefer=60)
        beat = cycle / 3.0                       # 3/4 한 마디 = 장단 한 주기
        for c in range(ncy):
            bar = A.ARIRANG[c % A.NBAR]
            notes = [(c * cycle + p * beat, d * beat * 0.94, n) for p, d, n in bar]
            mo = Motif([(p / beat, d / beat, n + 5) for p, d, n in bar], span=3)
            v = voice(mo, c * cycle, beat, "pyeongjo", "daegeum",
                      cadence_last=(c % 4 == 3))
            sing(mix, daegeum, do, ARI_PENTA, v,
                 gain=0.66, pan=0.10, send=0.34, seed=1500 + c)
            if c % 4 == 3:
                sing(mix, danso, do + 12, ARI_PENTA,
                     voice(mo.tail(2), c * cycle + 2 * beat, beat, "pyeongjo", "danso"),
                     gain=0.34, pan=0.34, send=0.42, seed=1600 + c)

    if amb:
        mix.add(G.wind(dur, 0.075, seed=7), 0.0, 1.0, 0.0, 0.10)
        mix.add(G.water(dur, 0.050, seed=8), 0.0, 1.0, 0.30, 0.10)
        if night:
            mix.add(G.crickets(dur, 0.055, seed=9), 0.0, 1.0, -0.25, 0.10)
    elif day:
        mix.add(G.wind(dur, 0.045, seed=7), 0.0, 1.0, 0.0, 0.10)
        mix.add(G.water(dur, 0.035, seed=8), 0.0, 1.0, 0.30, 0.10)
    elif night:
        mix.add(G.crickets(dur, 0.045, seed=9), 0.0, 1.0, -0.25, 0.10)

    tdb = {"trad": -16.0, "amb": -18.0, "ari": -16.5}[mood]
    return mix.render(rv, wet=1.0, target_db=tdb, loop=False)


SCENES = ["village_day", "village_night", "battle", "journey"]
MOODS = ["trad", "amb", "ari"]
KO_S = {"village_day": "마을 낮", "village_night": "마을 밤",
        "battle": "전투", "journey": "원정"}
KO_M = {"trad": "전통", "amb": "앰비언트", "ari": "아리랑"}
TRACKS = {f"{s}_{m}": dict(fn=(lambda s=s, m=m: (lambda spec=None: build(s, m)))(),
                           title=f"{KO_S[s]} · {KO_M[m]}", scene=s, mood=m)
          for s in SCENES for m in MOODS}

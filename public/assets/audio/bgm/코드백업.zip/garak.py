"""
garak.py — 골격 + 잔가락. 선율을 '주제 되풀이' 가 아니라 **산조가 굴러가는 방식**으로 짠다.

앞의 판(motif.py)은 서양식이었다. 주제를 정하고 A–A′–B–A″ 로 되풀이했더니
① 들머리 두 주기가 음 두 개뿐이라 비었고
② 뒤로 갈수록 같은 머리(치–우–궁′)가 29% 의 주기에서 똑같이 나와 지겨웠다.

국악은 그렇게 굴러가지 않는다. 산조에는 '한 주제를 네 번 되풀이하는 A 단락' 이 없다.
있는 것은

    골격(骨格)  — 한 장단에 두세 개, 어디로 가는지를 정하는 큰 음. 이게 정체다.
    잔가락      — 그 사이를 메우는 잘고 빠른 가락. **매번 다르다.**

정체는 골격이 지키고, 지겹지 않은 것은 잔가락이 맡는다. 그래서 산조는
같은 조·같은 장단으로 십 분을 가도 같은 마디가 두 번 나오지 않는다.
여기서는 그 두 층을 그대로 만든다.
"""
import numpy as np
from motif import sigim, deg_midi, PYEONGJO, GYEMYEONJO   # noqa: F401


class Garak:
    """골격을 깔고 잔가락으로 메운다."""

    def __init__(self, mode_name, arc, ncy_s, seed=0, lo=-2, hi=6):
        """
        arc  : 곡 전체가 지나가는 골격 음의 여정(음도 목록). 곡 길이에 맞춰 늘려 쓴다.
               예) [0,3,4,5,4,3,0] — 궁에서 나가 궁′까지 올랐다가 궁으로 돌아온다.
        ncy_s: 한 장단의 소박 수
        """
        self.m = mode_name
        self.arc = list(arc)
        self.n = ncy_s
        self.rng = np.random.default_rng(seed)
        self.lo, self.hi = lo, hi

    # ── 골격: 한 장단에 두세 음. 어디로 가는지가 여기서 정해진다.
    def bones(self, c, ncy):
        """c 번째 장단의 골격 [(소박, 음도)]. 큰 박에만 놓는다."""
        pos = c / max(1, ncy - 1)
        i = pos * (len(self.arc) - 1)
        a, b = int(np.floor(i)), min(len(self.arc) - 1, int(np.floor(i)) + 1)
        f = i - a
        base = self.arc[a]
        nxt = self.arc[b]
        n = self.n
        if n >= 24:                       # 진양조 — 각(6소박)마다 하나
            spots = [0, n // 4, n // 2, 3 * n // 4]
        elif n >= 12:
            spots = [0, n // 3, 2 * n // 3]
        elif n >= 9:
            spots = [0, n // 3, 2 * n // 3]
        else:
            spots = [0, n // 2]
        out = []
        for k, s in enumerate(spots):
            g = base if (k / len(spots)) > f else (nxt if f > 0.5 else base)
            if k == len(spots) - 1 and f > 0.35:
                g = nxt
            # 장단 안에서도 살짝 움직인다 — 골격이 한 음에 못 박히면 죽는다
            if k == 1:
                g = int(np.clip(g + self.rng.choice([-1, 0, 1], p=[.3, .35, .35]),
                                self.lo, self.hi))
            out.append((float(s), int(np.clip(g, self.lo, self.hi))))
        return out

    # ── 잔가락: 골격 사이를 메운다. 매번 다르게.
    def fill(self, bones, density, breath=False):
        """
        bones: [(소박, 음도)].  density: 0~1, 얼마나 잘게 메울지.
        breath=True 면 장단 끝을 비운다 — 숨 쉴 자리. 이게 없으면 사람이 아니다.
        돌려주는 것: [(소박, 길이[소박], 음도)]
        """
        r = self.rng
        n = self.n
        end = n - (r.choice([2, 3]) if breath else 0)
        notes = []
        for k, (s, g) in enumerate(bones):
            s2, g2 = (bones[k + 1] if k + 1 < len(bones) else (end, bones[0][1]))
            room = max(0.0, s2 - s)
            if s >= end:
                break
            # ① 앞꾸밈 — 큰 음 바로 앞에 잘게 하나. 국악 선율의 숨결이다.
            if k > 0 and room >= 1.5 and r.random() < 0.30 + 0.35 * density:
                gr = g + int(r.choice([1, -1, 2], p=[.5, .35, .15]))
                notes.append((s - 0.5, 0.5, int(np.clip(gr, self.lo, self.hi))))
            # ② 골격음 자체 — 남는 자리에 따라 길게
            hold = room * (0.75 - 0.45 * density)
            hold = float(np.clip(hold, 0.75, max(0.75, room)))
            notes.append((s, hold, g))
            # ③ 사이 메우기 — 골격에서 다음 골격으로 걸어간다
            t = s + hold
            step = 1 if g2 >= g else -1
            cur = g
            while t < min(s2, end) - 0.25:
                if r.random() > 0.35 + 0.6 * density:
                    t += 0.5
                    continue
                gap = g2 - cur
                if abs(gap) >= 1:
                    cur = cur + step                       # 순차로 걸어간다
                else:
                    cur = cur + int(r.choice([1, -1, 0], p=[.35, .45, .20]))  # 이웃음
                cur = int(np.clip(cur, self.lo, self.hi))
                d = float(r.choice([0.5, 0.5, 1.0, 1.5], p=[.34, .30, .26, .10]))
                d = min(d, min(s2, end) - t)
                if d < 0.4:
                    break
                notes.append((t, d, cur))
                t += d
        return [x for x in notes if 0 <= x[0] < end]

    def voice(self, notes, t0, sobak, inst, cadence=True):
        """음마다 시김새를 붙여 연주 지시로. (시각, 길이, 음도, 농현, 꺾기, 주법)"""
        out = []
        prev = None
        seen = {}
        for i, (s, d, g) in enumerate(sorted(notes)):
            role = "mid"
            if cadence and i == len(notes) - 1:
                role = "cadence"
            elif d >= 2.5:
                role = "mid"
            rep = seen.get(g, 0) > 0
            seen[g] = seen.get(g, 0) + 1
            nong, bend, art = sigim(self.m, g, d, role, prev, rep, inst)
            out.append((t0 + s * sobak, d * sobak, g, nong, bend, art))
            prev = g
        return out


# ── 장면마다의 여정. 이게 곡의 '이야기' 다. 되풀이가 아니라 어디로 가느냐.
ARC = {
    # 마을 낮 — 궁에서 나가 한 옥타브 위까지 올랐다가 돌아온다. 밝고 트인 길
    "village_day":   [0, 1, 3, 4, 3, 5, 4, 3, 1, 0],
    # 마을 밤 — 낮은 자리를 맴돌다 한 번만 위를 본다. 낮의 여정을 뒤집은 모양
    "village_night": [0, -1, 0, 2, 1, 3, 2, 0, -1, 0],
    # 전투 — 계속 밀어 올린다. 내려오지 않는다
    "battle":        [0, 2, 3, 4, 3, 5, 4, 5, 6, 5, 3, 0],
    # 원정 — 걸음. 오르내림이 얕고 꾸준하다
    "journey":       [0, 1, 2, 3, 2, 4, 3, 4, 3, 1, 0],
}

# 곡이 흐르는 동안 잔가락이 얼마나 잘아지는가 — 점층. 끝에서 다시 성기게.
def density_at(pos, peak=0.72, lo=0.30):
    """pos 0~1. 가운데가 가장 잘고, 처음과 끝은 성기다."""
    return float(lo + (peak - lo) * np.sin(np.pi * min(1.0, max(0.0, pos))) ** 0.8)

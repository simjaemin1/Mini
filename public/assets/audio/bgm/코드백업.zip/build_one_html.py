"""build_one_html.py — 12곡 + 악기 현황 + 조율 + 감식을 하나의 HTML 로. mp3 만 쓴다(사파리)."""
import os
import json
import base64
import subprocess

OUT = "_one"
NOTE = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
nm = lambda m: f"{NOTE[int(round(m)) % 12]}{int(round(m)) // 12 - 1}"
TITLES = [("village_day_trad", "마을 낮 · 전통"), ("village_day_amb", "마을 낮 · 앰비언트"),
          ("village_day_ari", "마을 낮 · 아리랑"),
          ("village_night_trad", "마을 밤 · 전통"), ("village_night_amb", "마을 밤 · 앰비언트"),
          ("village_night_ari", "마을 밤 · 아리랑"),
          ("battle_trad", "전투 · 전통"), ("battle_amb", "전투 · 앰비언트"),
          ("battle_ari", "전투 · 아리랑"),
          ("journey_trad", "원정 · 전통"), ("journey_amb", "원정 · 앰비언트"),
          ("journey_ari", "원정 · 아리랑")]


def b64(p):
    return "data:audio/mpeg;base64," + base64.b64encode(open(p, "rb").read()).decode()


def main():
    os.makedirs(OUT, exist_ok=True)
    meta = json.load(open("out_samples/meta.json"))
    score = json.load(open("score.json"))
    banks = {}
    for root, label in [("samples_gaya", "산조가야금"), ("samples_danso", "단소")]:
        if os.path.exists(f"{root}/_index.json"):
            banks[label] = json.load(open(f"{root}/_index.json"))

    # 악기별 사용량
    use = {}
    for notes in score.values():
        for e in notes:
            use[e["inst"]] = use.get(e["inst"], 0) + 1
    real = {k for k, v in meta["source"].items() if v == "샘플"}

    blocks = []
    for k, title in TITLES:
        src = f"out_samples/{k}.wav"
        if not os.path.exists(src):
            continue
        mp = f"{OUT}/{k}.mp3"
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", src, "-t", "36",
                        "-c:a", "libmp3lame", "-b:a", "112k", mp], check=True)
        t = meta["tracks"].get(k, {})
        octs = " · ".join(f"{a} {b:+d}옥타브" for a, b in (t.get("octaves") or {}).items())
        blocks.append(
            f'<div class="tr"><div class="th"><b>{title}</b>'
            f'<span class="sub">{t.get("seconds","?")}초 · 앞 36초</span></div>'
            f'<audio controls preload="none" src="{b64(mp)}"></audio>'
            + (f'<div class="meta">성부 이동: {octs}</div>' if octs else '') + '</div>')

    inst_ko = {"gayageum": "가야금", "danso": "단소", "daegeum": "대금", "piri": "피리",
               "geomungo": "거문고", "janggu_gung": "장구 궁편", "janggu_chae": "장구 채편",
               "buk": "북", "jing": "징", "kkwaenggwari": "꽹과리", "bak": "박"}
    rows = "".join(
        f'<tr><td>{inst_ko.get(i,i)}</td><td class="n">{n}</td>'
        f'<td class="{"ok" if i in real else "no"}">'
        f'{"국립국악원 실제 녹음" if i in real else "합성음"}</td></tr>'
        for i, n in sorted(use.items(), key=lambda t: -t[1]))

    tun = ""
    for label, idx in banks.items():
        t = idx.get("tuning", {}).get("gayageum") or {}
        n = len(idx["entries"])
        arts = {}
        for e in idx["entries"]:
            arts[e.get("art")] = arts.get(e.get("art"), 0) + 1
        import sampler as SP
        alist = ", ".join(f"{SP.ART_NAME_KO.get(a,a)} {c}"
                          for a, c in sorted(arts.items(), key=lambda x: -x[1]))
        line = ""
        if t.get("strings"):
            line = (f'<p class="note">12현 조율 <code>{" ".join(nm(s) for s in t["strings"])}</code>'
                    f' · 전역 {t["offset_semi"]*100:+.0f}센트 (A≈{440*2**(t["offset_semi"]/12):.1f}Hz)'
                    f' · 5음계 잔차 {t["residual_cents"]:.0f}센트</p>')
        tun += (f'<h3>{label}</h3><p class="note">조각 {n}개 · {alist}</p>{line}')

    html = f"""<!doctype html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>두랑고 BGM — 국악기 실음원판</title><style>
:root{{--bg:#12100e;--fg:#efe7db;--dim:#a99a86;--line:#332c25;--acc:#d8a25a}}
*{{box-sizing:border-box}}
body{{margin:0;background:var(--bg);color:var(--fg);font:15px/1.65 -apple-system,BlinkMacSystemFont,"Apple SD Gothic Neo","Noto Sans KR",sans-serif}}
.wrap{{max-width:820px;margin:0 auto;padding:26px 18px 80px}}
h1{{font-size:24px;margin:0 0 6px}}
h2{{font-size:17px;margin:34px 0 8px;padding-bottom:6px;border-bottom:1px solid var(--line)}}
h3{{font-size:14px;margin:16px 0 4px;color:var(--acc)}}
.lead{{color:var(--dim);margin:0 0 18px}}
.tr{{border:1px solid var(--line);border-radius:10px;padding:12px 14px;margin:10px 0;background:#181410}}
.th{{display:flex;gap:9px;align-items:baseline;margin-bottom:9px}}
.sub{{color:var(--dim);font-size:12px}}
audio{{width:100%;height:34px}}
.meta{{color:var(--dim);font-size:12px;margin-top:7px}}
table{{border-collapse:collapse;font-size:13px;width:100%;margin:8px 0}}
th,td{{border:1px solid var(--line);padding:4px 9px;text-align:left}}
th{{color:var(--dim);font-weight:400}}
td.n{{text-align:right}} td.ok{{color:#7fd08a}} td.no{{color:#a99a86}}
.note{{color:var(--dim);font-size:12.5px;margin:4px 0}}
code{{font-size:12px}}
footer{{margin-top:40px;padding-top:14px;border-top:1px solid var(--line);color:var(--dim);font-size:12.5px}}
</style></head><body><div class="wrap">
<h1>두랑고 BGM — 국악기 실음원판</h1>
<p class="lead">가야금과 단소를 국립국악원 실제 녹음으로 바꿨습니다. 아래는 12곡 앞 36초씩입니다.</p>

<h2>악기 현황</h2>
<table><tr><th>악기</th><th>쓰인 음</th><th>소리 출처</th></tr>{rows}</table>
<p class="note">전투 계열 두 곡은 거문고·장구·징 편성이라 아직 전부 합성음입니다.</p>

<h2>음원</h2>
{tun}
<p class="note">조율은 검출값을 '전역 오프셋 + 정수 반음' 으로 풀어 확정한 것입니다.
산조가야금은 A≈446Hz 로 조율된 C 평조 12현이고, 곡의 조를 여기에 맞춰 옮겼습니다
(평조는 으뜸음 G, 계면조는 A 일 때 12현에 그대로 얹힙니다).
그 결과 음정을 억지로 늘리는 양이 최대 2.32반음 → 0.52반음으로 줄었습니다.</p>

<h2>12곡</h2>
{''.join(blocks)}

<footer>국악기 음원 제공 — 국립국악원 (공공누리 제1유형)<br>
남은 악기(거문고·대금·향피리·장구·징·꽹과리·좌고·박)는 음원을 받는 대로 같은 방식으로 합류시킵니다.</footer>
</div></body></html>"""
    p = "두랑고BGM_통합.html"
    open(p, "w").write(html)
    print(f"{p}  {os.path.getsize(p)/1e6:.1f}MB  트랙 {len(blocks)}개")
    return p


if __name__ == "__main__":
    main()

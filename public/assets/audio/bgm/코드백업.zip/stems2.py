"""stems2.py — 새 12곡을 악기 층으로 분리 (믹서용). 정규화를 꺼 실제 음량 비를 지킨다."""
import os
import json
import numpy as np
import gugak as G
import sampler as S
import compose as C
import tracks2 as T
from render2 import ROOTS

INSTS = ["daegeum", "danso", "piri", "gayageum", "geomungo",
         "janggu_gung", "janggu_chae", "buk", "jing", "kkwaenggwari",
         "bak", "wind", "water", "crickets"]
GROUPS = {"winds": (["daegeum", "danso", "piri"], "대금·단소·피리"),
          "gayageum": (["gayageum"], "가야금"),
          "geomungo": (["geomungo"], "거문고"),
          "janggu": (["janggu_gung", "janggu_chae"], "장구"),
          "metal": (["jing", "kkwaenggwari", "buk", "bak"], "징·꽹과리·북·박"),
          "amb": (["wind", "water", "crickets"], "자연음")}
EXCERPT = (8.0, 34.0)


def _sil(*a, **k):
    return np.zeros(0, np.float32)


def render_only(spec, keep):
    """keep 에 든 악기만 남기고 렌더링.
    ★한 모듈만 끄면 안 된다 — 장구는 compose.play_jangdan 이 **compose 의 이름**으로,
      자연음은 tracks2 가 **gugak 의 이름**으로 부른다. 셋 다 꺼야 층이 층이 된다.
      (tracks2 만 껐을 때는 모든 층에 장구가 그대로 남아 층마다 음량이 똑같았다.)"""
    saved = {}
    for mod in (C, T, G):
        for n in INSTS:
            if hasattr(mod, n):
                saved[(mod, n)] = getattr(mod, n)
                if keep is not None and n not in keep:
                    setattr(mod, n, _sil)
    try:
        return spec["fn"]()
    finally:
        for (mod, n), f in saved.items():
            setattr(mod, n, f)


def main():
    os.makedirs("stems", exist_ok=True)
    bank = S.Bank(ROOTS)
    orig = G.Mix.render
    G.Mix.render = lambda self, *a, **k: orig(self, *a, **{**k, "norm": False})
    man = {}
    try:
        for key, spec in T.TRACKS.items():
            S.install(bank, [C, T])
            full = render_only(spec, None)
            rms = float(np.sqrt(np.mean(full ** 2))) + 1e-12
            gain = (10 ** (-15.0 / 20)) / rms
            a, b = int(EXCERPT[0] * G.SR), int(EXCERPT[1] * G.SR)
            rows = []
            for gk, (keep, ko) in GROUPS.items():
                S.install(bank, [C, T])
                y = render_only(spec, set(keep))
                r = float(np.sqrt(np.mean(y ** 2)))
                if r < 1e-6:
                    continue
                G.write_wav(f"stems/{key}__{gk}.wav", np.clip(y[:, a:b] * gain, -1, 1))
                rows.append([gk, ko, round(20 * np.log10(r / rms + 1e-12), 1)])
            rows.sort(key=lambda x: -x[2])
            man[key] = rows
            print(f"  {key:22s} 층 {len(rows)}개  " +
                  " ".join(f"{l}({d:+.0f}dB)" for _, l, d in rows), flush=True)
    finally:
        G.Mix.render = orig
    json.dump(man, open("stems/_manifest.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()

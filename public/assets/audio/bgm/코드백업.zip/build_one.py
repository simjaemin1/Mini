"""
build_one.py — 전부를 담은 HTML 한 개를 굽는다.

모든 소리는 MP3 base64 로 파일 안에 들어간다(Safari 는 Ogg 를 재생하지 못한다).
실시간 절차 엔진(bgm.js)도 통째로 인라인하므로 파일 하나만 있으면 전부 동작한다.
"""
import base64
import json
import os

SRC = "one"


def b64(name):
    with open(os.path.join(SRC, name), "rb") as f:
        return "data:audio/mpeg;base64," + base64.b64encode(f.read()).decode()


def au(name, cls=""):
    return f'<audio class="{cls}" controls loop preload="none" src="{b64(name)}"></audio>'


TRACKS = [
    ("village_day_trad", "마을 낮 · 전통", "평조 · 굿거리 · 대금/가야금/장구"),
    ("village_day_amb", "마을 낮 · 앰비언트", "패드 · 성긴 가야금 · 개울"),
    ("village_day_ari", "마을 낮 · 아리랑", "세마치 · 대금 본가락 (3절)"),
    ("village_night_trad", "마을 밤 · 전통", "계면조 · 진양조 · 저취 대금/거문고"),
    ("village_night_amb", "마을 밤 · 앰비언트", "저역 드론 · 단소 숨결 · 풀벌레"),
    ("village_night_ari", "마을 밤 · 아리랑", "아주 느린 3박 → 2절은 단소"),
    ("battle_trad", "전투 · 전통", "자진모리→휘모리 · 북/꽹과리/피리"),
    ("battle_amb", "전투 · 앰비언트", "드론 · 심장박동 타악 · 반음 불협"),
    ("battle_ari", "전투 · 아리랑", "몰아치는 3박 · 피리 (4절)"),
    ("journey_trad", "원정 · 전통", "평조 · 세마치 · 가야금 아르페지오"),
    ("journey_amb", "원정 · 앰비언트", "넓은 패드 · 발소리 펄스 · 먼 대금"),
    ("journey_ari", "원정 · 아리랑", "걷는 세마치 · 가야금 + 대금"),
]

LAYER_TR = [("village_day_trad", "마을 낮 · 전통"), ("village_night_trad", "마을 밤 · 전통"),
            ("village_day_amb", "마을 낮 · 앰비언트"), ("journey_trad", "원정 · 전통")]

INST_AB = [
    ("hits", "단타 — 궁편 ×3 · 채편 ×3 · 북 ×2",
     "옛것: 사인파 1개 + 잡음. 새것: 원형막 고유모드 16개 + 오동나무 통 공진 + 타격 접촉음."),
    ("jangdan", "굿거리 한 장단 ×2 (장구만)",
     "옛 채편은 520·1200Hz 고정 배음이 <b>매 타점마다 같은 선</b>으로 남았습니다. 새것은 칠 때마다 타점 위치가 달라 모드 구성이 바뀝니다."),
    ("gayageum", "가야금 — 단음 3 + 짧은 악구",
     "현만 있고 <b>공명통이 없었습니다</b>. 오동나무 판 공진 5개와 손톱이 명주현을 뜯는 순간음을 넣었습니다."),
    ("geomungo", "거문고 — 단음 3 + 짧은 악구",
     "옛것은 <b>가야금에 저역 필터를 씌운 것</b>이었습니다. 거문고는 뜯는 악기가 아니라 <b>술대(대나무 채)로 때리는</b> 악기입니다."),
]

VS_SAMPLE = [
    ("가야금", "gaya_mine", "gaya_koto", "고토 (일본 13현)",
     "같은 치터 계열이라 가장 가깝지만 <b>농현(왼손 흔들기)이 샘플에는 없습니다</b>."),
    ("대금", "wind_mine", "wind_shaku", "샤쿠하치 (일본 세로피리)",
     "둘 다 대나무 피리지만 <b>대금의 청(갈대막) 울림이 없습니다</b>."),
    ("거문고", "geo_mine", "geo_shami", "샤미센 (일본 3현)",
     "발목으로 때리는 성격은 맞지만 가죽 울림통이라 훨씬 건조합니다."),
    ("장구", "jang_mine", "jang_sample", "다이코 + 팀발레",
     "<b>한 통을 두 가죽이 나눠 쓰는 장구의 울림</b>은 다른 두 악기를 겹쳐서는 나오지 않습니다."),
]

CSS = """
:root{--bg:#14110e;--panel:#1e1a15;--line:#3a322a;--ink:#e9e0d2;--dim:#a39683;
 --acc:#c99a4e;--red:#c98b6e;--grn:#8fb08a}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;background:var(--bg);color:var(--ink);
 font-family:-apple-system,BlinkMacSystemFont,"Apple SD Gothic Neo","Noto Sans KR",sans-serif;
 line-height:1.6;-webkit-text-size-adjust:100%}
.wrap{max-width:980px;margin:0 auto;padding:0 20px 80px}
header{position:sticky;top:0;z-index:20;background:rgba(20,17,14,.96);
 -webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);border-bottom:1px solid var(--line);
 padding:14px 20px 0}
header .in{max-width:980px;margin:0 auto}
h1{font-size:19px;margin:0 0 2px}
.lead{color:var(--dim);font-size:12.5px;margin:0 0 10px}
nav{display:flex;gap:4px;flex-wrap:wrap;padding-bottom:10px}
nav a{color:var(--dim);text-decoration:none;font-size:12.5px;padding:5px 10px;
 border:1px solid var(--line);border-radius:20px;white-space:nowrap}
nav a:hover{color:var(--ink);border-color:var(--acc)}
h2{font-size:16px;color:var(--acc);border-bottom:1px solid var(--line);
 padding-bottom:8px;margin:38px 0 6px;scroll-margin-top:120px}
.h2sub{color:var(--dim);font-size:12.5px;margin:0 0 14px}
h3{font-size:14px;color:var(--acc);margin:0 0 9px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(290px,1fr));gap:11px}
.grid.sm{grid-template-columns:repeat(auto-fill,minmax(255px,1fr))}
.two{display:grid;grid-template-columns:1fr 1fr;gap:12px}
@media(max-width:680px){.two{grid-template-columns:1fr}}
.card,.pair{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:13px 14px}
.pair{margin-bottom:12px}
.card.full{border-color:var(--acc);margin-bottom:11px}
.nm{font-size:13.5px;font-weight:600;display:flex;justify-content:space-between;
 align-items:baseline;gap:8px}
.meta{color:var(--dim);font-size:11.5px;margin:1px 0 8px}
.db{color:var(--dim);font-size:11px;font-weight:400;white-space:nowrap}
.tag{font-size:11.5px;margin-bottom:5px}
.tag.old,.tag.syn{color:var(--red)}.tag.new,.tag.smp{color:var(--grn)}
audio{width:100%;height:34px;display:block}
.why{color:var(--dim);font-size:12.5px;margin-top:10px;padding-top:9px;border-top:1px solid var(--line)}
.warn{background:#1c1712;border:1px solid #55452c;border-radius:10px;padding:13px 15px;
 font-size:12.8px;color:#d8c8a8;margin:14px 0}
b{color:var(--ink)}
code{background:#241f18;padding:2px 5px;border-radius:4px;font-size:12px;color:#d9c79f}
pre{background:#191510;border:1px solid var(--line);border-radius:9px;padding:13px;
 overflow:auto;font-size:12px;color:#d3c7b2}
table{width:100%;border-collapse:collapse;font-size:12.5px;margin-top:6px}
td,th{border-bottom:1px solid var(--line);padding:6px 8px;text-align:left}
th{color:var(--acc);font-weight:600}
.row{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:9px}
button{background:#2b2419;color:var(--ink);border:1px solid var(--line);border-radius:7px;
 padding:7px 13px;font-size:13px;cursor:pointer;font-family:inherit}
button:hover{border-color:var(--acc)}
button.on{background:var(--acc);color:#20180c;border-color:var(--acc);font-weight:600}
button.big{padding:9px 18px}
label{font-size:12px;color:var(--dim);min-width:70px;display:inline-block}
input[type=range]{flex:1;min-width:140px;accent-color:var(--acc)}
.val{font-size:12px;color:var(--grn);min-width:44px;text-align:right}
"""

JS_TAIL = """
// 한 번에 하나만 재생 — 43개가 겹쳐 울리지 않게
document.addEventListener('play', function (e) {
  document.querySelectorAll('audio').forEach(function (a) {
    if (a !== e.target) a.pause();
  });
}, true);

var SCENES = [['village_day','마을 낮'],['village_night','마을 밤'],['battle','전투'],['journey','원정']];
var MOODS  = [['trad','전통색'],['amb','앰비언트'],['ari','아리랑']];
var bgm = DurangoBGM.create({ volume: 0.5 });
function chips(hostId, list, get, set){
  var host = document.getElementById(hostId);
  list.forEach(function(it){
    var b = document.createElement('button');
    b.textContent = it[1]; b.dataset.v = it[0];
    b.onclick = function(){ set(it[0]); paint(); };
    host.appendChild(b);
  });
  function paint(){
    Array.prototype.forEach.call(host.children, function(b){
      b.classList.toggle('on', b.dataset.v === get());
    });
  }
  paint(); return paint;
}
var pScene = chips('scenes', SCENES, function(){return bgm.scene;}, function(v){bgm.setScene(v);});
var pMood  = chips('moods',  MOODS,  function(){return bgm.mood;},  function(v){bgm.setMood(v);});
document.getElementById('engStart').onclick = function(){
  document.querySelectorAll('audio').forEach(function(a){a.pause();});
  bgm.start().then(function(){ document.getElementById('engState').textContent = '연주 중'; });
};
document.getElementById('engStop').onclick = function(){
  bgm.stop(); document.getElementById('engState').textContent = '멈춤';
};
function bind(id, fn, fmt){
  var s = document.getElementById(id), v = document.getElementById(id+'V');
  s.oninput = function(){ fn(+s.value); v.textContent = fmt(+s.value); };
}
bind('inten', function(x){bgm.setIntensity(x);}, function(x){return x.toFixed(2);});
bind('vol',   function(x){bgm.setVolume(x);},    function(x){return x.toFixed(2);});
bind('phase', function(x){ bgm.setDayPhase(x); pScene(); }, function(x){
  var h = Math.floor(x*24), m = Math.floor((x*24-h)*60);
  return ('0'+h).slice(-2)+':'+('0'+m).slice(-2);
});
setInterval(function(){ pScene(); pMood(); }, 900);

// 12곡은 같은 폴더의 파일을 읽는다 — 못 읽으면 안내를 띄운다
document.querySelectorAll('audio[data-track]').forEach(function(a){
  a.addEventListener('error', function(){
    var w = document.getElementById('trWarn');
    if (w) w.style.display = '';
  }, true);
});
"""


def build():
    S = []

    # ---------------------------------------------------------- ① 곡
    # 12곡은 같은 폴더의 음원 파일을 읽는다(파일 하나에 다 넣으면 35MB 를 넘는다).
    # ogg 를 먼저 두고 m4a 를 폴백으로 — Safari 는 ogg 를 재생하지 못한다.
    cards = "".join(
        f'<div class="card"><div class="nm">{t}</div><div class="meta">{d}</div>'
        f'<audio controls loop preload="none" data-track="{k}">'
        f'<source src="./{k}.ogg" type="audio/ogg">'
        f'<source src="./{k}.m4a" type="audio/mp4"></audio></div>'
        for k, t, d in TRACKS)
    S.append('<h2 id="s1">① 곡 12개</h2>'
             '<p class="h2sub">장면 4개 × 분위기 3개. 각 90~120초, 이음매 없이 반복됩니다.</p>'
             '<div class="warn" id="trWarn" style="display:none">이 12곡만 <b>같은 폴더의 음원 파일</b>을 읽습니다. '
             '지금 재생되지 않는다면 이 HTML 을 <code>public/assets/audio/bgm/</code> 안에 두고 여세요. '
             '아래 ③~⑥ 항목은 파일 안에 소리가 들어 있어 어디서든 재생됩니다.</div>'
             f'<div class="grid">{cards}</div>')

    # ---------------------------------------------------------- ② 실시간 엔진
    S.append('''<h2 id="s2">② 실시간 절차 생성 엔진 (파일 0바이트)</h2>
<p class="h2sub">브라우저가 직접 작곡·연주합니다. 이 페이지 안에 엔진이 통째로 들어 있습니다.</p>
<div class="card">
 <div class="row"><button class="big" id="engStart">▶ 시작</button>
  <button class="big" id="engStop">■ 정지</button>
  <span class="meta" id="engState" style="margin:0 0 0 6px">멈춤</span></div>
 <div class="row"><label>장면</label><span id="scenes"></span></div>
 <div class="row"><label>분위기</label><span id="moods"></span></div>
 <div class="row"><label>격렬도</label><input type="range" id="inten" min="0" max="1" step="0.01" value="0.6"><span class="val" id="intenV">0.60</span></div>
 <div class="row"><label>음량</label><input type="range" id="vol" min="0" max="1" step="0.01" value="0.5"><span class="val" id="volV">0.50</span></div>
 <div class="row"><label>게임 시각</label><input type="range" id="phase" min="0" max="1" step="0.005" value="0.5"><span class="val" id="phaseV">12:00</span></div>
 <div class="why">격렬도를 0.8 이상으로 올리면 전투 장단이 자진모리 → 휘모리로 조여듭니다.
  게임 시각을 밤(20시 이후)으로 넘기면 마을 낮/밤이 자동 전환됩니다.</div>
</div>''')

    # ---------------------------------------------------------- ③ 층 분리
    sub = ['<h2 id="s3">③ 층 분리 — 어느 소리인지 찾기</h2>'
           '<p class="h2sub">층별 음량은 <b>완성본 안에서의 실제 크기 그대로</b>입니다. '
           '옆의 dB는 완성본 대비 기여도.</p>']
    sub.append(f'''<div class="two">
 <div class="pair"><div class="tag old">마을 낮·전통 <b>고치기 전</b></div>{au("dg_ab__village_day_trad__before.mp3")}</div>
 <div class="pair"><div class="tag new">마을 낮·전통 <b>고친 뒤</b></div>{au("dg_ab__village_day_trad__after.mp3")}</div>
 <div class="pair"><div class="tag old">가야금만 <b>고치기 전</b> — A#2~G4, 21반음</div>{au("dg_ab__gayageum__before.mp3")}</div>
 <div class="pair"><div class="tag new">가야금만 <b>고친 뒤</b> — F3~G4, 12반음</div>{au("dg_ab__gayageum__after.mp3")}</div>
</div>
<div class="warn"><b>① 가야금 반주가 악기 음역 밖에서 뛰어다녔습니다.</b>
 반주 음을 고르는 식에 <code>steps[i%5] % 10 - 5</code> 라는 실수가 있어 A#2(116Hz)~G4 를 21반음씩 도약했습니다.
 실제 가야금 최저현은 D3(146Hz)입니다. 울림 1.9초 / 음 간격 0.395초라 항상 4~5음이 겹쳐 울렸습니다.
 → 한 옥타브 안에서 순차로 움직이게 고치고 울림도 1.15초로 줄였습니다(90~150Hz 성분 <b>14.7dB</b> 감소).
 <br><br><b>② 대금·단소 숨소리가 모두 같은 위상으로 떨렸습니다.</b>
 고정 3.1Hz 트레몰로가 음마다 t=0 에서 시작해 <b>모든 음이 같은 박자로 같이</b> 떨렸습니다.
 → 음마다 속도(2.2~4.4Hz)와 위상을 다르게 하고 깊이도 절반으로 줄였습니다.</div>''')
    for tr, title in LAYER_TR:
        rows = json.load(open(f"diag/{tr}.json"))
        cs = "".join(f'<div class="card"><div class="nm">{lab}<span class="db">{db:+.1f} dB</span></div>'
                     f'{au(f"dg_{tr}__{k}.mp3")}</div>' for k, lab, db in rows)
        sub.append(f'<h3 style="margin-top:22px">{title}</h3>'
                   f'<div class="card full"><div class="nm">전체 (완성본)</div>{au(f"dg_{tr}__full.mp3")}</div>'
                   f'<div class="grid sm">{cs}</div>')
    S.append("".join(sub))

    # ---------------------------------------------------------- ④ 악기 옛것/새것
    cs = "".join(
        f'<div class="pair"><h3>{lab}</h3><div class="two">'
        f'<div><div class="tag old">고치기 전</div>{au(f"ab_{k}_old.mp3")}</div>'
        f'<div><div class="tag new">새로 만든 것</div>{au(f"ab_{k}_new.mp3")}</div>'
        f'</div><div class="why">{why}</div></div>' for k, lab, why in INST_AB)
    S.append('<h2 id="s4">④ 악기 소리 다시 만들기 — 옛것 / 새것</h2>'
             '<p class="h2sub">믹스에 묻히지 않게 단독 타점과 짧은 악구만 담았습니다.</p>'
             '<div class="warn">이건 <b>녹음이 아니라 합성음</b>입니다. 물리 모형을 코드로 세워 만든 것이라 '
             '아무리 다듬어도 진짜 장구·가야금·거문고와는 다릅니다.</div>' + cs)

    # ---------------------------------------------------------- ⑤ 합성음 vs 실샘플
    cs = "".join(
        f'<div class="pair"><h3>{nm}</h3><div class="two">'
        f'<div><div class="tag syn">내 합성음</div>{au(f"sf_{a}.mp3")}</div>'
        f'<div><div class="tag smp">실제 녹음 — {alt}</div>{au(f"sf_{b}.mp3")}</div>'
        f'</div><div class="why">{why}</div></div>' for nm, a, b, alt, why in VS_SAMPLE)
    S.append('<h2 id="s5">⑤ 합성음 vs 실제 녹음 샘플</h2>'
             '<p class="h2sub">같은 가락(아리랑 1~4마디)·같은 박자·같은 음량. 장구만 굿거리 두 장단입니다.</p>'
             '<div class="warn">오른쪽은 실제 악기를 녹음한 샘플이지만 <b>전부 일본 악기입니다</b> — '
             'GM 규격에 국악기가 없어 고토·샤쿠하치·샤미센·다이코가 들어 있습니다.</div>' + cs)

    # ---------------------------------------------------------- ⑥ 샘플러
    S.append(f'''<h2 id="s6">⑥ 진짜 국악기로 바꾸기 — 샘플러</h2>
<p class="h2sub">음원이 들어오면 실제로 갈아끼워지는지 <b>대역 음원</b>으로 전 과정을 돌린 것입니다.</p>
<div class="warn">오른쪽은 <b>진짜 국악기가 아닙니다.</b> 국악 음원이 없어 사운드폰트를 폴더에 넣고 돌린 것입니다.
 여기서 볼 것은 <b>"폴더에 wav 를 넣으면 곡의 악기가 실제로 바뀌는가"</b> 입니다.</div>
<div class="pair"><h3>마을 낮 · 아리랑</h3><div class="two">
 <div><div class="tag syn">합성음</div>{au("sf_village_day_ari_synth.mp3")}</div>
 <div><div class="tag smp">샘플러를 거친 것</div>{au("sf_village_day_ari_sampler.mp3")}</div></div></div>
<div class="pair"><h3>원정 · 전통</h3><div class="two">
 <div><div class="tag syn">합성음</div>{au("sf_journey_trad_synth.mp3")}</div>
 <div><div class="tag smp">샘플러를 거친 것</div>{au("sf_journey_trad_sampler.mp3")}</div></div></div>
<div class="warn"><b>검증한 것</b><table>
<tr><th>항목</th><th>결과</th></tr>
<tr><td>음정 자동 검출 (파일명에 음이름 없이)</td><td>21음 <b>전부 정확</b></td></tr>
<tr><td>임의 음높이 리샘플링 정확도</td><td>59음, <b>최대 오차 11.7센트</b></td></tr>
<tr><td>장구 궁편/채편 자동 분리</td><td>밝기 기준으로 분리됨</td></tr>
<tr><td>음원 없는 악기 → 합성음 자동 대체</td><td>단소·피리·북·징·꽹과리 유지됨</td></tr>
<tr><td>곡 전체 렌더링</td><td>클리핑 0 · 길이·음량 기존과 동일</td></tr></table></div>
<div class="warn"><b>음원 받는 곳</b> — 국립국악원 국악기 디지털 음원 <code>gugak.go.kr/digitaleum</code> 의 <b>「단음」</b>.
 <b>공공누리 제1유형</b>이라 출처만 표시하면 상업적 이용·변형까지 자유입니다.
 받아서 <code>public/assets/audio/bgm/samples/</code> 에 넣고 두 줄만 실행하면 됩니다 —
 폴더 구조는 아무래도 괜찮고 경로 어딘가에 악기 이름만 있으면 됩니다.
 <pre>python3 sampler.py scan samples/
python3 render_samples.py samples/</pre>
 크레딧 문구: <code>국악기 음원 제공 — 국립국악원 (공공누리 제1유형)</code></div>''')

    # ---------------------------------------------------------- ⑦ 붙이기
    S.append('''<h2 id="s7">⑦ 게임에 붙이기</h2>
<p class="h2sub">파일 재생과 실시간 합성 중 하나를 고르면 됩니다. API 모양이 거의 같아 서로 바꿔 끼울 수 있습니다.</p>
<pre>&lt;!-- 파일 재생 (권장) --&gt;
&lt;script src="/assets/audio/bgm/bgm-loops.js"&gt;&lt;/script&gt;
const bgm = DurangoLoops.create({ base: '/assets/audio/bgm/', volume: 0.35 });
document.addEventListener('click', () =&gt; bgm.start(), { once: true });

&lt;!-- 또는 파일 0바이트 실시간 합성 --&gt;
&lt;script src="/assets/audio/bgm/bgm.js"&gt;&lt;/script&gt;
const bgm = DurangoBGM.create({ volume: 0.35 });

// 게임 루프에서
bgm.setDayPhase(worldTimeOfDay);   // 0..1 — 마을 낮/밤 자동 전환
bgm.setScene(inCombat ? 'battle' : (outsideVillage ? 'journey' : 'village_day'));
bgm.setMood('ari');                // trad | amb | ari
bgm.setIntensity(threatLevel);     // 0..1 (실시간 엔진 전용)</pre>
<div class="warn"><b>남은 일</b> — ① client.js 배선(제가 하겠습니다) ② 오디오 39MB 를 git 에 넣을지
 ③ 국악 실음원 도입 여부. 아무것도 안 하셔도 지금 상태로 동작합니다.</div>''')

    nav = "".join(f'<a href="#s{i}">{t}</a>' for i, t in [
        (1, "곡 12개"), (2, "실시간 엔진"), (3, "층 분리"), (4, "악기 옛것/새것"),
        (5, "합성 vs 실샘플"), (6, "샘플러"), (7, "붙이기")])

    with open("bgm.js") as f:
        engine = f.read()

    html = f'''<!DOCTYPE html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>두랑고 미니 · BGM</title><style>{CSS}</style></head><body>
<header><div class="in"><h1>두랑고 미니 · BGM</h1>
<p class="lead">청동기 후기 배경 국악 편성. 전부 코드로 합성했고, 소리는 이 파일 안에 들어 있습니다.</p>
<nav>{nav}</nav></div></header>
<div class="wrap">{"".join(S)}</div>
<script>{engine}</script>
<script>{JS_TAIL}</script>
</body></html>'''
    with open("두랑고_BGM.html", "w") as f:
        f.write(html)
    print(f"두랑고_BGM.html  {os.path.getsize('두랑고_BGM.html')/1e6:.1f} MB")


if __name__ == "__main__":
    build()

"""장구 조각이 국악원 원본과 같은 파형인지 대조할 물증을 만든다."""
import os, json, subprocess, numpy as np
from scipy.io import wavfile
idx=json.load(open("samples_janggu/_index.json"))
os.makedirs("_aud", exist_ok=True)
pick={}
for e in idx["entries"]:
    src=e["src"]
    if src not in pick or e["secs"]>pick[src]["secs"]: pick[src]=e
man=[]
for src,e in sorted(pick.items()):
    x=wavfile.read(os.path.join("samples_janggu",e["wav"]))[1].astype(np.float64)/32768
    if x.ndim>1: x=x.mean(1)
    x=x/(np.abs(x).max()+1e-9)*0.9
    base=os.path.basename(src).replace("장구_","").replace(".wav","")
    name=f"janggu__{base}.flac"
    tmp=f"_aud/{name}.wav"
    wavfile.write(tmp,44100,(np.clip(x,-1,1)*32767).astype(np.int16))
    subprocess.run(["ffmpeg","-v","error","-y","-i",tmp,"-compression_level","8",f"_aud/{name}"],check=True)
    os.remove(tmp)
    man.append(dict(clip=name, inst="janggu", orig=base+".wav", secs=e["secs"],
                    desc=f"장구 {base} · {e['secs']:.1f}초"))
json.dump(man, open("_aud/_manifest.json","w"), ensure_ascii=False, indent=1)
print("조각", len(man))

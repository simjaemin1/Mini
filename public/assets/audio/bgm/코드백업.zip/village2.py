"""
village2.py — 마을 낮, 다시 쓴 판.

예전 판은 `Melodist` 가 음계 위를 확률로 걸었다. 매번 다른 선율이 나왔고
어느 것도 기억에 남지 않았다. 이번에는 **동기 하나**를 정하고 곡 전체를 거기서 기른다.

  주제 (굿거리 한 주기 12소박, G 평조)
      물음 α : 치 —  우 — —  궁' — — —     (올라가서 꼭대기를 붙든다)
      답   β : 우 — 치 |  각 — 궁          (내려와 궁으로 맺는다)

  펼침 (23주기 ≈ 109초)
      1– 2  들머리   가야금 홀로 α 의 씨앗만
      3– 6  A        대금이 주제를 놓는다
      7–10  A'       같은 주제, 시김새를 바꾼다 · 단소가 꼬리를 받는다
     11–14  B        주제를 4도 위로 옮겨 되풀이 · 피리 합류
     15–16  사이     가야금 홀로 — 12현의 시김새를 다 쓴다
     17–21  A''      주제를 배로 늘려 크게 · 다 함께
     22–23  맺음     내려와 궁에서 잦아든다

  악기는 음원이 실제로 낼 수 있는 것만 맡긴다. G 평조로 얹었을 때 음정을
  억지로 늘려야 하는 양을 재서 옥타브를 정했다 — 대금·피리·가야금·거문고는 0.00반음.
      대금  33음 B3~G#6  궁=G4 → 주선율
      단소  21음 G#4~C7  궁=G5 → 응답 (궁' G6 만 없어서 그 자리는 안 쓴다)
      가야금 12음 G2~D5  궁=G3 → 반주·간주 (12현이 곧 G 평조다)
      거문고 25음 D2~E5  궁=G2 → 베이스
"""
import numpy as np
from gugak import *   # noqa  — 악기 이름을 모듈에 올려 두어야 sampler.install 이 갈아끼운다
import gugak as G
import compose as C
from motif import Motif, voice, deg_midi, PYEONGJO

MODE = PYEONGJO
MODE_NAME = "pyeongjo"
ROOT_GAYA = 55      # G3 — 산조가야금 12현이 그대로 얹히는 자리
ROOT_DAE = 67       # G4 — 대금 음역(B3~G#6) 안. G3 는 음역 아래라 옥타브를 올려 쓴다
ROOT_DAN = 79       # G5 — 단소(G#4~C7). deg5(G6)는 음원에 없어 쓰지 않는다
ROOT_PIRI = 67      # G4 — 향피리(G3~C6)
ROOT_GEO = 43       # G2 — 거문고 대현이 닿는 자리(궁 G2 만 G#2 에서 1반음 당겨 온다)

SOBAK, SWING = C.TEMPO["gutgeori"]
NSOBAK = 12
CYCLE = NSOBAK * SOBAK          # 4.74초
NCY = 23                        # ≈ 109초

# ── 주제. 자리·길이는 소박, 음도는 5음계 자리(0=궁 1=상 2=각 3=치 4=우 5=궁')
ALPHA = Motif([(0, 1, 3), (1, 2, 4), (3, 3, 5)], span=6)          # 물음 — 올라가 붙든다
BETA = Motif([(0, 2, 4), (2, 1, 3), (3, 2, 2), (5, 1, 0)], span=6)  # 답 — 내려와 맺는다


def f_of(root, deg):
    return G.mtof(deg_midi(root, MODE, deg))


def sing(mix, inst_fn, root, notes, gain, pan, send, amp=1.0, seed=0,
         legato=0.94, kw_nong="vib_cents", kw_bend="bend_end"):
    """voice() 가 준 지시를 그대로 분다/뜯는다. 시김새는 인자로 넘어가고,
    sampler 가 그 값을 보고 **실제 국악원 시김새 녹음**을 고른다."""
    rng = np.random.default_rng(seed)
    for at, dur, deg, nong, bend, art in notes:
        kw = {kw_nong: nong, kw_bend: bend, "seed": int(rng.integers(1 << 20))}
        if art:
            kw["art"] = art          # ★어느 국악원 시김새 녹음을 꺼낼지 직접 지정
        y = inst_fn(f_of(root, deg), dur * legato, amp, **kw)
        mix.add(y, at + rng.normal(0, 0.008), gain, pan, send)


def gaya_ostinato(mix, t0, gain=0.5, seed=0, dense=True):
    """가야금 반주 — 굿거리 큰 박에 궁·치를 번갈아. 가락을 가리지 않게 성기게.
    ★반주라고 시김새를 빼면 안 된다. 산조가야금은 반주에서도 굴리고 꺾는다.
      (자리, 음도, 길이, 농현, 꺾기, 주법)"""
    rng = np.random.default_rng(seed)
    pat = ([(0, 0, 1.6, 10, 0, "nong_shallow"), (3, 3, 1.2, 0, 0, "gullim"),
            (6, 2, 1.4, 12, 0, "nong_shallow"), (9, 3, 1.2, 0, -22, "toegim")]
           if dense else
           [(0, 0, 2.4, 20, 0, "nong_break"), (6, 3, 2.0, 0, -22, "toegim")])
    for s, deg, ln, nong, bend, art in pat:
        mix.add(gayageum(f_of(ROOT_GAYA, deg), ln * SOBAK, 1.0, art=art,
                         nonghyeon=float(nong), bend=float(bend),
                         seed=int(rng.integers(1 << 20))),
                t0 + s * SOBAK + rng.normal(0, 0.010), gain, -0.20, 0.30)


def geo_bass(mix, t0, gain=0.42, seed=0, degs=(0, 3), fig=0):
    """거문고 — 대현이 D2 까지 내려가니 베이스를 맡는다.
    ★거문고는 뜯는 악기가 아니라 술대로 때리는 악기라, 고유한 손이 따로 있다:
      슬기둥·싸랭·자출·전성. 전부 국악원 녹음에 들어 있는데 안 쓰고 있었다."""
    rng = np.random.default_rng(seed)
    hands = [("sulgidung", "jeonseong"), ("jeonseong", "sulgidung"),
             ("ssarang", "jeonseong"), ("sulgidung", "jachul")][fig % 4]
    for i, s in enumerate((0, 6)):
        mix.add(geomungo(f_of(ROOT_GEO, degs[i % len(degs)]), 3.4, 1.0,
                         art=hands[i], vib_cents=14.0,
                         seed=int(rng.integers(1 << 20))),
                t0 + s * SOBAK, gain, 0.24, 0.26)


def village_day2(spec=None):
    dur = NCY * CYCLE + 5.0
    mix = G.Mix(dur, tail=4.0)
    rv = G.Reverb(dur=2.6, decay=1.5, pre=0.015, damp=2400, seed=11, width=0.85)
    rng = np.random.default_rng(20260730)

    def T(c):
        return c * CYCLE

    for c in range(NCY):
        t0 = T(c)
        sd = 3000 + c * 17

        # ── 장구: 3주기째부터. 사이(15-16)에는 장구만 남는다.
        if c >= 2:
            heat = 0.30 if c < 4 else (0.66 if c < 14 else (0.52 if c < 16 else 0.72))
            if c >= 21:
                heat *= 0.55
            C.play_jangdan(mix, "gutgeori", t0, SOBAK, gain=heat, seed=sd,
                           drum="janggu" if heat > 0.5 else "soft",
                           humanize=0.011, swing=SWING, send=0.28)

        # ── 거문고: A 부터
        if 2 <= c < 14 or 16 <= c < 22:
            geo_bass(mix, t0, gain=0.40 if c < 16 else 0.46, seed=sd + 1,
                     degs=(0, 3) if c % 2 == 0 else (0, 2), fig=c)

        # ── 들머리 (1–2주기): 가야금이 α 의 씨앗만 성기게
        if c < 2:
            seed_m = ALPHA.head(2).augment(1.5)
            sing(mix, gayageum, ROOT_GAYA,
                 voice(seed_m, t0 + 3 * SOBAK, SOBAK, MODE_NAME, "gayageum", cadence_last=False),
                 gain=0.52, pan=-0.18, send=0.30, seed=sd + 2,
                 kw_nong="nonghyeon", kw_bend="bend")
            continue

        # ── A (3–6): 주제 그대로
        if 2 <= c < 6:
            sing(mix, daegeum, ROOT_DAE,
                 voice(ALPHA, t0, SOBAK, MODE_NAME, "daegeum", cadence_last=False, peak_at=2),
                 gain=0.62, pan=0.10, send=0.34, seed=sd + 3)
            sing(mix, daegeum, ROOT_DAE,
                 voice(BETA, t0 + 6 * SOBAK, SOBAK, MODE_NAME, "daegeum"),
                 gain=0.62, pan=0.10, send=0.34, seed=sd + 4)
            gaya_ostinato(mix, t0, gain=0.44, seed=sd + 5, dense=(c >= 4))

        # ── A' (7–10): 같은 주제, 맺음을 바꾸고 단소가 꼬리를 받는다
        elif 6 <= c < 10:
            half = (c - 6) % 2 == 1
            a = ALPHA if not half else ALPHA.shift(1)          # 한 자리 위로 되풀이
            b = BETA.ending(3) if not half else BETA           # 반종지 → 온종지
            sing(mix, daegeum, ROOT_DAE,
                 voice(a, t0, SOBAK, MODE_NAME, "daegeum", cadence_last=False, peak_at=2),
                 gain=0.64, pan=0.10, send=0.34, seed=sd + 3)
            sing(mix, daegeum, ROOT_DAE, voice(b, t0 + 6 * SOBAK, SOBAK, MODE_NAME, "daegeum"),
                 gain=0.64, pan=0.10, send=0.34, seed=sd + 4)
            # 단소 응답 — 주제의 꼬리만, 한 옥타브 위에서 되받는다
            if half:
                sing(mix, danso, ROOT_DAN,
                     voice(ALPHA.tail(2).diminish(0.75), t0 + 9 * SOBAK, SOBAK,
                           MODE_NAME, "danso", cadence_last=False),
                     gain=0.40, pan=0.34, send=0.42, seed=sd + 6)
            gaya_ostinato(mix, t0, gain=0.46, seed=sd + 5)

        # ── B (11–14): 주제를 4도 위로 옮겨 되풀이. 피리가 두께를 더한다
        elif 10 <= c < 14:
            up = 2 if c < 12 else 3
            a = ALPHA.shift(up)
            b = BETA.shift(up).ending(3 if c < 13 else 0)
            sing(mix, daegeum, ROOT_DAE,
                 voice(a, t0, SOBAK, MODE_NAME, "daegeum", cadence_last=False, peak_at=2),
                 gain=0.60, pan=0.12, send=0.36, seed=sd + 3)
            sing(mix, daegeum, ROOT_DAE, voice(b, t0 + 6 * SOBAK, SOBAK, MODE_NAME, "daegeum"),
                 gain=0.60, pan=0.12, send=0.36, seed=sd + 4)
            sing(mix, piri, ROOT_PIRI,
                 voice(ALPHA.head(2).shift(up), t0 + 6 * SOBAK, SOBAK, MODE_NAME, "piri",
                       cadence_last=False),
                 gain=0.34, pan=-0.34, send=0.40, seed=sd + 7)
            gaya_ostinato(mix, t0, gain=0.44, seed=sd + 5)

        # ── 사이 (15–16): 가야금 홀로. 12현의 시김새를 다 꺼낸다
        elif 14 <= c < 16:
            solo = [ALPHA, ALPHA.shift(1), BETA.tail(2), ALPHA.head(2).shift(2)][
                (c - 14) * 2: (c - 14) * 2 + 2]
            at = t0
            for m in solo:
                sing(mix, gayageum, ROOT_GAYA,
                     voice(m, at, SOBAK, MODE_NAME, "gayageum", cadence_last=True),
                     gain=0.62, pan=-0.14, send=0.34, seed=sd + 8,
                     kw_nong="nonghyeon", kw_bend="bend")
                at += m.span * SOBAK
            # 굴림 한 번 — 12현을 훑는다
            if c == 15:
                for i, d in enumerate([0, 1, 2, 3, 4, 5]):
                    mix.add(gayageum(f_of(ROOT_GAYA, d), 0.7, 1.0, nonghyeon=0.0,
                                     bend=0.0, seed=int(rng.integers(1 << 20))),
                            t0 + (8 + i * 0.55) * SOBAK, 0.40, -0.28, 0.36)

        # ── A'' (17–21): 주제를 배로 늘려 크게. 다 함께
        elif 16 <= c < 21:
            k = c - 16
            if k % 2 == 0:
                big = ALPHA.augment(2.0)                      # 12소박을 다 쓴다
                sing(mix, daegeum, ROOT_DAE,
                     voice(big, t0, SOBAK, MODE_NAME, "daegeum", cadence_last=False, peak_at=2),
                     gain=0.70, pan=0.08, send=0.34, seed=sd + 3)
                sing(mix, piri, ROOT_PIRI,
                     voice(big, t0, SOBAK, MODE_NAME, "piri", cadence_last=False),
                     gain=0.26, pan=-0.30, send=0.40, seed=sd + 7)
            else:
                sing(mix, daegeum, ROOT_DAE,
                     voice(ALPHA, t0, SOBAK, MODE_NAME, "daegeum", cadence_last=False, peak_at=2),
                     gain=0.68, pan=0.08, send=0.34, seed=sd + 3)
                sing(mix, daegeum, ROOT_DAE,
                     voice(BETA, t0 + 6 * SOBAK, SOBAK, MODE_NAME, "daegeum"),
                     gain=0.68, pan=0.08, send=0.34, seed=sd + 4)
                sing(mix, danso, ROOT_DAN,
                     voice(BETA.tail(2), t0 + 9 * SOBAK, SOBAK, MODE_NAME, "danso"),
                     gain=0.38, pan=0.36, send=0.44, seed=sd + 6)
            gaya_ostinato(mix, t0, gain=0.48, seed=sd + 5)

        # ── 맺음 (22–23): 내려와 궁에서 잦아든다
        else:
            fade = 0.72 if c == 21 else 0.44
            close = BETA.stretch_last(2.2)
            sing(mix, daegeum, ROOT_DAE,
                 voice(close, t0 + 2 * SOBAK, SOBAK, MODE_NAME, "daegeum"),
                 gain=0.56 * fade / 0.72, pan=0.06, send=0.40, seed=sd + 3)
            sing(mix, gayageum, ROOT_GAYA,
                 voice(BETA.tail(2), t0 + 7 * SOBAK, SOBAK, MODE_NAME, "gayageum"),
                 gain=0.44 * fade / 0.72, pan=-0.20, send=0.36, seed=sd + 8,
                 kw_nong="nonghyeon", kw_bend="bend")

    # 자연음 — 아주 얇게 (낮 마을의 바닥)
    mix.add(G.wind(dur, 0.055, seed=7), 0.0, 1.0, 0.0, 0.10)
    mix.add(G.water(dur, 0.040, seed=8), 0.0, 1.0, 0.30, 0.10)
    return mix.render(rv, wet=1.0, target_db=-16.0, loop=False)


TRACKS = {"village_day2": dict(fn=village_day2, title="마을 낮 · 다시 쓴 판",
                               scene="village_day", mood="trad")}

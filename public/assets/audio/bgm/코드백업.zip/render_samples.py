"""
render_samples.py — 실음원 폴더를 써서 곡을 다시 렌더링한다.

    python3 sampler.py scan samples_gaya      # 폴더마다 색인
    python3 notes_of.py                       # 악보 뽑기 (옥타브 계획에 필요)
    python3 render_samples.py samples_gaya samples_danso ...
    python3 render_samples.py --only village_day_ari samples_gaya

음원이 없는 악기는 자동으로 합성음이 쓰인다.
성부가 악기 음역 밖이면 **곡마다 성부 전체를 옥타브 단위로** 옮긴다.
음마다 따로 접으면 선율선이 튀어 곡이 망가지기 때문이다.
"""
import sys
import os
import json
import numpy as np
import gugak as G
import sampler as S


def main():
    args = sys.argv[1:]
    only = []
    while "--only" in args:
        i = args.index("--only")
        only.append(args[i + 1])
        del args[i:i + 2]
    roots = args or ["samples_gaya"]

    bank = S.Bank(roots)
    import compose as C
    import arirang as A
    allt = {**C.TRACKS, **A.ARI_TRACKS}
    names = only or list(allt)
    score = json.load(open("score.json")) if os.path.exists("score.json") else {}
    if not score:
        print("  ! score.json 없음 — 옥타브 계획 생략 (python3 notes_of.py 먼저)")

    outdir = "out_samples"
    os.makedirs(outdir, exist_ok=True)
    meta = {}
    probe = S.install(bank, [C, A])
    print("악기별 소리 출처")
    for k, v in sorted(probe.items()):
        src = "·".join(sorted(bank.source.get(k, []))) if v == "샘플" else ""
        print(f"  {'●' if v == '샘플' else '○'} {k:14s} {v}  {src}")
    if getattr(bank, "dropped_src", None):
        print(f"  (한 악기가 여러 폴더에 있어 한쪽만 씁니다: {bank.dropped_src})")

    for name in names:
        oct_plan = S.plan_octaves({name: score[name]}, bank) if name in score else {}
        S.install(bank, [C, A], octaves=oct_plan)
        y = allt[name]["fn"](allt[name])
        G.write_wav(os.path.join(outdir, name + ".wav"), y)
        rms = float(np.sqrt(np.mean(y ** 2)))
        meta[name] = dict(seconds=round(y.shape[1] / G.SR, 2),
                          rms_db=round(float(20 * np.log10(rms + 1e-9)), 2),
                          peak_db=round(float(20 * np.log10(np.max(np.abs(y)) + 1e-9)), 2),
                          octaves=oct_plan)
        ostr = " ".join(f"{k}{v:+d}옥" for k, v in oct_plan.items()) or "-"
        print(f"  {name:20s} {meta[name]['seconds']:7.2f}s  rms {meta[name]['rms_db']:6.2f}dB  "
              f"peak {meta[name]['peak_db']:6.2f}dB   옥타브 {ostr}")
    json.dump({"source": probe, "tracks": meta, "roots": roots},
              open(os.path.join(outdir, "meta.json"), "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()

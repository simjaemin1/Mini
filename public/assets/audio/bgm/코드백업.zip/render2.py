"""render2.py — 새 엔진으로 12곡 전부."""
import sys, os, json, time, numpy as np
import gugak as G, sampler as S, compose as C, tracks2 as T

ROOTS = ["samples_gaya", "samples_danso", "samples_daegeum", "samples_piri",
         "samples_geomungo", "samples_janggu", "samples_jing", "samples_buk",
         "samples_bak", "samples_kkwaenggwari"]


def main():
    os.makedirs("out_samples", exist_ok=True)
    bank = S.Bank(ROOTS)
    use, shift, miss = {}, {}, {}
    op = S.Bank._pick

    def pick(self, inst, midi, rr, dur=0.5, amp=1.0, art=None):
        g = op(self, inst, midi, rr, dur=dur, amp=amp, art=art)
        if g is None:
            miss[inst] = miss.get(inst, 0) + 1
            return g
        use.setdefault(inst, {})
        a = g[2].get("art")
        use[inst][a] = use[inst].get(a, 0) + 1
        if midi is not None and g[0] is not None:
            shift.setdefault(inst, []).append(abs(midi - g[0]))
        return g
    S.Bank._pick = pick
    S.install(bank, [C, T])
    meta = {}
    names = sys.argv[1:] or list(T.TRACKS)
    for k in names:
        t0 = time.time()
        y = T.TRACKS[k]["fn"]()
        G.write_wav(f"out_samples/{k}.wav", y)
        m = y.mean(0) if y.ndim > 1 else y
        meta[k] = dict(title=T.TRACKS[k]["title"], seconds=round(len(m) / G.SR, 1),
                       rms=round(float(20 * np.log10(np.sqrt((m ** 2).mean()))), 1))
        print(f"  {k:22s} {meta[k]['seconds']:6.1f}초  rms {meta[k]['rms']:6.1f}dB"
              f"  ({time.time()-t0:.0f}s)")
    S.Bank._pick = op
    tot = sum(sum(d.values()) for d in use.values())
    print(f"\n음 {tot}개 · 합성음 {sum(miss.values())}개 {miss if miss else ''}")
    print(f"{'악기':12s}{'음':>6s}{'최대늘림':>9s}{'평균':>7s}  쓴 시김새")
    for inst, d in sorted(use.items(), key=lambda x: -sum(x[1].values())):
        sh = shift.get(inst)
        a = f"{max(sh):.2f}" if sh else "—"
        b = f"{np.mean(sh):.2f}" if sh else "—"
        al = " · ".join(f"{S.ART_NAME_KO.get(k2,k2)}{v}"
                        for k2, v in sorted(d.items(), key=lambda x: -x[1])[:6])
        print(f"{inst:12s}{sum(d.values()):6d}{a:>9s}{b:>7s}  {al}")
    json.dump({"tracks": meta,
               "source": {i: "샘플" for i in use},
               "notes": tot, "synth": sum(miss.values())},
              open("out_samples/meta.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()

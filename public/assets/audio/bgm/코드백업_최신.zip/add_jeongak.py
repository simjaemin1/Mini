"""정악풍 판을 악보 페이지에 붙인다."""
import os, base64, subprocess, sys
import numpy as np, sampler as S, gugak as G, compose as C, render_jeongak as J

def main():
    bank = S.Bank(["samples_jgaya", "samples_daegeum", "samples_piri",
                   "samples_danso", "samples_geomungo", "samples_janggu"])
    S.install(bank, [C, J])
    y = J.build()
    os.makedirs("_sc", exist_ok=True)
    G.write_wav("_sc/jeongak.wav", y)
    subprocess.run(["ffmpeg","-v","error","-y","-i","_sc/jeongak.wav",
                    "-c:a","libmp3lame","-b:a","96k","_sc/jeongak.mp3"], check=True)
    e = "data:audio/mpeg;base64," + base64.b64encode(open("_sc/jeongak.mp3","rb").read()).decode()
    h = open("마을낮_악보.html", encoding="utf-8").read()
    blk = f'''<div class="lbl">④ 같은 악보, <b>정악풍</b> — 가야금은 진짜 정악가야금</div>
<audio controls preload="none" src="{e}"></audio>
<p class="note">국립국악원 낱음 세트(60종·953파일)에 <b>정악대금은 없습니다.</b>
대금류는 <code>Sanjo_deageum</code> 하나뿐입니다 — 가야금은 정악·산조 둘 다,
아쟁도 둘 다 있는데 대금만 산조뿐입니다. 그래서 이 판의 대금은
<b>산조대금 음원으로 낸 정악풍</b>이지 정악대금 음색이 아닙니다.
바꾼 것: 소박 0.395→0.50초(한 장단 6.0초) · 깊은 농현을 걷어내고 요성(±8센트·3Hz)만 ·
맺음은 퇴성 · 여운 2.0초 · 장단에서 굴림을 빼고 세기 0.62배 ·
저역 +/고역 − EQ로 관이 긴 악기 쪽으로 기울임(음색 보정이지 다른 악기가 아닙니다).
<b>가야금만은 진짜 정악가야금</b>(jungak_gayageum, 조각 100개)입니다.</p>
<p class="note">MIDI 파일'''
    h = h.replace('<p class="note">MIDI 파일', blk, 1)
    open("마을낮_악보.html","w").write(h)
    print(f"붙임 완료 · {os.path.getsize('마을낮_악보.html')/1e6:.1f}MB")

if __name__ == "__main__":
    main()

import pathlib,subprocess,os,time,json,datetime
p=pathlib.Path('/tmp/t1248');root=pathlib.Path('/workspace/Mini');os.sched_setaffinity(0,{1,2,3})
required=['v4-world-tick30','v4-tick400','v4-candidate400','v4-farm-tick400','v4-farm-candidate400','v4-farm-replay400','v4-off','historic-workt400','historic-stop44400','historic-dawn400','historic-nofarmer400','queue-nowork400','queue-order400']+[f'v4-scale-{n}-{m}' for n in [3900,16000] for m in ['0','1']]
print('Waiting for all noncritical engine cases before serial controlled N measurement',flush=True)
while True:
 statuses=[p/n/'status.json' for n in required]
 if all(f.exists() for f in statuses):
  assert all(json.loads(f.read_text()).get('valid') for f in statuses),'noncritical case failed'
  break
 time.sleep(10)
result={}
for n,pop in [(3900,77),(16000,314)]:
 for mode in ['0','1']:
  name=f'v4-controlled-scale-{n}-{mode}';d=p/name;d.mkdir(exist_ok=True)
  env={**os.environ,'T1248_OUT':str(d),'T1248_ROOT':str(p/'frozen-v4'),'T1241_DES':mode,'T1243_FARM_ON':'0','T1248_TICK_BENCH':'1','T1248_EXPECT_N':str(n),'T577_CAND_SEEDPOP':str(pop),'T315_MAPBEDS':'0','T1248_BENCH_TICKS':'1000','T1248_BENCH_WARMUP':'300'}
  condition={'startedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'affinity':sorted(os.sched_getaffinity(0)),'noncriticalCasesAllComplete':True,'criticalWorld100AlreadyComplete':(p/'v4-world100/status.json').exists(),'flags':{k:v for k,v in env.items() if k.startswith(('T1248_','T1241_','T1243_','T577_CAND_','T315_'))},'scope':'Serial benchmark engines on CPUs1,2,3; only remaining critical world100 may run on CPU0; no overlapping noncritical simulation engines'}
  (d/'measurement-env.json').write_text(json.dumps(condition,indent=2))
  with (d/'batch.log').open('w') as f:r=subprocess.run(['node','scripts/t1248-run.js','1','1020'],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
  result[name]=r.returncode;print('DONE',name,r.returncode,flush=True)
(p/'controlled-scale-status.json').write_text(json.dumps(result,indent=2));raise SystemExit(any(result.values()))

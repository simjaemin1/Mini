import pathlib,json,gzip,subprocess
root=pathlib.Path('/workspace/Mini');p=pathlib.Path('/tmp/t1248');out=root/'계측/T1248_2026-11-10-independent'
for d in sorted(p.iterdir()):
 if not d.is_dir():continue
 status=d/'status.json';independent=d/'independent-validation.json'
 if not status.exists():continue
 try:s=json.loads(status.read_text())
 except ValueError:continue
 if not(s.get('valid') or (independent.exists() and json.loads(independent.read_text()).get('valid'))):continue
 dest=out/'runs'/d.name
 if (dest/'archive-validation.json').exists():continue
 count=0
 for f in d.rglob('*'):
  if not f.is_file() or '.db' in f.name or f.suffix not in ['.json','.jsonl','.log']:continue
  to=dest/(str(f.relative_to(d))+'.gz');to.parent.mkdir(parents=True,exist_ok=True);to.write_bytes(gzip.compress(f.read_bytes(),mtime=0));count+=1
 (dest/'archive-validation.json').write_text(json.dumps({'originalStatus':s,'files':count,'dbExcluded':True},indent=2));print('archived',d.name,count)
pairs=[('window-control400','window-farmer400'),('historic-proto400','clear-wake-control400'),('clear-wake-control400','clear-wake-native400'),('historic-dawn400','window-control400'),('window-control400','window-native400'),('queue-nowork400','queue-order400'),('v4-tick400','v4-candidate400'),('v4-farm-tick400','v4-farm-candidate400'),('v4-farm-candidate400','v4-farm-replay400'),('v4-world-tick30','v4-world100')]+[('historic-tick400','historic-'+x+'400') for x in ['proto','workt','stop44','dawn','nofarmer']]
for left,right in pairs:
 target=out/'comparisons'/('compare-'+right+'.json')
 if target.exists():continue
 def valid(n):
  f=p/n/'status.json';return f.exists() and json.loads(f.read_text()).get('valid')
 if not(valid(left) and valid(right)):continue
 r=subprocess.run(['node','scripts/t1248-table.js',str(p/left),str(p/right)],cwd=root,capture_output=True,text=True)
 if r.returncode:print('FAILEDcompare',right,r.stderr[-300:]);continue
 target.parent.mkdir(exist_ok=True);target.write_text(r.stdout);(p/target.name).write_text(r.stdout);z=json.loads(r.stdout);print('compared',right,z['official'])

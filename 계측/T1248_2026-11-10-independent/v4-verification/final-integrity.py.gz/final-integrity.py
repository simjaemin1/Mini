from pathlib import Path
import json,hashlib,datetime
p=Path('/tmp/t1248');root=Path('/workspace/Mini');out=root/'계측/T1248_2026-11-10-independent'
read=lambda f:json.loads(f.read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();utc=lambda f:datetime.datetime.fromtimestamp(f.stat().st_mtime,datetime.timezone.utc).isoformat()
names=['v4-world100','v4-world-tick30','v4-tick400','v4-candidate400','v4-farm-tick400','v4-farm-candidate400','v4-farm-replay400','v4-off','historic-tick400','historic-proto400','historic-workt400','historic-stop44400','historic-dawn400','historic-nofarmer400','queue-nowork400','queue-order400']+[f'{prefix}{n}-{m}' for prefix in ['v4-scale-','v4-controlled-scale-'] for n in [3900,16000] for m in ['0','1']]
names += ['window-control400','window-native400','window-farmer400','clear-wake-control400','clear-wake-native400']
assert len(names)==29
expected=read(p/'v4-game-source.json');assert all(sha(root/f)==h for f,h in expected.items())
records=[]
for name in names:
 d=p/name;s=read(d/'status.json');assert s['valid'],name
 if name=='v4-off':
  assert s['exitCode']==0 and s['officialSame']=='1/1' and s['sourceUnchanged'] and s['gameHashesAtCompletion']==expected
  records.append({'name':name,'validOfficialGate':True,'sourceUnchanged':True,'clockErrors':s.get('clockErrors'),'clockErrorEvidence':s.get('clockErrorEvidence'),'sourceFileWrittenUTC':utc(d/'source.json'),'statusFileWrittenUTC':utc(d/'status.json')});continue
 src=read(d/'source.json');r=Path(src['root']);actual={f:sha(r/f) for f in src['source']};assert actual==src['source'],name
 if name.startswith('v4-'):assert all(src['source'].get(f)==h for f,h in expected.items()),name
 m=read(d/'days.jsonl.meta.json');assert m['code']==0 and m['clock']['errs']==0,name
 record={'name':name,'sourceAtStartEqualsCurrentFiles':True,'sourceFileWrittenUTC':utc(d/'source.json'),'exitMetaFileWrittenUTC':utc(d/'days.jsonl.meta.json'),'zoneCPUSeconds':m['cpuSeconds'],'zoneWallSeconds':m['wallSeconds'],'clockErrors':m['clock']['errs'],'fixture':s.get('benchmarkFixtureCompleted',False)}
 if record['fixture']:
  b=m['tickBenchmark'];assert b['window']['measuredTicks']==1000 and b['cpu']['samples']==1000 and b['wall']['samples']==1000
  record['actualBodies']=b['actualBodies']
 else:
  f=next((d/'server').glob('*-1020.json'));o=read(f);assert o['days']>=src['days'] and o['seedPop'] and all(x>0 for x in o['seedPop']);record['villages']=o['villages'];record['days']=o['days']
  if name in ['v4-world100','v4-world-tick30']:assert o['villages']==51 and len(o['seedPop'])==51,name
  else:assert o['villages']==1,name
 records.append(record)
z={'selected29TimedMeasurementCasesComplete':True,'currentV4GameHashes':expected,'sourceValidation':records,'timingNote':'source/meta/status file timestamps are approximate orchestration markers, not exact server start times; zoneWallSeconds is real hrtime duration. Gzip mtime0 otherwise discards original filesystem timestamps.'}
diag=read(p/'v4-restart-final/status.json');assert diag['diagnosticCompleted'] and diag['gameSourceUnchanged'];z['restartBindingRequirementPassed']=diag['bindingRequirementPassed']
(out/'final-source-and-timing-validation.json').write_text(json.dumps(z,indent=2));print('validated29 cases and frozen source integrity')

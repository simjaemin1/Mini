import os,subprocess,json,time,concurrent.futures,pathlib,hashlib,re,shutil
p=pathlib.Path('/tmp/t1248');root=pathlib.Path('/workspace/Mini');os.sched_setaffinity(0,{1,2,3})
def run(name,days,flags,model='frozen-v4',cpus='1,2,3'):
 d=p/name;d.mkdir(exist_ok=True);s=d/'status.json'
 if s.exists() and json.loads(s.read_text()).get('valid'):return name,0
 env={**os.environ,'T1248_OUT':str(d),'T1248_ROOT':str(p/model),**flags}
 (d/'measurement-env.json').write_text(json.dumps({'flags':flags,'model':model,'cpus':cpus,'days':days},indent=2))
 with (d/'batch.log').open('w') as f:r=subprocess.run(['taskset','-c',cpus,'node','scripts/t1248-run.js',str(days),'1020'],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 print('DONE',name,r.returncode,flush=True);return name,r.returncode

def off():
 d=p/'v4-off';d.mkdir(exist_ok=True)
 files=['server/zone.js','server/villages.js','server/des.js','server/des-work.js'];hashes=lambda:{f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files}
 start=hashes();(d/'source.json').write_text(json.dumps(start,indent=2));t=time.monotonic()
 with (d/'off.log').open('w') as f:r=subprocess.run(['taskset','-c','1,2,3','node','scripts/server-baseline-check.js','계측/서버기준선_2026-11-08c.json','--vclock','--plan','1020:400'],cwd=root,env={**os.environ,'T1241_DES':'0'},stdout=f,stderr=subprocess.STDOUT)
 text=(d/'off.log').read_text();m=re.search(r'판 (/tmp/sbc-\S+)',text);errs=[]
 if m:
  src=pathlib.Path(m.group(1));out=d/'evidence';out.mkdir(exist_ok=True)
  for f in src.rglob('*'):
   if f.is_file() and '.db' not in f.name:
    to=out/f.relative_to(src);to.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,to)
   if f.is_file() and f.name.endswith('.log'):
    for line in f.read_text(errors='replace').splitlines():
     if 'vclock' in line.lower() and 'err' in line.lower():errs.append(line)
 end=hashes();z={'valid':r.returncode==0 and '같음 1/1' in text and start==end,'kind':'official-off-gate','exitCode':r.returncode,'officialSame':'1/1' if '같음 1/1' in text else None,'days':400,'gameHashesAtStart':start,'gameHashesAtCompletion':end,'sourceUnchanged':start==end,'elapsedWallSeconds':time.monotonic()-t,'clockLogLines':errs,'scope':'official baseline clock, not live-clock annual performance'};(d/'status.json').write_text(json.dumps(z,indent=2));print('DONE officialOFF',z['valid'],flush=True);return 'v4-off',0 if z['valid'] else 1

jobs=[('v4-world-tick30',30,{'T1241_DES':'0','T1243_FARM_ON':'1'}),('v4-tick400',400,{'T1241_DES':'0','VILLAGE_MAX':'1'}),('v4-candidate400',400,{'T1241_DES':'1','VILLAGE_MAX':'1'}),('v4-farm-tick400',400,{'T1241_DES':'0','T1243_FARM_ON':'1','VILLAGE_MAX':'1'}),('v4-farm-candidate400',400,{'T1241_DES':'1','T1243_FARM_ON':'1','VILLAGE_MAX':'1'}),('v4-farm-replay400',400,{'T1241_DES':'1','T1243_FARM_ON':'1','VILLAGE_MAX':'1'})]
for n,pop,mode in [(3900,77,'1'),(16000,314,'0'),(16000,314,'1')]:jobs.append((f'v4-scale-{n}-{mode}',1,{'T1241_DES':mode,'T1243_FARM_ON':'0','T1248_TICK_BENCH':'1','T1248_EXPECT_N':str(n),'T577_CAND_SEEDPOP':str(pop),'T315_MAPBEDS':'0','T1248_BENCH_TICKS':'1000','T1248_BENCH_WARMUP':'300'}))
hist=[('historic-workt400',{'T1241_DES_WALK_WORKT':'1'}),('historic-stop44400',{'T1241_DES_STOP44':'1'}),('historic-dawn400',{'T1241_DES_DAWN':'1'}),('historic-nofarmer400',{'T1241_DES_NOWALK':'hunter,farmer'})]
# world100 is isolated from the3 sharedCPU queue and awaited until real completion.
with concurrent.futures.ThreadPoolExecutor(max_workers=1) as critical, concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 futures=[critical.submit(run,'v4-world100',100,{'T1241_DES':'1','T1243_FARM_ON':'1','T1248_CHECKPOINTS':'30,100'},cpus='0')]
 futures += [pool.submit(run,*job) for job in jobs]
 futures.append(pool.submit(off))
 futures += [pool.submit(run,name,400,{'T1241_DES':'1','VILLAGE_MAX':'1',**flags},'historical') for name,flags in hist]
 results=dict(f.result() for f in concurrent.futures.as_completed(futures))
(p/'final-orchestrate-status.json').write_text(json.dumps(results,indent=2));raise SystemExit(any(results.values()))

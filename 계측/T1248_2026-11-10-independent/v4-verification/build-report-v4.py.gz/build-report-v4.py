from pathlib import Path
import json,re,statistics
p=Path('/tmp/t1248');root=Path('/workspace/Mini');out=root/'계측/T1248_2026-11-10-independent'
def read(f):return json.loads(f.read_text())
def meta(n):return read(p/n/'days.jsonl.meta.json')
def body(n):return [json.loads(s) for s in (p/n/'body.1020.jsonl').open()]
def cmp(n):return read(p/('compare-'+n+'.json'))
def fmt(x):return '—' if x is None else f'{x:.3f}'
def table(headers,rows):return '| '+' | '.join(headers)+' |\n|'+ '|'.join(['---']*len(headers))+'|\n'+'\n'.join('| '+' | '.join(map(str,row))+' |' for row in rows)
required=['v4-world100','v4-world-tick30','v4-tick400','v4-candidate400','v4-farm-tick400','v4-farm-candidate400','v4-farm-replay400','v4-off','v4-scale-3900-0','v4-scale-3900-1','v4-scale-16000-0','v4-scale-16000-1','historic-workt400','historic-stop44400','historic-dawn400','historic-nofarmer400','queue-nowork400','queue-order400']
for n in required:assert read(p/n/'status.json').get('valid'),n
pairs=[('기본1마을400일','v4-candidate400'),('밭켬1마을400일','v4-farm-candidate400'),('밭켬 사건 독립 반복400일','v4-farm-replay400'),('전체51마을 밭켬 공통30일','v4-world100')];rows=[];differences=[]
for label,n in pairs:
 c=cmp(n);assert c['sourceHashesEqual'],n;o=c['official'];q=c['positions'];rows.append([label,f"{o['same']}/{o['compared']}",fmt(q['medianM']),fmt(q['p90M']),fmt(q['maxM']),f"{q['checkpoints']}/{q['bodies']}",f"{q['onlyTick']}/{q['onlyDes']}"])
 if o['first']:
  f=o['first']
  for v in f['villages']:
   for x in v.get('firstValues',[]):differences.append([label,f['day'],v['name'],x['part']+x.get('path',''),json.dumps(x.get('tick'),ensure_ascii=False),json.dumps(x.get('des'),ensure_ascii=False),'씨 수이면 파종1칸의 정본 차감과 대조; 그 밖에는 상위 작업/운반/차례 기제 미확정'])
  if not f['villages']:differences.append([label,f['day'],'econ날','econ',*f['econ'],'날 처리 위상 갈림; 원인 미확정'])
comparison=table(['판','공식 날 같음','자리 가운데m','p90m','최대m','체크포인트/짝','신원누락 틱/사건'],rows)
difftext=table(['대조','첫날','마을','칸/경로','틱','사건','직접 관측·남은 원인'],differences) if differences else '위 대조의 공통 측정 범위에서 공식 지문 첫 불일치를 관측하지 않았다. 전체51마을400일 또는 미측정 조건의 동일성을 뜻하지 않는다.'
world=meta('v4-world100');tick=meta('v4-world-tick30');check=read(p/'v4-world100/days.jsonl.checkpoint-30.json');assert check['day']==30 and world['clock']['errs']==0 and tick['clock']['errs']==0
worldrows=[]
for label,days,m in [('사건 중간 체크포인트',30,check),('사건 완주',100,world),('틱 완주',30,tick)]:worldrows.append([label,days,fmt(m['cpuSeconds']/60),fmt(m['wallSeconds']/60),fmt(m['cpuSeconds']*400/days/60),fmt(m['wallSeconds']*400/days/60)])
worldtext=table(['관측','실제 날수','CPU분','경과분','400일 CPU 외삽분','400일 경과 외삽분'],worldrows)
for name,label in [('v4-world100','사건100일'),('v4-world-tick30','틱30일')]:
 b=body(name);d=[x for x in b if 'd'in x];pops=[x['pop'] for x in d if 'pop'in x];s=meta(name)['stats'];worldtext+=f"\n\n{label}: 기록 인구 {min(pops)}–{max(pops)}, 마지막 {pops[-1]}; 실제 workKinds `{json.dumps(s.get('workKinds'),ensure_ascii=False)}`. holdChecks={s.get('holdChecks',0)}, steps={s.get('steps')}, bodyTicks={s.get('bodyTicks')}. 최종 자식0/시계오류0."
scale=[];summary=[]
for n in [3900,16000]:
 row=[];both=[]
 for mode in ['0','1']:
  name=f'v4-scale-{n}-{mode}';m=meta(name);b=m['tickBenchmark'];assert m['code']==0 and m['clock']['errs']==0 and b['window']['measuredTicks']==1000 and b['cpu']['samples']==1000 and b['wall']['samples']==1000
  raw=b['rawCpuSamples'];owned=statistics.mean(x['owned'] for x in raw);assert (owned==0 if mode=='0' else owned>0);z={'run':name,'actualBodies':b['actualBodies'],'cpu':b['cpu'],'wall':b['wall'],'ownedMean':owned,'status':read(p/name/'status.json')};summary.append(z);both.append(z)
 a,b=both;scale.append([f"{a['actualBodies']['min']} / {b['actualBodies']['min']}",'/'.join(fmt(a['cpu'][k]) for k in ['meanMs','medianMs','p95Ms']),'/'.join(fmt(b['cpu'][k]) for k in ['meanMs','medianMs','p95Ms']),f"{fmt(a['wall']['meanMs'])}/{fmt(b['wall']['meanMs'])}",f"{fmt(a['wall']['p95Ms'])}/{fmt(b['wall']['p95Ms'])}",f"{fmt(a['ownedMean'])}/{fmt(b['ownedMean'])}"])
scaletext=table(['실제몸 틱/사건','틱CPU 평균/중앙/95%ms','사건CPU 평균/중앙/95%ms','wall평균 틱/사건ms','wall95% 틱/사건ms','사건소유 평균 틱/사건'],scale)+'\n\n모두CPU1–3 공유 배치의 관측이며 동시 실행 판은 시점마다 다르다. 특히3,927명 OFF 표본은 세션 중단 전에 완료된 동일V4 소스다. 벽시계 비율을 동일 부하의 통제된 알고리즘 배속으로 해석하지 않는다.'
(p/'v4-scale-summary.json').write_text(json.dumps(summary,indent=2));(out/'v4-scale-summary.json').write_text(json.dumps(summary,indent=2))
abl=[];base=body('historic-tick400')[-1]['farm']
for n,label in [('historic-tick400','과거 틱'),('historic-proto400','과거 시제품'),('historic-workt400','ⓐ 도착 작업시계'),('historic-stop44400','ⓑ 44px경계'),('historic-dawn400','ⓒ 첫결정 즉시'),('historic-nofarmer400','농부 걸음 제외')]:
 b=body(n);f=b[-1]['farm'];common={x.get('d'):x for x in body('historic-tick400') if 'd'in x};first=next((x.get('d')+1 for x in b if 'd'in x and x.get('d') in common and x.get('farm')!=common[x['d']].get('farm')),None);abl.append([label,f,fmt((f/base-1)*100)+'%',first or '없음',b[-1].get('pop')])
abltext=table(['같은 과거 소스400일','최종 개간칸','틱 대비','첫 개간갈림 scanDay','인구'],abl)
order=[]
for n,label in [('queue-nowork400','V2 준비시간 순서'),('queue-order400','V2 기존 NPC 순서')]:
 b=body(n)[-1];order.append([label,b['farm'],b.get('pop')])
abltext+='\n\n'+table(['별도 V2 소스400일 대조 ⓓ','개간칸','인구'],order)
o=read(p/'v4-off/status.json');assert o['valid'] and o['sourceUnchanged'];offtext=f"**1/1**, checker 종료0, 소스 시작/끝 같음, 공식400일 지문·판JSON·여덟 수 같음. 실제 경과{fmt(o['elapsedWallSeconds'])}초. 원로그/evidence 및 자식 시계 로그 보존."
farmcmp=cmp('v4-farm-candidate400');farm=farmcmp['costs'];fpercent=(farm['des']['farm']/farm['tick']['farm']-1)*100
values={'SAME':str(farmcmp['official']['same']),'POS':fmt(farmcmp['positions']['medianM']),'CLEAR':f'V4밭켬 {fpercent:+.3f}%(다른 세계)','FORECAST':fmt(world['wallSeconds']*4/60),'N3900':f"{summary[0]['cpu']['meanMs']:.3f}/{summary[1]['cpu']['meanMs']:.3f}(CPU평균 틱/사건)",'OFF':'1','COMPARISONS':comparison,'DIFFERENCES':difftext,'WORLD':worldtext,'SCALE':scaletext,'ABLATIONS':abltext,'OFFDETAIL':offtext}
s=(p/'report-v4-template.md').read_text()
for k,v in values.items():s=s.replace('{{'+k+'}}',str(v))
assert not re.search(r'\{\{\w+\}\}',s)
s=s.replace('몸 전부는 시딩된 몸 모두를 뜻하며 인구가 시간에 따라 변하는 것을 감췄다는 뜻이 아니다.','몸 상한을 두지 않았으며 실제 인구 변화는 아래에 함께 제시한다.')
(root/'보고/T1248_2026-11-10.md').write_text(s)
print(s.splitlines()[0])

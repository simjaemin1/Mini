from pathlib import Path
import json,re,statistics
p=Path('/tmp/t1248');root=Path('/workspace/Mini');out=root/'계측/T1248_2026-11-10-independent'
def read(f):return json.loads(f.read_text())
def meta(n):return read(p/n/'days.jsonl.meta.json')
def body(n):return [json.loads(s) for s in (p/n/'body.1020.jsonl').open()]
def cmp(n):return read(p/('compare-'+n+'.json'))
def fmt(x):return '—' if x is None else f'{x:.3f}'
def table(headers,rows):return '| '+' | '.join(headers)+' |\n|'+ '|'.join(['---']*len(headers))+'|\n'+'\n'.join('| '+' | '.join(map(str,row))+' |' for row in rows)
required=['v4-world100','v4-world-tick30','v4-tick400','v4-candidate400','v4-farm-tick400','v4-farm-candidate400','v4-farm-replay400','v4-off','v4-scale-3900-0','v4-scale-3900-1','v4-scale-16000-0','v4-scale-16000-1','historic-tick400','historic-proto400','historic-workt400','historic-stop44400','historic-dawn400','historic-nofarmer400','queue-nowork400','queue-order400']
required += ['window-control400','window-native400','window-farmer400','clear-wake-control400','clear-wake-native400']
required += [f'v4-controlled-scale-{n}-{m}' for n in [3900,16000] for m in ['0','1']]
for n in required:assert read(p/n/'status.json').get('valid'),n
pairs=[('기본1마을400일','v4-candidate400'),('밭켬1마을400일','v4-farm-candidate400'),('밭켬 사건 독립 반복400일','v4-farm-replay400'),('전체51마을 밭켬 공통30일','v4-world100')];rows=[];differences=[]
for label,n in pairs:
 c=cmp(n);assert c['sourceHashesEqual'],n;o=c['official'];q=c['positions'];rows.append([label,f"{o['same']}/{o['compared']}",fmt(q['medianM']),fmt(max((r['medianM'] for r in q['rows']),default=None)),fmt(q['p90M']),fmt(q['maxM']),f"{q['checkpoints']}/{q['bodies']}",f"{q['onlyTick']}/{q['onlyDes']}"])
 if o['first']:
  f=o['first']
  for v in f['villages']:
   for x in v.get('firstValues',[]):differences.append([label,f['day'],v['name'],x['part']+x.get('path',''),json.dumps(x.get('tick'),ensure_ascii=False),json.dumps(x.get('des'),ensure_ascii=False),('정본 파종 칸당 씨1 차감; 해당 날 몸 기록의 작물39/38·수확0/0. 작업/걸음/선점 순서의 상위 원인 미확정' if 'seed_barnyard_millet' in x.get('path','') else ('구리 금고 수량 차이. 채굴/입고/금고 반영의 상위 원인 미확정' if x['part']=='treasury' else '구리 곳간 수량 차이. 채굴/운반/차례의 상위 원인 미확정'))])
  if not f['villages']:differences.append([label,f['day'],'econ날','econ',*f['econ'],'날 처리 위상 갈림; 원인 미확정'])
comparison=table(['판','공식 날 같음','자리 가운데m','체크포인트 가운데 최대m','p90m','최대m','체크포인트/짝','신원누락 대조/후보'],rows)
difftext=table(['대조','첫날','마을','칸/경로','틱','사건','직접 관측·남은 원인'],differences) if differences else '위 대조의 공통 측정 범위에서 공식 지문 첫 불일치를 관측하지 않았다. 전체51마을400일 또는 미측정 조건의 동일성을 뜻하지 않는다.'
world=meta('v4-world100');tick=meta('v4-world-tick30');check=read(p/'v4-world100/days.jsonl.checkpoint-30.json');assert check['day']==30 and world['clock']['errs']==0 and tick['clock']['errs']==0 and check['clock']['V']==tick['clock']['V']
worldrows=[]
for label,days,m in [('사건 중간 체크포인트',30,check),('사건 완주',100,world),('틱 완주',30,tick)]:worldrows.append([label,days,fmt(m['cpuSeconds']/60),fmt(m['wallSeconds']/60),fmt(m['cpuSeconds']*400/days/60),fmt(m['wallSeconds']*400/days/60)])
worldtext=table(['관측','실제 날수','CPU분','경과분','400일 CPU 외삽분','400일 경과 외삽분'],worldrows)
worldtext+=f'\n\n같은30일의 사건 CPU는 틱 대비 {(check["cpuSeconds"]/tick["cpuSeconds"]-1)*100:+.3f}%다. 경과 시간 차이는 CPU0 단독 배치와 CPU1–3 공유 부하 조건을 함께 포함하므로 알고리즘 배속으로 보지 않는다.'
for name,label in [('v4-world100','사건100일'),('v4-world-tick30','틱30일')]:
 b=body(name);d=[x for x in b if 'd'in x];pops=[x['pop'] for x in d if 'pop'in x];s=meta(name)['stats'];worldtext+=f"\n\n{label}: 기록 인구 {min(pops)}–{max(pops)}, 마지막 {pops[-1]}; 실제 workKinds `{json.dumps(s.get('workKinds'),ensure_ascii=False)}`. holdChecks={s.get('holdChecks',0)}, steps={s.get('steps')}, bodyTicks={s.get('bodyTicks')}. 최종 자식0/시계오류0."
wb=[x for x in body('v4-world100') if 'd'in x];lastq=world['stats'].get('queue',{});firstq=next((x for x in wb if x.get('st',{}).get('queue',{}).get('queued',0)>0),None)
worldtext+=f"\n\n100일 최종 시설 요청 {lastq.get('requests')}회 / 즉시 승인되지 않은 요청 {lastq.get('queued')}회. 첫 대기 기록 scanDay={firstq['d']+1 if firstq else '없음'}. 이 queued 카운터는 이미 줄에 있는 몸의 재요청도 포함할 수 있으므로 새 삽입 수·고유 몸 수·완료 서비스 수가 아니다. 30일의0회 관측을100일 전체로 일반화하지 않는다. 정본 선점 뒤 연결한 큐의 경쟁 관측이며, 정본 배정 권한까지 FIFO로 교체했다는 뜻은 아니다."
scale=[];summary=[]
for n in [3900,16000]:
 row=[];both=[]
 for mode in ['0','1']:
  name=f'v4-controlled-scale-{n}-{mode}';m=meta(name);b=m['tickBenchmark'];assert m['code']==0 and m['clock']['errs']==0 and b['window']['measuredTicks']==1000 and b['cpu']['samples']==1000 and b['wall']['samples']==1000
  assert b['actualBodies']['min']==b['actualBodies']['max']=={3900:3927,16000:16014}[n];raw=b['rawCpuSamples'];owned=statistics.mean(x['owned'] for x in raw);assert (owned==0 if mode=='0' else owned>0);z={'run':name,'actualBodies':b['actualBodies'],'cpu':b['cpu'],'wall':b['wall'],'ownedMean':owned,'virtualExitV':m['clock']['V'],'status':read(p/name/'status.json')};summary.append(z);both.append(z)
 a,b=both;scale.append([f"{a['actualBodies']['min']} / {b['actualBodies']['min']}",'/'.join(fmt(a['cpu'][k]) for k in ['meanMs','medianMs','p95Ms']),'/'.join(fmt(b['cpu'][k]) for k in ['meanMs','medianMs','p95Ms']),f"{fmt(a['wall']['meanMs'])}/{fmt(b['wall']['meanMs'])}",f"{fmt(a['wall']['p95Ms'])}/{fmt(b['wall']['p95Ms'])}",f"{fmt(a['ownedMean'])}/{fmt(b['ownedMean'])}"])
scaletext=table(['실제몸 틱/사건','틱CPU 평균/중앙/95%ms','사건CPU 평균/중앙/95%ms','wall평균 틱/사건ms','wall95% 틱/사건ms','사건소유 평균 틱/사건'],scale)+'\n\n앞서 실행 중이던 비핵심 주 계측·과거 대조 판이 종료된 뒤 CPU1–3에서 네 창을 순서대로 실행했다. 추가 아침 창·개간 반경 실험은 이 네 창 뒤에 실행했다. 남은 전체100일 판은 CPU0에서 실행했으며 각 창의 시작 조건은 measurement-env.json에 남겼다. 앞선 혼합 부하 표본은 원자료로 보존하되 이 표에 섞지 않았다. 다른 CPU의 세계 판과 공유 메모리/캐시 영향은 남으므로 CPU와 경과 시간을 함께 읽는다.'
assert len({x['virtualExitV'] for x in summary})==1
scaletext+=f"\n\n네 창의 가상 종료 시각은 모두 {summary[0]['virtualExitV']}ms로 같다. CPU는 프로세스의 모든 스레드 누적이라 벽시계보다 클 수 있다."
(p/'v4-scale-summary.json').write_text(json.dumps(summary,indent=2));(out/'v4-scale-summary.json').write_text(json.dumps(summary,indent=2))
abl=[];base=body('historic-tick400')[-1]['farm'];proto=body('historic-proto400');protofarm=proto[-1]['farm'];protomap={x.get('d'):x for x in proto if 'd'in x}
for n,label in [('historic-tick400','과거 틱'),('historic-proto400','과거 시제품'),('historic-workt400','ⓐ 도착 작업시계'),('historic-stop44400','ⓑ 44px경계'),('historic-dawn400','ⓒ 첫결정 즉시'),('historic-nofarmer400','농부 걸음 제외')]:
 b=body(n);f=b[-1]['farm'];common={x.get('d'):x for x in body('historic-tick400') if 'd'in x};first=next((x.get('d')+1 for x in b if 'd'in x and x.get('d') in common and x.get('farm')!=common[x['d']].get('farm')),None);firstproto=next((x.get('d')+1 for x in b if 'd'in x and x.get('d') in protomap and x.get('farm')!=protomap[x['d']].get('farm')),None);abl.append([label,f,fmt((f/base-1)*100)+'%',f-protofarm,first or '없음',firstproto or '없음',b[-1].get('pop')])
abltext=table(['같은 과거 소스400일','최종 개간칸','틱 대비','시제품 대비칸','첫 틱 갈림날','첫 시제품 갈림날','인구'],abl)
order=[]
for n,label in [('queue-nowork400','V2 준비시간 순서'),('queue-order400','V2 기존 NPC 순서')]:
 b=body(n)[-1];order.append([label,b['farm'],b.get('pop')])
abltext+='\n\n'+table(['별도 V2 소스400일 대조 ⓓ','개간칸','인구'],order);oa={x.get('d'):x for x in body('queue-nowork400') if 'd'in x};ob=body('queue-order400');od=next((x['d']+1 for x in ob if 'd'in x and x['d'] in oa and x.get('farm')!=oa[x['d']].get('farm')),None);abltext+=f'\n\nⓓ 첫 개간 칸 갈림 scanDay: {od if od else "없음"}. 원래 NPC 순서만 바꾼 별도V2 쌍이며 과거 시제품의 권한 배정 전체에 대한 인과 확정은 아니다.'
wr=[]
for n,label in [('window-control400','첫 결정 즉시만(추가소스)'),('window-native400','모든 적격 걸음 기한 조정'),('window-farmer400','농부 걸음만 기한 조정')]:
 b=body(n)[-1];wr.append([label,b['farm'],b['farm']-protofarm,fmt((b['farm']/base-1)*100)+'%',b['st'].get('windowCuts',0),fmt(b['st'].get('windowCutMs',0))])
wc=cmp('window-native400');assert wc['sourceHashesEqual'];oldc=cmp('window-control400');abltext+='\n\n### 아침 창 정본 틱 추가 대조\n\n'+table(['아침 창 소스별400일','개간칸','시제품 대비칸','과거 틱 대비','기한 조정 선택','총 앞당김ms'],wr)
abltext+=f"\n\n두 판 모두 nextDecisionAt=0이며 처리 판만0.137에 걸리는 모든 적격 걸음의 문턱을 정본TICK_MS 하나 앞당겨 마지막 허용 틱에서 깨운다. 전체 아침 창을 없앤 실험은 아니다. 추가 소스의 끔 대조와 이전 첫결정 대조의 공식 같음 {oldc['official']['same']}/{oldc['official']['compared']}; 같은 추가 소스 두 판의 공식 같음 {wc['official']['same']}/{wc['official']['compared']}. 계측은 다른 판과 큰 인구 순차 표본이 끝난 뒤 실행했다."
farmerCuts=body('window-farmer400')[-1]['st'].get('windowCuts',0)
if farmerCuts==0:abltext+='\n\n농부 전용 기한 조정 선택0회: 이 세계/설정에서 해당 개입이 실행되지 않았으므로 농부 아침 창의 영향을 배제하는 증거가 아니다.'
fc=cmp('window-farmer400');abltext+=f"\n\n농부 전용 행은 simJob===farmer 술어 한 줄만 추가한 별도 소스이며, 앞 두 행과 소스 해시가 같다고 보지 않는다. 한 줄 패치를 보존했다. 공통 첫결정 대조와 농부 전용의 공식 같음 {fc['official']['same']}/{fc['official']['compared']}. 전체 직업 기한 변경의 간접 효과와 농부만의 효과를 구분한다."
cr=[]
for n,label in [('clear-wake-control400','기본 시제품(추가소스)'),('clear-wake-native400','개간 반경에서 조기 기상')]:
 b=body(n)[-1];cr.append([label,b['farm'],b['farm']-protofarm,fmt((b['farm']/base-1)*100)+'%',b['st'].get('clearRadiusWakes',0),fmt(b['st'].get('clearRadiusCutMs',0))])
cc=cmp('clear-wake-native400');assert cc['sourceHashesEqual'];oc=cmp('clear-wake-control400');abltext+='\n\n### 개간 출근 반경만 추가 대조\n\n'+table(['개간 반경 소스별400일','개간칸','시제품 대비칸','과거 틱 대비','기한 조정 선택','총 조정ms'],cr)
abltext+=f"\n\n건축/귀가 등의 경로를 자르지 않는다. 개간 출근이고 원래 경로 끝이 정본44px 안일 때만, 원래 Route의 위치별 빠르기/시각을 보존하며44px 안이고 기존 nextDecisionAt 이후인 첫 시각에 깨운다. 추가 소스의 끔 대조↔기존 시제품 공식 같음 {oc['official']['same']}/{oc['official']['compared']}; 같은 추가 소스의 두 판 공식 같음 {cc['official']['same']}/{cc['official']['compared']}. 기한 조정 카운터는 최소 토막 수락 전 선택 수이며 실제 새 사건 수와 구분한다."
o=read(p/'v4-off/status.json');assert o['valid'] and o['sourceUnchanged'];offtext=f"**1/1**, checker 종료0, 소스 시작/끝 같음, 공식400일 지문·판JSON·여덟 수 같음. 실제 경과{fmt(o['elapsedWallSeconds'])}초. 원로그/evidence 보존. 이 공식 판의 서버 로그 끝이 잘려 종료 시계 오류 수는 미확인이다(0으로 간주하지 않음). 다른 계측 판의 별도 hook 메타와 구분한다."
farmcmp=cmp('v4-farm-candidate400');farm=farmcmp['costs'];fpercent=(farm['des']['farm']/farm['tick']['farm']-1)*100;default=cmp('v4-candidate400')['costs'];defaultpercent=(default['des']['farm']/default['tick']['farm']-1)*100
values={'SAME':str(farmcmp['official']['same']),'POS':fmt(farmcmp['positions']['medianM']),'CLEAR':f'원인 미확정(과거 반경 조정 {(body("clear-wake-native400")[-1]["farm"]/base-1)*100:+.3f}%; V4기본 {defaultpercent:+.3f}%, 밭켬 {fpercent:+.3f}%)' ,'FORECAST':fmt(world['wallSeconds']*4/60),'TICKHOURS':fmt(tick['wallSeconds']*400/30/3600),'N3900':f"{summary[0]['cpu']['meanMs']:.3f}/{summary[1]['cpu']['meanMs']:.3f}(CPU평균 틱/사건)",'OFF':'1','COMPARISONS':comparison,'DIFFERENCES':difftext,'WORLD':worldtext,'SCALE':scaletext,'ABLATIONS':abltext,'OFFDETAIL':offtext}
s=(p/'report-v4-template.md').read_text()
for k,v in values.items():s=s.replace('{{'+k+'}}',str(v))
assert not re.search(r'\{\{\w+\}\}',s)
s=s.replace('몸 전부는 시딩된 몸 모두를 뜻하며 인구가 시간에 따라 변하는 것을 감췄다는 뜻이 아니다.','몸 상한을 두지 않았으며 실제 인구 변화는 아래에 함께 제시한다.')
(root/'보고/T1248_2026-11-10.md').write_text(s)
print(s.splitlines()[0])

import pathlib,json,time
p=pathlib.Path('/tmp/t1248')
def state(n):
 d=p/n;f=d/'days.jsonl';k=sum(1 for _ in f.open()) if f.exists() else 0;s=d/'status.json'
 if s.exists():return str(k)+(' OK' if json.load(s.open()).get('valid') else ' incomplete')
 return k
print(time.strftime('%H:%M:%S UTC',time.gmtime()))
for label,names in [('v4-400',['v4-tick400','v4-candidate400','v4-farm-tick400','v4-farm-candidate400','v4-farm-replay400']),('world',['v4-world100','v4-world-tick30']),('scale',['v4-scale-3900-0','v4-scale-3900-1','v4-scale-16000-0','v4-scale-16000-1']),('historical',['historic-tick400','historic-proto400','historic-workt400','historic-stop44400','historic-dawn400','historic-nofarmer400']),('extra-ablations',['window-control400','window-native400','window-farmer400','clear-wake-control400','clear-wake-native400'])]:
 print(label, [state(n) for n in names])

f=p.parent/'v4-off/off.log'
if f.exists():
 a=f.read_text().splitlines();print('OFF',a[-1][-180:] if a else 'startup')

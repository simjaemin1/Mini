import pathlib,os,time,json,subprocess,concurrent.futures
p=pathlib.Path('/tmp/t1248');root=pathlib.Path('/workspace/Mini');os.sched_setaffinity(0,{1,2,3})
while not (p/'window-ablation-status.json').exists():time.sleep(10)
assert not any(json.loads((p/'window-ablation-status.json').read_text()).values())
def run(job):
 name,flag=job;d=p/name;d.mkdir(exist_ok=True);env={**os.environ,'T1248_ROOT':str(p/'historical-clear-wake'),'T1248_OUT':str(d),'T1241_DES':'1','T1243_FARM_ON':'0','VILLAGE_MAX':'1','T1241_DES_DAWN':'0','T1241_DES_WALK_WORKT':'0','T1241_DES_STOP44':'0','T1248_NATIVE_CLEAR44':flag}
 (d/'measurement-env.json').write_text(json.dumps({'flags':{k:v for k,v in env.items() if k.startswith(('T1248_','T1241_','T1243_','VILLAGE_MAX'))},'cpus':[1,2,3],'windowCasesFinished':True},indent=2))
 with (d/'batch.log').open('w') as f:r=subprocess.run(['node','scripts/t1248-run.js','400','1020'],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(name,r.returncode,flush=True);return name,r.returncode
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:result=dict(pool.map(run,[('clear-wake-control400','0'),('clear-wake-native400','1')]))
(p/'clear-wake-ablation-status.json').write_text(json.dumps(result,indent=2));raise SystemExit(any(result.values()))

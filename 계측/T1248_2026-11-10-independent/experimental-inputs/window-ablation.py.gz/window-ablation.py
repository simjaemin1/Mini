import pathlib,os,time,json,subprocess,concurrent.futures
p=pathlib.Path('/tmp/t1248');root=pathlib.Path('/workspace/Mini');os.sched_setaffinity(0,{1,2,3})
while not (p/'controlled-scale-status.json').exists():time.sleep(10)
assert not any(json.loads((p/'controlled-scale-status.json').read_text()).values()),'controlled benchmark failure'
def run(job):
 name,flags=job;d=p/name;d.mkdir(exist_ok=True)
 env={**os.environ,'T1248_ROOT':str(p/'historical-window'),'T1248_OUT':str(d),'T1241_DES':'1','T1241_DES_DAWN':'1','T1243_FARM_ON':'0','T1248_NATIVE_MORNING':'0','VILLAGE_MAX':'1',**flags}
 (d/'measurement-env.json').write_text(json.dumps({'flags':{k:v for k,v in env.items() if k.startswith(('T1248_','T1241_','VILLAGE_MAX'))},'cpus':[1,2,3],'controlledBenchmarksAllComplete':True},indent=2))
 with (d/'batch.log').open('w') as f:r=subprocess.run(['node','scripts/t1248-run.js','400','1020'],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(name,r.returncode,flush=True);return name,r.returncode
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:result=dict(pool.map(run,[('window-control400',{}),('window-native400',{'T1248_NATIVE_MORNING':'1'})]))
(p/'window-ablation-status.json').write_text(json.dumps(result,indent=2));raise SystemExit(any(result.values()))

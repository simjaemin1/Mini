import pathlib,os,time,json,subprocess
p=pathlib.Path('/tmp/t1248');root=pathlib.Path('/workspace/Mini');os.sched_setaffinity(0,{1,2,3})
while not(p/'window-ablation-status.json').exists():time.sleep(10)
assert not any(json.loads((p/'window-ablation-status.json').read_text()).values())
d=p/'window-farmer400';d.mkdir(exist_ok=True)
env={**os.environ,'T1248_ROOT':str(p/'historical-window-farmer'),'T1248_OUT':str(d),'T1241_DES':'1','T1241_DES_DAWN':'1','T1248_NATIVE_MORNING':'1','T1243_FARM_ON':'0','VILLAGE_MAX':'1'}
(d/'measurement-env.json').write_text(json.dumps({'flags':{k:v for k,v in env.items() if k.startswith(('T1248_','T1241_','T1243_','VILLAGE_MAX'))},'cpus':[1,2,3],'windowCasesFinished':True},indent=2))
with(d/'batch.log').open('w')as f:r=subprocess.run(['node','scripts/t1248-run.js','400','1020'],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
(p/'window-farmer-status.json').write_text(json.dumps({'window-farmer400':r.returncode},indent=2));print('window-farmer400',r.returncode,flush=True);raise SystemExit(r.returncode)

'use strict';
// Only the zone child loads the canonical economy fingerprint hook.
if (!process.env.T577_OUT || !/server[\\/]zone\.js$/.test(process.argv[1] || '')) return;
const fs = require('fs'), path = require('path');
process.env.SBC_HOOK = '1';
require(path.join(__dirname, 'server-baseline-check.js'));
process.on('exit', () => fs.writeFileSync(process.env.T577_OUT + '.t1274-meta.json', JSON.stringify({
  cpu: process.cpuUsage(), uptimeSeconds: process.uptime(),
  clock: typeof global.__t745 === 'function' ? global.__t745() : null,
  requestedDays: process.env.T577_DAYS, seed: process.env.T577_SEED,
  npcCapEnvironment: process.env.VILLAGE_NPC_CAP || null
})));

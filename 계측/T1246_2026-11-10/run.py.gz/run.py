import os,subprocess,concurrent.futures,json,hashlib,sys
from pathlib import Path
arm=sys.argv[1];root='/tmp/t1246/base' if arm=='before' else '/workspace/Mini';out=Path('/tmp/t1246')/arm
files=['sim/economy-sim.js','sim/economy-sim-v2.js','server/granary-lots.js','scripts/t176-ab.js']
(out/'source.json').write_text(json.dumps({f:hashlib.sha256(Path(root,f).read_bytes()).hexdigest() for f in files},indent=2))
def run(seed):
 env={**os.environ,'T1246_ROOT':root,'T1246_OBSERVE_OUT':str(out/f'{seed}.observe.json'),'T1243_FARM_ON':'0' if arm=='control' else '1','T17_JSON':str(out/f'{seed}.json'),'T176_JSON':str(out/f'{seed}.farm.json'),'NODE_OPTIONS':'--require /workspace/Mini/scripts/t1246-observe.js'}
 with (out/f'{seed}.log').open('w') as f:r=subprocess.run(['node','scripts/t176-ab.js','800',str(seed)],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(arm,seed,r.returncode,flush=True);return seed,r.returncode
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:result=dict(pool.map(run,[1020,7,42]))
(out/'status.json').write_text(json.dumps(result));raise SystemExit(any(result.values()))

from pathlib import Path
import json,csv,gzip,hashlib,shutil,re,subprocess
root=Path('/workspace/Mini'); src=Path('/tmp/t1246'); out=root/'계측/T1246_2026-11-10'; out.mkdir(exist_ok=True)
load=lambda p:json.loads(p.read_text())
unit=load(src/'tests.json');assert len(unit)==9 and not any(unit.values()),unit
parity=load(src/'parity/status.json');assert parity['observedEqualsPlain']
for name in ['after/source.json','control/source.json','off-source.json']:
 for f,h in load(src/name).items():assert hashlib.sha256((root/f).read_bytes()).hexdigest()==h,(name,f)
for f,h in load(src/'observer-source.json').items():assert hashlib.sha256((root/f).read_bytes()).hexdigest()==h,f
before_proof={}
for f in load(src/'before/source.json'):
 original=subprocess.check_output(['git','show','87b63d2c:'+f],cwd=root); b=(src/'base'/f).read_bytes();assert b==original,f;before_proof[f]=hashlib.sha256(b).hexdigest()
log=(src/'off-final.log').read_text();offdir=Path(re.search(r'판 (/tmp/sbc-\w+)',log)[1]);check=load(offdir/'check.json');assert check['res']['1020']['same'] and check['per']['1020']['code']==0 and check['res']['1020']['days']==400,check
records={}; totals={}
for arm in ['before','after','control']:
 status=load(src/arm/'status.json');assert len(status)==3 and not any(status.values()),status
 records[arm]={};tot={'pop':0,'empty':0,'villageDays':0,'priceSum':0,'priceAt1000':0,'populationDays':0,'lumberjackDays':0,'lumberjacksEnd':0,'births':0,'zeroBirthVillageDays':0,'foodDaysSum':0,'reasons':{}}
 for seed in [1020,7,42]:
  d=load(src/arm/f'{seed}.json');f=load(src/arm/f'{seed}.farm.json');o=load(src/arm/f'{seed}.observe.json');assert o['exit']==0,o
  end=o['snapshots'][-1];assert end['day']==800 and end['population']==d['base']['pop'],end
  row={'seed':seed,'population':d['base']['pop'],'empty':d['base']['dead'],'priceMean':o['priceMean'],'lumberjackSharePeriod':o['lumberjackShare'],'lumberjacksEnd':end['lumberjacks'],'lumberjackShareEnd':end['lumberjacks']/max(1,end['population']),'births':o['births'],'zeroBirthVillageDays':o['zeroBirthVillageDays'],'reasons':o['reasons']};records[arm][seed]=row
  tot['pop']+=row['population'];tot['empty']+=row['empty'];tot['lumberjacksEnd']+=end['lumberjacks']
  for k in ['villageDays','priceSum','priceAt1000','populationDays','lumberjackDays','births','zeroBirthVillageDays','foodDaysSum']:tot[k]+=o[k]
  for reason,n in o['reasons'].items():tot['reasons'][reason]=tot['reasons'].get(reason,0)+n
  assert sum(o['reasons'].values())==o['zeroBirthVillageDays']
 tot['priceMean']=tot['priceSum']/max(1,tot['villageDays']);tot['capShare']=tot['priceAt1000']/max(1,tot['villageDays']);tot['ljPeriod']=tot['lumberjackDays']/max(1,tot['populationDays']);tot['ljEnd']=tot['lumberjacksEnd']/max(1,tot['pop']);tot['foodDaysMean']=tot['foodDaysSum']/max(1,tot['villageDays']);totals[arm]=tot
b,a,c=[totals[x] for x in ['before','after','control']];before_ratio=100*b['pop']/c['pop'];after_ratio=100*a['pop']/c['pop']
summary={'baseCommit':'87b63d2c','days':800,'seeds':[1020,7,42],'records':records,'totals':totals,'beforeOffPopulationPercent':before_ratio,'afterOffPopulationPercent':after_ratio}
(out/'요약.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
with (out/'비교.tsv').open('w') as stream:
 w=csv.writer(stream,delimiter='\t',lineterminator='\n');w.writerow(['arm','seed','population','empty','dailyVillagePriceMean','lumberjackShareEnd','lumberjackSharePeriod','births','zeroBirthVillageDays'])
 for arm,rr in records.items():
  for seed,row in rr.items():w.writerow([arm,seed,row['population'],row['empty'],row['priceMean'],row['lumberjackShareEnd'],row['lumberjackSharePeriod'],row['births'],row['zeroBirthVillageDays']])
with (out/'출생사유.tsv').open('w') as stream:
 w=csv.writer(stream,delimiter='\t',lineterminator='\n');w.writerow(['arm','reason','zeroBirthVillageDays','shareOfZeroBirthDays'])
 for arm,t in totals.items():
  for reason,n in t['reasons'].items():w.writerow([arm,reason,n,n/max(1,t['zeroBirthVillageDays'])])
head=f"식량 읽는 자리 17곳(감사 경로) → 정본 하나 · 켬 식량 값 상한 1,000(오진 재현) → {a['priceMean']:.2f}(800일 일별 평균) · 나무꾼 몫 {a['ljEnd']*100:.2f}%(종료) · 랩 켬 인구 {b['pop']:,} → {a['pop']:,}(끔의 {after_ratio:.2f}%) · 빈 마을 {b['empty']} → {a['empty']}(3판 합) · 끈 판 1/1"
md=['| 시드 | 끔 인구 | 전 인구 / 빈 마을 | 후 인구 / 빈 마을 | 식량 값 전→후 | 종료 나무꾼 % 전→후 | 기간 나무꾼 % 전→후 |','|---|---:|---:|---:|---:|---:|---:|']
for seed in [1020,7,42]:
 p,q,z=[records[x][seed] for x in ['before','after','control']];md.append(f"| {seed} | {z['population']} | {p['population']} / {p['empty']} | {q['population']} / {q['empty']} | {p['priceMean']:.2f}→{q['priceMean']:.2f} | {p['lumberjackShareEnd']*100:.2f}→{q['lumberjackShareEnd']*100:.2f} | {p['lumberjackSharePeriod']*100:.2f}→{q['lumberjackSharePeriod']*100:.2f} |")
md.append(f"| 합/가중 | {c['pop']} | {b['pop']} / {b['empty']} | {a['pop']} / {a['empty']} | {b['priceMean']:.2f}→{a['priceMean']:.2f} | {b['ljEnd']*100:.2f}→{a['ljEnd']*100:.2f} | {b['ljPeriod']*100:.2f}→{a['ljPeriod']*100:.2f} |")
summarytext=f"같은 800일의 끔 대비 인구 합 비율은 **{before_ratio:.2f}%→{after_ratio:.2f}%**다. 식량 값이 상한인 마을-날 몫은 {b['capShare']*100:.2f}%→{a['capShare']*100:.2f}%, 평균 곳간 식량 일수는 {b['foodDaysMean']:.2f}→{a['foodDaysMean']:.2f}일이다. 가격의 1,000은 실제 기근·흐름 적자에서도 나올 수 있으므로 모든 상한 가격을 오진이라고 계산하지 않았다."
birth=['| 판 | 출생 수 | 출생 0 마을-날 | 주거 문 | 겨울 문 | 표시 성장≤0 | 누적/다른 문 |','|---|---:|---:|---:|---:|---:|---:|']
for arm,label in [('before','수정 전 켬'),('after','수정 후 켬'),('control','끔 대조')]:
 t=totals[arm];r=t['reasons'];h=r.get('housing',0);birth.append(f"| {label} | {t['births']} | {t['zeroBirthVillageDays']} | {h} ({100*h/max(1,t['zeroBirthVillageDays']):.2f}%) | {r.get('winter-food',0)} | {r.get('nonpositive-or-rounded-growth',0)} | {r.get('fraction-or-other-birth-gate',0)} |")
gates=f"- 수정 전·후·끔 대조 각각 3시드·800일: **9판 종료0**.\n- 관측기 유무 120일·시드1020: 요약·생활층 JSON **완전 일치**.\n- 관련 회귀 하네스 **9개 종료0**, 새 하네스의 켬·끔·옛 읽기 변이·실제 로트·케� Node/브라우저 검사 통과.\n- 브라우저 번들 **16/16 일치**, 두 인라인 실험실 최신.\n- 공식 끔 **1/1 일치**, 시드1020·400일·{check['sec']}초. 400일 날 지문·마을 칸 지문·판 JSON·여덟 수 일치.\n- 계측 시작 해시와 최종 게임 코드 일치."
conclusion=(f"곡물만 있는 곳간을 빈 식량 재고로 오인하는 결함은 하네스로 재현하고 수정했다. 같은 랩의 인구는 {b['pop']:,}→{a['pop']:,}, 종료 나무꾼 몫은 {b['ljEnd']*100:.2f}%→{a['ljEnd']*100:.2f}%로 관측했다. 이 결과를 실제 몸 전체의 개선이나 기본 켬 승인으로 확장하지 않는다.")
text=(src/'report-template.md').read_text();subs={'__HEADLINE__':head,'__METRICS_TABLE__':'\n'.join(md),'__METRICS_SUMMARY__':summarytext,'__BIRTH_TABLE__':'\n'.join(birth),'__GATES__':gates,'__CONCLUSION__':conclusion}
for k,v in subs.items():text=text.replace(k,v)
assert not re.search(r'__[A-Z_]+__',text);(root/'보고/T1246_2026-11-10.md').write_text(text.replace('케�','켬'))
# Archive exact original bytes; do not include temporary DB files.
def archive(p,target):
 target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for arm in ['before','after','control']:
 for p in (src/arm).iterdir():
  if p.is_file():archive(p,out/arm/(p.name+'.gz'))
for p in (src/'parity').iterdir():
 if p.is_file():archive(p,out/'parity'/(p.name+'.gz'))
for p in offdir.iterdir():
 if p.is_file() and '.db' not in p.name and '.sqlite' not in p.name:archive(p,out/'off'/(p.name+'.gz'))
for p in src.iterdir():
 if p.is_file() and (p.name.startswith('test-') or p.name in ['tests.json','off-final.log','off-source.json','observer-source.json','interrupted-preload-runs.json','bundle-check.log','inline-check.log','run.py','observe.js']):archive(p,out/(p.name+'.gz'))
for arm in ['before','after','control']:archive(src/('superseded-'+arm)/'status.json',out/'superseded'/(arm+'-status.json.gz'))
(out/'before-base-proof.json').write_text(json.dumps({'commit':'87b63d2c','verifiedAfterRunAgainstGit':True,'sha256':before_proof},indent=2))
(out/'README.md').write_text('''# T1246 계측 원자료\n\nbefore=87b63d2c 원본, after=최종 코드, control=최종 코드의 끔. 모두 같은 수동 설정 뒤 붙는 관측기로 3×800일. 각 시드 .json은 요약, .farm.json은 실제 밭 생활층, .observe.json은 일별 가격·출생·직업 집계다.\n\nparity는 관측기 유무 120일 원본 JSON 완전 일치 증거다. off는 카드의 공식 400일 서버 기준선 1판이며 몸 전체 라이브 판이 아니다. source.json은 실행 시작 게임 소스 해시다. before-base-proof는 실행 후 원본 복사본과 git 바이트를 대조했다.\n\n루트 observe.js.gz는 **폐기한 초기 관측기**다. 설정 전 require 문제로 9판을 중단했고 superseded/status와 interrupted metadata에 기록했다. 최종 관측기는 저장소 scripts/t1246-observe.js 및 t1246-metrics.js다. 초기 실행을 성공 증거에 포함하지 않았다.\n\nrun.py.gz는 정확한 실행 명령·환경을 남긴다. before 복사본 재현은 git87b63d2c의 server/sim/scripts와 node_modules/public 경로를 준비하고 T1246_ROOT로 지정한다. 켬·끔 각각 별도 프로세스다.\n\n로그와 JSON은 원문 바이트를 gzip으로 보존했다. DB는 포함하지 않는다. SHA256SUMS는 압축 파일을 포함한 보관 바이트의 해시다. 보고서는 보고/T1246_2026-11-10.md.\n''')
lines=[]
for p in sorted(out.rglob('*')):
 if p.is_file() and p.name!='SHA256SUMS':lines.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(out)))
(out/'SHA256SUMS').write_text('\n'.join(lines)+'\n');print(head);print('archived',len(lines),'files')

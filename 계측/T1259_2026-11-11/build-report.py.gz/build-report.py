from pathlib import Path
import json,re
P=Path('/tmp/t1259');R=Path('/workspace/Mini');O=R/'계측/T1259_2026-11-11';S=json.loads((O/'summary.json').read_text());assert S['completeSeedCases']==15
rows={(r['arm'],r['seed']):r for r in S['rows']};seeds=[1020,7,42];arms=['OFF','WOOD','WOOD_CAP','TERR','ALL'];labels={'OFF':'끔','WOOD':'나무꾼만','WOOD_CAP':'나무꾼+자리','TERR':'영토 v2만','ALL':'셋 묶음'}
for a in arms+['OFF_GATE']:
 z=json.loads((P/a/'status.json').read_text());assert z['exit']==0 and z['sourceUnchanged'],a
log=(P/'OFF_GATE/controller.log').read_text();assert '=== 같음 1/1' in log
assert rows['OFF',1020]['pop']==3867
offbase=json.loads((P/'OFF/baseline.json').read_text())['byseed']['1020']
gatetmp=Path(re.search(r'판 (/tmp/sbc-\S+)',log).group(1));gateSBC=json.loads((gatetmp/'sbc-1020.json.sbc.json').read_text());gateGame=json.loads((gatetmp/'sbc-1020.json').read_text())
assert offbase['days']==gateSBC['days'] and offbase['eight']==gateGame['eight']
(O/'off-make-versus-gate.json').write_text(json.dumps({'sameDays':400,'sameEight':True,'sameSource':True},indent=2))

lab=json.loads((O/'t17-validation.json').read_text());assert lab['exit']==0 and lab['population']==5929
ratio=lambda a:' · '.join(f"{rows[a,s]['popRatioToOff']:.3f}" for s in seeds)
table=lambda heads,data:'| '+' | '.join(heads)+' |\n|'+'|'.join(['---']*len(heads))+'|\n'+'\n'.join('| '+' | '.join(map(str,r))+' |' for r in data)
cap60=rows['WOOD_CAP',1020]['lowK']['60']['lumber'];wood60=rows['WOOD',1020]['lowK']['60']['lumber']
first=f"3시드 인구 끔비 — 나무꾼만 {ratio('WOOD')} · +자리 {ratio('WOOD_CAP')} · v2만 {ratio('TERR')} · 셋 묶음 {ratio('ALL')} · 나무 적은 마을 나무꾼148(이전 라이브60날)→{cap60}(이번 빠른60날·1020; 같은 빠른 WOOD {wood60}→{cap60}) · 끈 판1/1 · 회부3"
pop=[];wood=[];thin=[]
for a in arms:
 for s in seeds:
  x=rows[a,s];pop.append([labels[a],s,x['pop'],f"{x['popDeltaFromOff']:+d}",f"{x['popRatioToOff']:.6f}",x['empty'],x['famineVillageDays'],x['foodDebtDeaths'],x['bodyStarveDeaths']])
  wood.append([labels[a],s,f"{x['woodStock']:.3f}",x['felledTrees'],f"{x['felledWood']:.3f}",f"{x['bodyWoodIn']:.3f}",f"{x['econWoodD']:.3f}"])
  t=x['lowK'];thin.append([labels[a],s,t['60']['villages'],f"{t['60']['lumber']}/{t['60']['allLumber']}",t['400']['villages'],f"{t['400']['lumber']}/{t['400']['allLumber']}"])
paired=[]
for s in seeds:
 a,b=rows['WOOD',s],rows['WOOD_CAP',s];paired.append([s,a['pop'],b['pop'],b['pop']-a['pop'],f"{b['pop']/a['pop']:.6f}",a['lowK']['60']['lumber'],b['lowK']['60']['lumber']])
evidence=json.loads((R/'server/wood-walk-evidence.json').read_text());radius=evidence['maxFullDayDistancePx']/2
text=first+'\n\n# T1259 — 선 나무를 읽는 직업 자리와 3시드 400일 비교\n\n'
text+='베이스 `65675e26`(land1064 이후 main), 구현 `1880230e`, 가지 `batch/wood-3seed-1110`. **기본 OFF이며 켬 기본과 병합은 재민 판정이다.** T1248 작업은 앞서 푸시한 별도 독립 가지에 보존했다.\n\n'
text+='## 1. 구현\n\n`jobCapacity`의 나무꾼 자리는 현재 서 있는 나무 셀에 기존 계수0.30을 곱해 내림한다. 서버가 읽는 값은 기존 T398 벌목 후보 중 정본 나무 색인에 현재 나무가 남고, 반경 안이며, 기존 T427/T562 도달 술어로 회관에서 닿는 셀 수다. 별도 나무 재고나 새 도달 알고리즘을 두지 않았다. 당일 벌목은 다시 정본 색인에 물으므로 빈 셀을 자리로 세지 않는다. 후보 목록의 일 캐시는 기존 벌목 목록과 같다.\n\n'
text+='직업 선택·변경 함수는 그대로이며 직업을 직접 배정하지 않는다. `T1259_WOOD_CAP=1`만 켜고 끔은 옛 땅×숲 계산을 유지한다. 공간 reader가 없는 독립 랩은 기존 비공간 모델을 유지한다. 회관 기준은 기존 헤드리스 나무꾼 하루 왕복 예산의 출발점과 같다.\n\n'
text+=f"추가 실제 이동 관측: 1마을·시드1020·자연 직업·운영 하루1440000ms·몸∞·60일. 나무꾼3명, 완전 하루67개(경계 한 틱은 합산에서 빠짐)의 최대 이동은 {evidence['maxFullDayDistancePx']:.9f}px였다. 읽기 반경은 왕복2로 나눈 {radius:.9f}px({radius/32:.3f}셀)이며 `_tripDayMs()`의 정본 운영 하루 비율로만 스케일한다. 기존 영토 밖16셀 후보 고리를 넓히지 않는다. 이동은 나무꾼 역할로 있던 하루의 전체 좌표 이동이며 벌목 출퇴근 구간만 분리한 값은 아니다. 이는 표본 최대이지 세계 전체의 통계 추정이 아니며, 직선 반경과 도달 판정이 우회 경로 전체의 소요시간을 보증하지는 않는다.\n\n"
text+='## 2. 조건과 짝 비교\n\n카드의 빠른 시계400날·시드1020/7/42, `server-baseline-check --make --days 400 --seeds 1020,7,42 --vclock --par 1`을 팔마다 실행했다. 세 시드는 정본 자의 econ 시드이며 지도·소굴·전쟁 시드는 고정이다. 집 행위/캐러밴은 이 정본 자의 끔 조건이다. 가시 몸 상한1이며, 전체 몸을 걷는 라이브400일 판이 아니다. 모든15개는400일·51마을·양수 시딩·자식 종료0·시계 오류0·관찰기 오류0을 확인했다. 기록 소스 해시를 동일하게 고정했다.\n\n'
text+=table(['팔','T325 목재','T1259 자리','T1207 영토','T1238 v2'],[['끔',0,0,0,0],['나무꾼만',1,0,0,0],['나무꾼+자리',1,1,0,0],['영토v2만',0,0,1,1],['셋 묶음',1,1,1,1]])+'\n\n'
text+='인구 Δ와 비율의 분모는 같은 시드의 끔이다. 시드 평균을 다른 시드의 분모에 나누지 않았다. 기근 마을일은 정본 `villageFamine`이 참인 마을×날 수다. 식량 빚 사망과 몸 굶음 사망은 네이티브 T577의 별도 정본 누계다. 관찰기의 `starvedEvents`는 export 호출만 감싸 내부 직접 호출을 포함하지 않아 사망 표에 사용하지 않았다.\n\n'
text+=table(['팔','시드','인구','끔 대비 Δ','끔 대비 비율','빈 마을','기근 마을일','식량빚 사망','몸 굶음 사망'],pop)+'\n\n'
text+='## 3. 목재와 나무 적은 마을\n\n벌목 문 반환량과 곳간 입고를 구분한다. 정본 벌목 문은 빠른 판의 일괄과 영토 개간 그루도 포함한다. econ 몫은 T1251과 같은 이전날 `_woodOutLast` 누계다. 수요 문·손 짐·개간의 추가 수요가 있으므로 벌목량=입고=econ 몫으로 맞춰 적지 않았다. 단위는 정본 목재 단이다.\n\n'
text+=table(['팔','시드','끝 곳간 목재','벌목 그루','벌목 문 반환량','실제 입고 누계','econ 식 몫 누계'],wood)+'\n\n'
text+='K는 기존 벌목 후보 고리의 정본 raw 그루 수로, 현재 서 있는 나무 셀 수와 다르다. K<60의60과 비교 시점은 카드/T1251을 따른다. T1251의148명은 라이브60일이라 이번 빠른 판과 직접 인과차로 쓰지 않았다. 이번 같은 빠른 조건의 WOOD→WOOD_CAP은 별도로 대조한다.\n\n'
text+=table(['팔','시드','60일 K<60 마을','60일 해당 나무꾼/전체','400일 K<60 마을','400일 해당 나무꾼/전체'],thin)+'\n\n'
text+=table(['시드','WOOD 인구','+자리 인구','자리 추가 Δ','+자리/WOOD','WOOD 얇은숲 나무꾼60일','+자리 같은지표'],paired)+'\n\n'
text+='## 4. 게이트와 보존\n\n- 공식 끔400일: 기준선11-08c의1020:400 **1/1**, 인구3867. 별도의 끔 make 판1020과도 원문 지문을 대조했다.\n- 랩 t17 시드1020·800일: **5929명, 종료0**.\n- 하네스4/0: 끔 기본/명시적0/켬, 정본 나무0·도달 불가·당일 벌목, 미끼 검출. 미끼는 나무 입력을 무시한 실제 코드 사본이며 의도한 나무0 단언으로 실패함을 확인했다.\n- 초기 실서버51마을 켬3일과 관찰기 포함끔20일 접두1/1도 보존했다. 본400일 게이트를 대신하지 않는다.\n- 이동 관찰기의 초기 두 오류 진단은 중단·무효로 보존했다. 기본 속도를 상한으로 오인해 정상 도로 가속을 누락했으며 첫 버전에는 시각 소수 허용 오차도 부족했다. 최종 진단은 모든 유한 좌표 차를 포함하고 최대 프레임 이동을 남겼다.1마을 진단의 T577 최소40마을 단언 실패1은 그대로 남겼고 엔진60일 종료0/시계오류0과 구분했다.\n\n'
text+='관찰기 raw의 `wallSeconds`는 T745가 덮은 hrtime에서 나온 가상 구간 길이로 확인되어 실제 경과 시간으로 사용하지 않았다. 요약에는 `observerVirtualElapsedSeconds`로 이름을 바로잡고 부모 정본 러너의 실제 초를 따로 기록했다.\n\n'
text+='`계측/T1259_2026-11-11/`에 입력·환경·소스 해시·정본 판 JSON·400날 지문·관찰기·로그·시드별 검증·요약·재현 절차·SHA256SUMS를 보관했다. DB는 제외했다.\n\n'
text+='## 회부3 — 켬 기본은 재민 판정\n\n1. 위 세 시드의 짝 결과를 근거로 목재 단독/자리 추가/영토v2 조합의 켬 기본을 판정한다. 이번 작업은 기본 OFF를 유지한다.\n2. 새 반경의 추가 이동 표본은1마을3명67몸날이다. 더 넓은 라이브 표본과 우회 경로 소요시간까지의 제약은 별도 검증 범위다.\n3. 셋 묶음과 v2만의 차이는 목재+자리의 결합 효과다. v2+목재(자리끔) 팔이 없어 v2 조건에서 자리만의 효과를 완전히 분리하지 않는다. T1251의 다른 소스·라이브 조건 수치를 이 팔에 대입하지 않는다.\n'
(R/'보고/T1259_2026-11-11.md').write_text(text);print(first)

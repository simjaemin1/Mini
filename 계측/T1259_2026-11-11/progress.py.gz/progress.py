from pathlib import Path
import json,re,time
p=Path('/tmp/t1259');print(time.strftime('%H:%M:%S UTC',time.gmtime()))
for name in ['OFF','WOOD','WOOD_CAP','TERR','ALL','OFF_GATE']:
 d=p/name;s=d/'status.json'
 if s.exists():
  z=json.load(s.open());print(name,'DONE',z['exit'],'source',z['sourceUnchanged']);continue
 f=d/'controller.log'
 if not f.exists():print(name,'queued');continue
 text=f.read_text(errors='replace');m=re.search(r'판 (/tmp/sbc-\S+)',text)
 if not m:print(name,'starting');continue
 r=Path(m.group(1));a=[]
 for seed in ([1020] if name=='OFF_GATE' else [1020,7,42]):
  j=r/f'sbc-{seed}.json';l=r/f'sbc-{seed}.log'
  if j.exists():a.append(str(seed)+':'+str(json.load(j.open()).get('days')))
  elif l.exists():
   with l.open('rb') as h:h.seek(max(0,l.stat().st_size-131072));tail=h.read().decode(errors='replace')
   rows=re.findall(r'econ day (\d+)',tail);a.append(str(seed)+':'+(rows[-1] if rows else 'boot'))
  else:a.append(str(seed)+':queued')
 print(name,' '.join(a))

from pathlib import Path
import json,re,gzip,hashlib,shutil
P=Path('/tmp/t1259');R=Path('/workspace/Mini');OUT=R/'계측/T1259_2026-11-11';ARMS=['OFF','WOOD','WOOD_CAP','TERR','ALL'];SEEDS=[1020,7,42]
read=lambda f:json.loads(f.read_text())
expected=read(P/'matrix-source.json');results=[]
for arm in ARMS:
 d=P/arm;l=d/'controller.log'
 if not l.exists():continue
 text=l.read_text();m=re.search(r'판 (/tmp/sbc-\S+)',text)
 if not m:continue
 tmp=Path(m.group(1))
 for seed in SEEDS:
  file=tmp/f'sbc-{seed}.json';obs=tmp/f'sbc-{seed}.json.t1259.json'
  if not(file.exists() and obs.exists()):continue
  g=read(file);o=read(obs)
  if g.get('days')!=400:continue
  assert g['villages']==51 and len(g['seedPop'])==51 and min(g['seedPop'])>0,(arm,seed,'seed')
  assert len(o['rows'])==400 and [r['day'] for r in o['rows']]==list(range(1,401)),(arm,seed,'days')
  assert not o['errors'] and o['clock']['errs']==0 and o['source']==expected,(arm,seed,'observer/source')
  assert len(o['snapshots'])==40 and o['rows'][-1]['pop']==g['eight']['pop'],(arm,seed,'snapshot/pop')
  if not re.search(r'시드 '+str(seed)+r' 400일 판 .*종료 0',text):continue
  fd=read(tmp/f'sbc-{seed}.fd-deaths.json');assert fd['days']==400
  last=o['rows'][-1];snaps={x['day']:x for x in o['snapshots']}
  low={}
  for day in [60,400]:
   v=snaps[day]['villages'];assert len(v)==51
   small=[r for r in v if r['K']<60]
   low[str(day)]={'villages':len(small),'lumber':sum(v['lumber'] for v in small),'allLumber':sum(item['lumber'] for item in v)}
  row={'arm':arm,'seed':seed,'pop':g['eight']['pop'],'empty':g['empty'],'foodDebtDeaths':fd['fdDeadTot'],'bodyStarveDeaths':g['bodyExit']['died']['starve'],'famineVillageDays':o['famineVillageDays'],'woodStock':last['wood'],'felledTrees':o['felledTrees'],'felledWood':o['felledWood'],'bodyWoodIn':o['bodyWoodIn'],'econWoodD':o['econWoodD'],'lowK':low,'cpuSeconds':o['cpuSeconds'],'observerVirtualElapsedSeconds':o['wallSeconds'],'runnerWallSecondsRounded':float(re.search(r'시드 '+str(seed)+r' 400일 판 ([0-9.]+)초',text).group(1)),'clockErrors':0,'childExit':0,'sourceValidated':True}
  results.append(row);dest=OUT/'runs'/arm/str(seed)
  if not (dest/'validation.json').exists():
   dest.mkdir(parents=True,exist_ok=True)
   for f in tmp.glob(f'sbc-{seed}*'):
    if f.is_file() and '.db' not in f.name and f.suffix in ['.json','.log']:(dest/(f.name+'.gz')).write_bytes(gzip.compress(f.read_bytes(),mtime=0))
   print('archived',arm,seed)
  (dest/'validation.json').write_text(json.dumps(row,indent=2))
for arm in ARMS+['OFF_GATE']:
 d=P/arm;dest=OUT/'controllers'/arm
 if (d/'status.json').exists():
  dest.mkdir(parents=True,exist_ok=True)
  for n in ['input.json','status.json','controller.log','baseline.json']:
   if (d/n).exists():(dest/(n+'.gz')).write_bytes(gzip.compress((d/n).read_bytes(),mtime=0))
g=P/'OFF_GATE'
if (g/'status.json').exists():
 text=(g/'controller.log').read_text();m=re.search(r'판 (/tmp/sbc-\S+)',text)
 if m:
  root=Path(m.group(1));dest=OUT/'off-gate';dest.mkdir(exist_ok=True)
  for f in root.rglob('*'):
   if f.is_file() and '.db' not in f.name and f.suffix in ['.json','.log']:
    to=dest/(str(f.relative_to(root))+'.gz');to.parent.mkdir(parents=True,exist_ok=True);to.write_bytes(gzip.compress(f.read_bytes(),mtime=0))
base={r['seed']:r for r in results if r['arm']=='OFF'}
for row in results:
 if row['seed'] in base:
  off=base[row['seed']];row['popDeltaFromOff']=row['pop']-off['pop'];row['popRatioToOff']=row['pop']/off['pop']
(OUT/'summary.json').write_text(json.dumps({'completeSeedCases':len(results),'requiredSeedCases':15,'rows':results},indent=2));print('completed seed cases',len(results),'/15')

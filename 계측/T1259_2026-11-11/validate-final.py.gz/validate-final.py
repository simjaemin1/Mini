from pathlib import Path
import json,gzip,hashlib,re,subprocess
P=Path('/tmp/t1259');R=Path('/workspace/Mini');O=R/'계측/T1259_2026-11-11';read=lambda p:json.loads(p.read_text())
expected=read(P/'matrix-source.json');assert all(hashlib.sha256((R/f).read_bytes()).hexdigest()==h for f,h in expected.items())
assert all(hashlib.sha256(subprocess.check_output(['git','show','1880230e:'+f],cwd=R)).hexdigest()==h for f,h in expected.items())
e=read(R/'server/wood-walk-evidence.json');w=read(P/'walk.json');assert hashlib.sha256((P/'walk.json').read_bytes()).hexdigest()==e['rawSHA256']
bestSamples=max(r['samples'] for r in w['rows']);selected=[r for r in w['rows'] if r['samples']==bestSamples and r['nonfinite']==0]
assert bestSamples==e['samplesPerFullBodyDay'] and len(selected)==e['fullBodyDays'] and len({r['pid'] for r in selected})==e['actors']
assert max(r['distancePx'] for r in selected)==e['maxFullDayDistancePx']
x=read(O/'summary.json');assert x['completeSeedCases']==15
wanted={(a,s) for a in ['OFF','WOOD','WOOD_CAP','TERR','ALL'] for s in [1020,7,42]};assert {(r['arm'],r['seed']) for r in x['rows']}==wanted
records=[]
for a,s in sorted(wanted):
 d=O/'runs'/a/str(s);raw=lambda n:json.loads(gzip.decompress((d/n).read_bytes()))
 g=raw(f'sbc-{s}.json.gz');m=raw(f'sbc-{s}.json.t1259.json.gz');v=read(d/'validation.json')
 assert g['days']==400 and g['villages']==51 and len(g['seedPop'])==51 and min(g['seedPop'])>0
 assert not m['errors'] and m['clock']['errs']==0 and m['source']==expected
 assert len(m['rows'])==400 and m['rows'][-1]['pop']==g['eight']['pop']==v['pop']
 assert v['childExit']==0 and v['sourceValidated']
 records.append({'arm':a,'seed':s,'days':400,'villages':51,'positiveInitialSeeding':True,'childExit':0,'clockErrors':0,'observerErrors':0,'sourceEqualsFrozenVersion':True,'finalPopulation':g['eight']['pop']})
for a in ['OFF','WOOD','WOOD_CAP','TERR','ALL','OFF_GATE']:
 s=read(P/a/'status.json');assert s['exit']==0 and s['sourceUnchanged']
text=(P/'OFF_GATE/controller.log').read_text();assert '=== 같음 1/1' in text
tmp=Path(re.search(r'판 (/tmp/sbc-\S+)',text).group(1));gm=read(tmp/'sbc-1020.json.t1259.json');assert gm['source']==expected and gm['clock']['errs']==0 and not gm['errors']
refs=read(O/'off-three-seed-reference-comparison.json');assert len(refs)==3 and all(r['sameDailyFingerprint'] and r['sameEight'] for r in refs)
lab=read(O/'t17-validation.json');assert lab['exit']==0 and lab['population']==5929
assert '4/0' in (P/'harness.log').read_text()
z={'all15SeedCasesComplete':True,'frozenSourceEqualsCurrentFiles':True,'frozenSourceEqualsImplementation1880230e':True,'sourceHashes':expected,'walkEvidenceSelection':{'sampleCount':bestSamples,'bodyDays':len(selected),'actors':e['actors'],'maxDistancePx':e['maxFullDayDistancePx'],'rawSHA256':e['rawSHA256']},'measurements':records,'nativeOffGate':'1/1','nativeOffGateClockErrors':0,'offMakeReferenceDaysAndEight':'3/3','labT17':{'seed':1020,'days':800,'exit':0,'population':5929},'targetHarnessConfigurations':'4/0 (including intended bait rejection)','timingFieldScope':'Observer raw wallSeconds is virtual hrtime elapsed; summary explicitly renames it and uses native parent rounded wall seconds. CPU is process.cpuUsage.','starvationFieldScope':'Use native fdDeadTot and bodyExit.died.starve; observer exported-hook starvedEvents omits internal direct calls and is excluded from outcome tables.'}
(O/'final-source-and-results-validation.json').write_text(json.dumps(z,indent=2));print('validated15 complete400-day seed cases, allsixnativecontrollers, sources, OFFgate andlab')
